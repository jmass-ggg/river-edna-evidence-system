# FreshWater targeted debugging package

Selected working-tree files preserve their original paths. Source code, tests and scientific artifacts are unchanged. This package supports investigation; it is not a defect report. Existing validation reports describe prior runs. No application tests were rerun while packaging.

## Contents

1. Backend: application modules required by the APIs and scientific workflows, including routes, services, repositories, schemas, domain, database, scientific engines/rules, context providers, preflight extraction, configuration and migrations.
2. Frontend: investigation creation (src/pages/Investigations.jsx), workspace, reports, sites, dashboard, maps, hooks, API client, imported components, router, styles and build configuration.
3. Science: small preflight CSV/GeoJSON/JSON artifacts, verified topology and A/B/C/D sites, Z1/Z2/Z3 zones, sampling validation, historical metadata, reproducible candidate comparisons/decision output, validation summaries, science freeze documents/checksums and Carraro source fixtures.
4. Tests: all backend/tests and frontend/tests source files plus scripts imported by tests and browser/reproduction launchers.
5. Configuration: backend/requirements.txt, frontend/package.json and package-lock.json, backend/.env.example, alembic.ini. No backend dependency lockfile was present. DEBUG_DIRECTORY_TREE.txt lists packaged paths; DEBUG_FILE_MANIFEST.json records each original file's size and SHA-256.

## Review entry points

- backend/app/api/routes/{cases,investigations,evidence,hydrology,sampling,follow_up_samples,demo,one_health}.py
- backend/app/services/investigation_service.py and adjacent services
- backend/app/scientific/{evidence,hydrology,sampling}/ and rules/catalog.py
- frontend/src/pages/{Investigations,InvestigationWorkspace,Reports,Sites,Dashboard}.jsx
- frontend/src/components/ScientificMap.jsx and frontend/src/services/api.js
- data_preflight/outputs/sampling_design_validation.json
- reproducibility_outputs/wigger_result.json and WIGGER_INVESTIGATION_REPORT.md

## Test setup

From the extracted root, create a fresh Python venv at `venv` (the browser configuration expects that path), and install backend/requirements.txt. Supply your own DATABASE_URL through the environment; backend/config.py requires it. For the existing SQLite-backed unit-test fixtures, use a disposable URL such as `DATABASE_URL=sqlite:////tmp/freshwater-debug.sqlite`. From backend run `../venv/bin/python -m pytest tests`. Production persistence uses PostgreSQL; SQLite test results do not establish live PostgreSQL persistence correctness.

From frontend run `npm ci`, then `npm test`. For browser tests run `npx playwright install chromium`, then `npm run test:e2e`. The included browser launcher creates a disposable SQLite database; see scripts/run_browser_test_backend.py and frontend/playwright.config.js.

## Exclusions and limitations

Real .env files, virtual environments, node_modules, database files/backups, caches, Git internals, browser recordings/screenshots and large raw HydroRIVERS shapefiles are excluded. Personal prompt drafts and unrelated architecture/audit narratives are excluded to keep the review focused. Example configuration and synthetic credentials in tests are placeholders, not supplied access credentials.

Carraro MATLAB fixtures, model scripts and the metadata workbook are included because historical validation reads them directly. Derived Wigger topology and crosswalks are included. Regenerating the raw HydroRIVERS crosswalk requires separately supplying data_preflight/raw/hydrorivers/HydroRIVERS_v10_eu.shp and its companion files. Specifically, backend/tests/unit/test_carraro_v4_extraction.py::test_crosswalk_is_deterministic_and_only_s1_is_matched needs this omitted dataset; inventory and observation tests in that file use included Carraro fixtures. Raw GIS preflight scripts also require omitted shapefiles. No tests were modified or skipped in this snapshot.

Generated DEBUG_* files are packaging aids. The directory tree describes archive contents rather than excluded project content.
