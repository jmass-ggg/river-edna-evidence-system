# FreshWater eDNA Evidence Investigator — Module Audit Report

**Type:** Read-only architectural and implementation audit  
**Date:** 2026-10-02  
**Source inspected:** 72 files — backend, frontend, tests, migrations, scripts  
**Constraint:** No production code modified

---

## Part 1 — Module Architecture Map

### 1.1 Five logical modules and their file ownership

---

#### Module 1 — Investigation Management

Responsibility: create, persist, retrieve, and list investigations; record the initial eDNA detection event; register the detection site; accept eDNA replicate evidence from the form; register follow-up field samples; maintain database integrity across all writes.

| Layer | Files |
|-------|-------|
| Routes | `api/routes/cases.py`, `api/routes/evidence.py`, `api/routes/follow_up_samples.py` |
| Services | `services/case_service.py`, `services/evidence_service.py`, `services/follow_up_sample_service.py` |
| Repositories | `repositories/cases.py`, `repositories/evidence.py`, `repositories/follow_up_samples.py` |
| Schemas | `schemas/cases.py`, `schemas/evidence.py`, `schemas/follow_up_samples.py` |
| DB Models | `db/models.py` → `CaseModel`, `SamplingSiteModel`, `EvidenceItemModel`, `FollowUpSampleModel` |
| Migrations | `6758ca39bed9_initial_schema_with_all_tables.py`, `a31f6c729d0a_add_follow_up_samples.py` |
| Frontend | `pages/Investigations.jsx` (list + creation form), `pages/Dashboard.jsx` |
| Tests | `test_case_creation_integration.py`, `test_follow_up_samples.py`, `test_services.py` (TestCaseService, TestEvidenceService) |

---

#### Module 2 — Scientific Evidence Engine

Responsibility: load and serve the HydroRIVERS river network; apply evidence compatibility rules; assess each evidence item against each zone hypothesis; maintain the rule catalog and evidence strength assessments.

| Layer | Files |
|-------|-------|
| Routes | `api/routes/hydrology.py`, `api/routes/evidence.py` (evidence-assessment endpoint) |
| Services | `services/hydrology_service.py`, `services/evidence_service.py` (assess_evidence_for_zones) |
| Repositories | `repositories/evidence.py` |
| Schemas | `schemas/hydrology.py`, `schemas/evidence.py` |
| Scientific engines | `scientific/hydrology/engine.py`, `scientific/evidence/engine.py`, `scientific/rules/catalog.py`, `scientific/data_loader.py`, `scientific/interfaces.py` |
| DB Models | `EvidenceItemModel` (evidence storage) |
| Dependencies | `api/dependencies.py` (engine initialization) |
| Frontend | `InvestigationWorkspace.jsx` (Possible Sources accordion, evidence assessment display) |
| Tests | `test_hydrology_engine.py`, `test_wigger_loader.py`, `test_wigger_scientific_regression.py`, `test_v3_scientific_boundaries.py`, `tests/property/test_hydrology_properties.py`, `tests/property/test_evidence_properties.py` |

---

#### Module 3 — Sampling Decision Engine

Responsibility: generate topology-based candidate sites; evaluate and score candidates using pair-separation; persist a sampling decision and audit trace; return the map GeoJSON for case-specific geography.

| Layer | Files |
|-------|-------|
| Routes | `api/routes/sampling.py` |
| Services | `services/sampling_service.py` |
| Repositories | `repositories/sampling.py` |
| Schemas | `schemas/sampling.py` |
| Scientific engines | `scientific/sampling/engine.py`, `scientific/sampling/candidate_generator.py` |
| DB Models | `SamplingSiteModel`, `CandidateZoneModel`, `SamplingDecisionModel`, `DecisionTraceModel` |
| Migrations | `6758ca39bed9` (sites, zones, decisions, traces) |
| Frontend | `InvestigationWorkspace.jsx` (Sampling Decision accordion, SimpleCandidates table), `pages/Sites.jsx`, `components/ScientificMap.jsx` |
| Tests | `test_sampling_repository.py`, `test_wigger_scientific_regression.py`, `test_services.py` (TestSamplingService), `tests/property/test_sampling_properties.py`, `test_sampling_scope_audit.py` |

---

#### Module 4 — Reinvestigation Engine

Responsibility: orchestrate a versioned reinvestigation run; snapshot hypothesis states; compare before/after; persist append-only run history; handle failure rollback.

| Layer | Files |
|-------|-------|
| Routes | `api/routes/investigations.py` |
| Services | `services/investigation_service.py` |
| Repositories | `repositories/investigations.py` |
| Schemas | `schemas/investigations.py` |
| Scientific engines | `scientific/hypothesis.py` (ConservativeHypothesisStateResolver), `scientific/sampling/candidate_generator.py`, `scientific/sampling/engine.py`, `scientific/evidence/engine.py` |
| DB Models | `InvestigationRunModel`, `HypothesisStateModel`, `GeneratedCandidateSnapshotModel` |
| Migrations | `d4c8e1a907b2_add_investigation_history.py` |
| Frontend | `InvestigationWorkspace.jsx` (Next Steps accordion, run reinvestigation button, latest run display) |
| Tests | `test_investigation_runs.py`, `test_v4_scientific_update.py` |

---

#### Module 5 — Scientific Communication

Responsibility: generate investigation reports; provide environmental and One Health context; serve the Wigger demo; expose the map endpoint for the Sites page; export PDF.

| Layer | Files |
|-------|-------|
| Routes | `api/routes/demo.py`, `api/routes/one_health.py`, `api/routes/context.py`, `api/routes/health.py` |
| Services | `services/one_health_service.py` |
| Context providers | `context/service.py`, `context/providers/gbif.py`, `context/providers/weather.py`, `context/providers/urbanization.py`, `context/interfaces.py` |
| Scientific validation | `scientific/historical_validation.py`, `preflight/carraro_v4.py` |
| Schemas | `schemas/one_health.py`, `schemas/context.py` |
| Data | `data_preflight/outputs/*` (frozen Wigger artifacts) |
| Frontend | `pages/Reports.jsx`, `pages/Sites.jsx`, `pages/Home.jsx`, `components/ScientificMap.jsx` |
| Tests | `test_carraro_validation.py`, `test_carraro_v4_extraction.py`, `test_wigger_map_api.py`, `test_wigger_reproducible_workflow.py`, `test_v3_scientific_boundaries.py` (One Health, context), `test_v4_scientific_update.py` (historical overlap) |

---

### 1.2 Module dependency map

```
Module 1 (Investigation Management)
  └─writes─> cases, sampling_sites, evidence_items, follow_up_samples (DB)
  └─depends on─> Module 2 (reads evidence for assessment)
  └─depends on─> Module 3 (creates detection site, registers zones/sites)

Module 2 (Scientific Evidence Engine)
  └─reads─> evidence_items, candidate_zones (DB)
  └─loads─> upstream_reaches_real.csv, upstream_edges.csv (at startup + per-request)
  └─depends on─> Module 1 (reads evidence)
  └─feeds─> Module 3 (evidence assessments used in decision)
  └─feeds─> Module 4 (engine instances passed to InvestigationService)

Module 3 (Sampling Decision Engine)
  └─reads─> sampling_sites, candidate_zones, sampling_decisions (DB)
  └─reads─> upstream_reaches_real.geojson, site_a_snap_validation.json (per-request)
  └─depends on─> Module 2 (HydrologyEngine for can_contribute)
  └─feeds─> Module 4 (sampling_engine, candidate_generator injected)

Module 4 (Reinvestigation Engine)
  └─reads/writes─> investigation_runs, hypothesis_states, generated_candidate_snapshots (DB)
  └─orchestrates─> Modules 2, 3 engines
  └─reads─> evidence_items, candidate_zones, follow_up_samples (DB)
  └─depends on─> Module 1 (all evidence and zones must exist first)

Module 5 (Scientific Communication)
  └─reads─> all DB tables (read-only for reports)
  └─reads─> frozen preflight GeoJSON artifacts
  └─calls─> GBIF API, Open-Meteo API (external)
  └─depends on─> Modules 1–4 complete for a full report
  └─writes─> evidence_items (context records stored via EvidenceRepository)
```

---

## Part 2 — Scientific Workflow Verification

### 2.1 Nine-step workflow vs. implementation

| Step | Description | Implementation Status | Notes |
|------|-------------|----------------------|-------|
| 1 | Record initial eDNA detection | **COMPLETE** | POST /cases creates case + detection site + optional replicate evidence atomically |
| 2 | Load river network and scientific context | **COMPLETE** | HydrologyEngine loads at startup; GBIF + ERA5 on demand; GHSL explicitly unavailable |
| 3 | Define plausible upstream source hypotheses | **COMPLETE** | POST /cases/{id}/zones; frontend ZoneForm; Wigger demo loads Z1/Z2/Z3 automatically |
| 4 | Assess evidence against hypotheses | **COMPLETE** | GET /cases/{id}/evidence-assessment; one validated rule (hydrorivers.directed_contribution.v1); all other types → UNKNOWN |
| 5 | Generate and compare sampling candidates | **COMPLETE** | GET /cases/{id}/generated-candidates; pair-separation scoring; equivalence classes |
| 6 | Record new sampling evidence | **COMPLETE** | POST /cases/{id}/follow-up-samples; atomic evidence linkage |
| 6b | Reinvestigate after new evidence | **COMPLETE** | POST /cases/{id}/reinvestigate; versioned runs; before/after diff |
| 7 | Present findings, uncertainty, monitoring relevance | **PARTIAL** | Reports page is complete; One Health pathway is only implemented for the specific Fs/H001/S1/2014-06-25 case identity |
| — | PDF export | **COMPLETE** | window.print() + SVG PrintMap fallback; Playwright test generates actual PDF |

### 2.2 Identified workflow inconsistencies

**W1 — Follow-up evidence cannot alter hypotheses (known, documented)**  
File: `services/investigation_service.py` lines 83–85, `scientific/hypothesis.py` ConservativeHypothesisStateResolver  
A follow-up sample creates `follow_up_edna_sample` evidence. No rule in `rules/catalog.py` classifies this type. The resolver only acts on `hydrorivers.directed_contribution.v1`. Hypothesis states will always remain at their topology-based resolution regardless of field results. This is explicitly documented in the trace limitations but is a functional gap in the scientific workflow.

**W2 — HydrologyEngine rebuilt per request (performance defect)**  
Files: `api/routes/hydrology.py` → `get_hydrology_service()`, `api/routes/sampling.py` → `get_sampling_service()`  
Both functions call `WiggerPreflightLoader(…)` and construct a fresh `HydrologyEngine` on every HTTP request. `api/dependencies.py` correctly initializes `_hydrology_engine` at startup but this global is only used by `get_hydrology_engine()` — which is used only by `api/routes/cases.py` and `api/routes/follow_up_samples.py`. The hydrology and sampling routes do not use the startup-initialized engine.

**W3 — Decision trace written twice (design defect)**  
File: `services/sampling_service.py` lines 96–116  
`save_decision()` inserts a `DecisionTraceModel` with empty arrays. The service immediately mutates the ORM object and commits again to overwrite with real content. This is two commits for one logical operation and risks an inconsistent state if the process dies between commits.

**W4 — One Health pathway hardcoded to single case identity**  
File: `services/one_health_service.py` → `_is_verified_fs_case()`  
The method checks `target_taxon == "Fredericella sultana"` AND `station == "S1"` AND `date == "2014-06-25"`. Any other Fs investigation, or any investigation of any other taxon, returns `pathways: []`. The framework structure exists but carries no content for the general case.

**W5 — Coordinate snapping not implemented for new investigations**  
File: `api/routes/cases.py` → `create_case()`  
The comment explicitly states: "The application does not implement coordinate snapping. Require the caller's supplied reach to exist in the validated loaded network." Users must know and supply a correct HYRIV_ID. There is no spatial lookup or nearest-reach suggestion. The frontend labels the field "Verified HydroRIVERS reach ID" — appropriate but places full burden on the user.

**W6 — Single replicate only in creation form**  
File: `frontend/src/pages/Investigations.jsx` → `NewInvestigationForm`  
The form has a single "Replicate 1" dropdown. The schema stores `value: {replicate_results: [one_value]}`. The domain supports multiple replicates (follow-up samples track replicate_count and positive_replicates), but the creation form cannot record more than one replicate result.

---

## Part 3 — Module 1 Audit (Investigation Management)

### 3.1 Feature inventory

#### 3.1.1 Investigation creation (POST /cases)

**What is implemented:**

- `CaseCreateRequest` schema validates: `target_taxon` non-empty, `observation_date` ≤ today, latitude −90..90, longitude −180..180, `detection_site_hyriv_id` > 0 (Pydantic), HYRIV_ID existence in loaded network (service-layer call to `hydrology_engine.get_reach`)
- Atomic transaction: site created first (commit=False), case created (commit=False), site.case_id linked, single `db.commit()` at the end — confirmed in `api/routes/cases.py` lines 52–77
- Rollback on any exception: `except Exception: db.rollback(); raise`
- `test_case_creation_integration.py` covers: happy path 201 + DB state, rollback on service failure, unknown HYRIV_ID rejected without writes, future date rejected by schema

**What is missing or partial:**

- M1.1 — No coordinate snapping. A user who enters precise GPS coordinates but the wrong HYRIV_ID will get a 404 error with no suggestion of the correct reach. **MISSING**
- M1.2 — Detection site is created with `ValidationStatus.NOT_VERIFIED` for all manual investigations. The Wigger demo uses `MATCHED`. There is no path for a user-created investigation to achieve `VERIFIED` or `MATCHED` status through the application UI. **PARTIAL**
- M1.3 — Metadata field `name` is stored in `cases.meta` but the schema has no dedicated `name` column. The field is accessed via `case.metadata?.name` everywhere in the frontend. This works but means `name` is not indexed or queryable. **PARTIAL** (acceptable for current scope but not production-ready)
- M1.4 — No PATCH endpoint for cases exists in `api/routes/cases.py`. `CaseService.update_case_status()` and `CaseRepository.update_case()` are implemented but not exposed. **MISSING** (service exists, route does not)

#### 3.1.2 Coordinate validation

**What is implemented:**

- Pydantic validators: `ge=-90, le=90` for latitude, `ge=-180, le=180` for longitude
- Future date rejected by `@field_validator("observation_date")`
- HYRIV_ID validated against loaded network (raises `ValueError` → caught by `except Exception` in route → 404 response)

**What is missing:**

- M1.5 — No validation that latitude/longitude actually places the point within a reasonable distance of any loaded river reach. A user could enter coordinates in Australia and HYRIV_ID from Switzerland and the request succeeds. **MISSING**

#### 3.1.3 River-reach identification

**What is implemented:**

- `hydrology_engine.get_reach(hyriv_id)` called before any DB write in `api/routes/cases.py`
- Uses the globally initialized engine from `api/dependencies.py` (via `Depends(get_hydrology_engine)`) — this is correct; the case route uses the startup engine, unlike the hydrology/sampling routes

**What is missing:**

- M1.6 — No nearest-reach lookup from coordinates. The only path from "I have GPS coordinates" to a valid HYRIV_ID is the user looking it up externally. **MISSING**

#### 3.1.4 eDNA replicate entry

**What is implemented:**

- Frontend form accepts one replicate result (Positive/Negative/Invalid)
- Stored as `evidence_type: "edna_observation"`, `value: {replicate_results: ["Positive"]}` via `POST /cases/{id}/evidence`
- `EvidenceService.add_evidence()` validates non-empty type, source, and value

**What is missing:**

- M1.7 — Only one replicate can be recorded at creation time. The domain model for follow-up samples tracks `replicate_count` and `positive_replicates` properly, but the initial observation form cannot record more than one. **PARTIAL**
- M1.8 — Initial observation evidence has `evidence_type: "edna_observation"` but no validated rule in the catalog applies to this type. It will always show as `UNKNOWN` in evidence assessment. This is technically correct behavior (no rule = UNKNOWN) but means the initial eDNA detection itself never contributes to hypothesis discrimination. **PARTIAL** (by design, documented in limitations)
- M1.9 — Assay metadata, controls status, collector source (all required for follow-up samples) are not collected at initial creation. Only a free-text "laboratory or assay metadata" textarea is provided. **PARTIAL**

#### 3.1.5 Follow-up sample registration

**What is implemented:**

- `POST /cases/{id}/follow-up-samples` fully implemented
- `FollowUpSampleService.create()` validates: case exists, exactly one of sampling_site_id or candidate_reference, replicate counts (0 ≤ positive ≤ total, total > 0), concentration ≥ 0 and unit required if supplied, HYRIV_ID exists in network, site belongs to case
- Atomic transaction: `FollowUpSampleModel` inserted, linked `EvidenceItemModel` created, `evidence_id` back-linked, `db.commit()`, `db.refresh()`, rollback in `except Exception`
- Frontend `FollowUpForm` collects all required fields; can target registered sites or generated candidate reaches
- Tests cover: happy path + evidence linkage, schema rejection of invalid measurements, wrong-case site rejection, invalid HYRIV_ID rejection

**What is missing:**

- M1.10 — `reanalysis_required: True` is hardcoded in `FollowUpSampleResponse`. The field is not computed from any actual state; it is always True. There is no mechanism to set it to False even after a reinvestigation run is completed. **DEFECTIVE** (value is hardcoded, not computed)
- M1.11 — `candidate_reference` format is free text (e.g. "HYRIV_ID:20450127"). There is no FK or validation that the referenced candidate actually exists in any GeneratedCandidateSnapshot. **PARTIAL**

#### 3.1.6 Database integrity

**What is implemented:**

- Circular FK between `cases.detection_site_id → sampling_sites.id` and `sampling_sites.case_id → cases.id` is handled by deferred commit: site is inserted (flush), case is inserted (flush), site.case_id is linked, single commit
- Rollback in `create_case` route on any exception: confirmed in `api/routes/cases.py`
- `test_case_creation_integration.py::test_failed_case_creation_rolls_back_detection_site` verifies zero rows in both tables after simulated failure
- Follow-up sample and evidence creation is atomic (both flush before commit, rollback in except)

**What is defective:**

- M1.12 — `SamplingRepository.create_site()` has `commit=True` as default. The route passes `commit=False` to defer to the single commit. However, `SamplingRepository.create_zone()` always commits immediately (`self.db.commit()`). If a zone creation is part of a larger transaction that later fails, the zone row is already committed. **DEFECTIVE** (low severity for current use but architecturally inconsistent)
- M1.13 — `EvidenceRepository.add_evidence()` always commits immediately. This means adding evidence from within a larger transaction (e.g. demo loading) is not atomic with the surrounding work. The demo loader calls `_ensure_wigger_evidence` after the main creation block, which is acceptable but the pattern is not consistent. **PARTIAL**

---

## Part 4 — Confirmed Architectural Problems

### P1 — HydrologyEngine rebuilt on every hydrology and sampling request

**Severity:** High (performance)  
**Files:**
- `backend/app/api/routes/hydrology.py` → `get_hydrology_service()` (lines 28–44)
- `backend/app/api/routes/sampling.py` → `get_sampling_service()` (lines 39–71)

Both functions call `WiggerPreflightLoader(config.PREFLIGHT_DATA_DIR)` and construct `HydrologyEngine(reaches, edges)` on every invocation. This reads two CSV files (49 rows + edges) and builds two adjacency dicts on every HTTP request. The startup engine in `api/dependencies.py` is not used by these routes.

**Impact:** Under any concurrent load, this multiplies I/O and graph construction. For a 49-reach graph it is fast, but the pattern will not scale if the network grows.

---

### P2 — DecisionTrace written in two commits

**Severity:** Medium (correctness risk)  
**File:** `backend/app/services/sampling_service.py` lines 96–116

`save_decision()` in `SamplingRepository` inserts `DecisionTraceModel` with empty arrays. `evaluate_sampling_candidates` then fetches the trace by decision_id, overwrites its fields, and commits again. Between the two commits the trace is empty. If the second commit fails, the trace remains empty and is never corrected.

---

### P3 — PATCH /cases route is missing despite service and repository support

**Severity:** Medium (missing feature)  
**File:** `backend/app/api/routes/cases.py`

`CaseService.update_case_status()` and `CaseRepository.update_case()` both exist and are tested (mocked). No route exposes them. The frontend cannot change a case's workflow status (ACTIVE → UNDER_REVIEW → COMPLETED) through the API.

---

### P4 — reanalysis_required is hardcoded True

**Severity:** Medium (misleading output)  
**File:** `backend/app/schemas/follow_up_samples.py` line 28

```python
reanalysis_required: bool = True
```

This field is never computed from any state. After a completed reinvestigation run, `reanalysis_required` still returns True for every sample. The Reports page does not display this field, but any API consumer will always see True regardless of actual state.

---

### P5 — No follow-up evidence interpretation rule

**Severity:** High (scientific workflow gap)  
**Files:** `backend/app/scientific/rules/catalog.py`, `backend/app/scientific/evidence/engine.py`

`follow_up_edna_sample` evidence always receives `EvidenceCompatibility.UNKNOWN` with `rule_id=None`. The reinvestigation trace explicitly records: "New follow-up sample recorded, but no validated interpretation rule currently allows this observation to alter source hypotheses." This means recording field results has zero effect on hypothesis states or sampling decisions. The workflow records the data but cannot act on it.

---

### P6 — One Health pathway exists only for one specific case identity

**Severity:** Medium (incomplete feature)  
**File:** `backend/app/services/one_health_service.py` lines 44–52

`_is_verified_fs_case()` requires exact match of taxon, station, date, and detection state. Any other case returns `pathways: []` with no explanation to the user.

---

### P7 — Candidate_reference is free text with no validation against stored candidates

**Severity:** Low  
**File:** `backend/app/services/follow_up_sample_service.py`, `backend/app/schemas/follow_up_samples.py`

When a follow-up sample references a generated candidate (not a registered site), `candidate_reference` is stored as an arbitrary string (e.g. `"HYRIV_ID:20450127"`). No FK exists to `generated_candidate_snapshots`. The HYRIV_ID is validated to exist in the network, but there is no check that it was actually generated as a candidate in the most recent run.

---

### P8 — create_zone always commits immediately

**Severity:** Low-Medium  
**File:** `backend/app/repositories/sampling.py` → `create_zone()` line 159

`create_zone()` always calls `self.db.commit()` with no `commit=False` option. If zone creation is ever part of a larger multi-step transaction, the zone will be committed independently. Compare with `create_site()` which accepts `commit=False`.

---

## Part 5 — Prioritized Implementation Plan

### Priority ordering rationale

1. Correctness defects first (P2, P4)
2. Missing mandatory routes that block the frontend workflow (P3)
3. Highest-impact scientific gap (P5)
4. Performance problem that will bite in production (P1)
5. UX improvements that reduce user friction (coordinate discovery, multiple replicates)
6. Incomplete features (P6, P7, P8)

---

### Priority 1 — Fix DecisionTrace double-commit (P2)

**Impact:** Correctness. An interrupted second commit leaves an empty trace.  
**File:** `backend/app/services/sampling_service.py`

**Change required:**  
Remove the `save_decision()` call (which creates the placeholder trace). Inline the `SamplingDecisionModel` creation, call `sampling_engine.create_decision_trace()` first, then create both `SamplingDecisionModel` and `DecisionTraceModel` and commit once.

Alternatively: change `SamplingRepository.save_decision()` to accept an optional pre-built trace dict and skip the placeholder, instead accepting the real trace content.

**Tests needed:**
- Unit: add to `test_services.py` — verify that if the second commit is never reached (mock raises after `save_decision`), no orphan decision row exists
- Integration: add to `test_case_creation_integration.py` or new `test_sampling_decision_integrity.py` — simulate a crash between the two commits (using a mock that raises on the second `.commit()`) and verify the trace is consistent

---

### Priority 2 — Expose PATCH /cases/{id} route (P3)

**Impact:** The workflow status field (`ACTIVE → UNDER_REVIEW → COMPLETED`) cannot be changed through the UI.  
**File:** `backend/app/api/routes/cases.py`

**Change required:**  
Add a `PATCH /cases/{case_id}` endpoint that accepts `{"status": "UNDER_REVIEW"}` (or a partial CaseUpdateRequest schema). Route calls `case_service.update_case_status()` which already exists.

**Schema change:** Add `CaseUpdateRequest` to `schemas/cases.py`:
```python
class CaseUpdateRequest(BaseModel):
    status: CaseStatus | None = None
    metadata: dict[str, Any] | None = None
```

**Tests needed:**
- Unit: add to `test_services.py` — verify status update propagates
- Integration: add to `test_case_creation_integration.py` — create case, PATCH status, verify DB row updated
- Browser: the Playwright test `desktop workflow` test could assert the workflow status column changes after a PATCH

---

### Priority 3 — Fix reanalysis_required (P4)

**Impact:** Misleading API output. All follow-up samples always report `reanalysis_required: True`.  
**File:** `backend/app/schemas/follow_up_samples.py`, `backend/app/repositories/follow_up_samples.py`

**Change required:**  
Either: (a) remove the field entirely if it is not computed, or (b) compute it from whether the sample's `created_at` is earlier than the `completed_at` of the most recent successful `InvestigationRunModel` for the case. Option (b) requires joining to `investigation_runs` in the follow-up response.

The simplest safe fix is (a) — remove the hardcoded field and add a note to the `FollowUpSampleResponse` that reanalysis state is visible through `GET /cases/{id}/investigation-runs`.

**Tests needed:**
- Add assertion to `test_follow_up_samples.py` that `reanalysis_required` is absent from the response (if removed) or equals the correct computed value

---

### Priority 4 — Use startup-initialized HydrologyEngine in all routes (P1)

**Impact:** Performance. Every hydrology/sampling request rebuilds the graph from disk.  
**Files:** `backend/app/api/routes/hydrology.py`, `backend/app/api/routes/sampling.py`, `backend/app/api/dependencies.py`

**Change required:**

In `api/dependencies.py`, add a `get_candidate_generator()` and `get_site_a_fraction()` dependency alongside the existing `get_hydrology_engine()`. These would be initialized once at startup using the same `WiggerPreflightLoader` call that already happens in `initialize_engines()`.

In `api/routes/hydrology.py`, replace `get_hydrology_service` with a factory that uses `Depends(get_hydrology_engine)` instead of constructing a new engine.

In `api/routes/sampling.py`, replace the local `get_sampling_service` factory with one that injects the startup engine.

**Tests needed:**
- Unit: `test_services.py` already mocks engines, no engine construction tests needed
- Integration: `test_case_creation_integration.py` already exercises the route-level engine — verify it still works after the refactor
- New: add a test that calls `GET /hydrology/reaches/{id}` twice and asserts the engine instance is the same object (using a module-level counter or a spy)

---

### Priority 5 — Add a follow-up evidence interpretation rule (P5)

**Impact:** The entire reinvestigation workflow is a no-op scientifically — recorded field samples cannot alter hypothesis states.  
**Files:** `backend/app/scientific/rules/catalog.py`, `backend/app/scientific/evidence/engine.py`

**Change required (to be verified with scientific reviewer before implementation):**

This is the highest-impact but also the most scientifically sensitive change. The implementation plan is:

1. Define the rule structure in `rules/catalog.py` — a `FOLLOW_UP_EDNA_DETECTION_RULE` that maps `follow_up_edna_sample` with `positive_replicates > 0` to `SUPPORTS` for zones where `can_contribute` is true
2. Add the rule application branch to `EvidenceCompatibilityEngineImpl.assess_evidence_for_zone()`
3. Confirm the `ConservativeHypothesisStateResolver` already handles SUPPORTS correctly (it does — tested in `test_v4_scientific_update.py`)

**Important constraint:** Do not implement until a scientific reviewer has confirmed the rule logic. The existing code correctly documents this gap; closing it requires domain input.

**Tests needed:**
- Unit: add to `tests/property/test_evidence_properties.py` — for any follow-up sample with positive_replicates > 0, the assessment of a zone whose root can_contribute to the sample site should return SUPPORTS
- Unit: add to `test_v4_scientific_update.py` — verify that `test_unknown_follow_up_preserves_zones_decision_and_trace` is updated once the rule is added (the test currently asserts no change, which should change after the rule is implemented)

---

### Priority 6 — Module 1 form improvements

#### 6a — Multiple replicates at creation (M1.7)

**File:** `frontend/src/pages/Investigations.jsx` → `NewInvestigationForm`

**Change required:**  
Add an "Add replicate" button that appends to `form.replicates[]`. Each replicate gets a select (Positive/Negative/Invalid). The evidence value becomes `{replicate_results: ["Positive", "Negative"]}`. No backend change needed — `EvidenceService` already accepts any JSON value.

**Tests needed:**
- Playwright: add to the desktop workflow test — add a second replicate, verify it appears in the evidence value on the workspace

#### 6b — Initial assay and controls metadata (M1.9)

**File:** `frontend/src/pages/Investigations.jsx` → `NewInvestigationForm`

**Change required:**  
Expand fieldset 5 to include optional assay name and controls status fields. Store in the evidence provenance dict. No backend schema change required.

**Tests needed:**
- Playwright: verify the fields appear and their values appear in the evidence record on the workspace

---

### Priority 7 — Fix create_zone to support deferred commit (P8)

**File:** `backend/app/repositories/sampling.py` → `create_zone()`

**Change required:**  
Add `commit: bool = True` parameter (identical to `create_site`). Callers that need atomicity can pass `commit=False`.

**Tests needed:**
- Unit: add to `test_sampling_repository.py` — verify that `create_zone(commit=False)` does not commit and the zone is rolled back if the session is closed without committing

---

## Part 6 — Module 1 File-Specific Changes Required

### Files to modify (no new files needed)

| File | Change | Priority |
|------|--------|---------|
| `backend/app/services/sampling_service.py` | Merge two-commit trace write into single transaction | 1 (P2) |
| `backend/app/api/routes/cases.py` | Add PATCH /{case_id} endpoint | 2 (P3) |
| `backend/app/schemas/cases.py` | Add CaseUpdateRequest schema | 2 (P3) |
| `backend/app/schemas/follow_up_samples.py` | Remove or compute reanalysis_required | 3 (P4) |
| `backend/app/api/dependencies.py` | Add candidate_generator and site_a_fraction to startup initialization | 4 (P1) |
| `backend/app/api/routes/hydrology.py` | Use Depends(get_hydrology_engine) instead of local loader | 4 (P1) |
| `backend/app/api/routes/sampling.py` | Use injected startup engines instead of per-request loader | 4 (P1) |
| `backend/app/repositories/sampling.py` | Add commit=False option to create_zone | 7 (P8) |
| `frontend/src/pages/Investigations.jsx` | Add second replicate field, optional assay/controls | 6 |

### New test files needed

| File | Purpose |
|------|---------|
| `backend/tests/unit/test_sampling_decision_integrity.py` | Verify single-commit trace write; verify orphan trace is impossible |
| `backend/tests/unit/test_case_patch.py` | Verify PATCH /cases/{id} updates status and metadata |

### Existing test files to extend

| File | Addition |
|------|---------|
| `backend/tests/unit/test_case_creation_integration.py` | Test PATCH /cases/{id} integration |
| `backend/tests/unit/test_follow_up_samples.py` | Assert reanalysis_required behavior after fix |
| `backend/tests/unit/test_services.py` | Add TestSamplingService trace integrity test |
| `frontend/tests/wigger.spec.js` | Add second replicate assertion; PATCH status workflow |

---

## Part 7 — Summary Classification Table

| Feature | Module | Status | Problem |
|---------|--------|--------|---------|
| POST /cases — atomic creation + rollback | M1 | COMPLETE | — |
| HYRIV_ID validation on creation | M1 | COMPLETE | — |
| Date validation (future date rejected) | M1 | COMPLETE | — |
| Coordinate range validation | M1 | COMPLETE | — |
| Detection site auto-created | M1 | COMPLETE | — |
| PATCH /cases/{id} status update | M1 | MISSING | Route not exposed (P3) |
| Coordinate-to-reach snapping | M1 | MISSING | No spatial lookup (M1.6) |
| Multiple replicates at creation | M1 | PARTIAL | Only 1 replicate in form (M1.7) |
| Assay/controls at creation | M1 | PARTIAL | Free text only (M1.9) |
| Follow-up sample registration | M1 | COMPLETE | — |
| Follow-up sample atomic evidence linkage | M1 | COMPLETE | — |
| reanalysis_required computation | M1 | DEFECTIVE | Always hardcoded True (P4) |
| candidate_reference validation | M1 | PARTIAL | Free text, no FK (P7) |
| create_zone deferred commit | M1 | PARTIAL | Always commits (P8) |
| HydrologyEngine (graph, upstream, distance) | M2 | COMPLETE | — |
| Evidence compatibility assessment | M2 | COMPLETE | Only topology rule (by design) |
| Evidence strength assessment | M2 | COMPLETE | — |
| Follow-up evidence interpretation rule | M2 | MISSING | No rule in catalog (P5) |
| Candidate generation (pair-separation) | M3 | COMPLETE | — |
| Sampling decision + trace | M3 | COMPLETE | Two-commit trace (P2) |
| Decision trace single-commit write | M3 | DEFECTIVE | Two commits (P2) |
| PATCH /cases status route | M3 | MISSING | — |
| Per-request engine rebuild | M3/M2 | DEFECTIVE | Performance (P1) |
| Reinvestigation versioned runs | M4 | COMPLETE | — |
| Hypothesis state resolution | M4 | COMPLETE | Never eliminates (by design, V4) |
| Before/after diff comparison | M4 | COMPLETE | — |
| Investigation run failure rollback | M4 | COMPLETE | — |
| Follow-up evidence → hypothesis change | M4 | MISSING | No rule (P5) |
| Wigger demo (idempotent) | M5 | COMPLETE | — |
| GBIF context | M5 | COMPLETE | — |
| ERA5 historical weather | M5 | COMPLETE | — |
| GHSL urbanization | M5 | MISSING | Explicitly unavailable |
| One Health pathway (Fs) | M5 | COMPLETE | Single case only (P6) |
| One Health pathway (general) | M5 | MISSING | Empty pathways for other taxa |
| Investigation report (all sections) | M5 | COMPLETE | — |
| PDF export | M5 | COMPLETE | — |
| Interactive map (MapLibre GL) | M3/M5 | COMPLETE | — |
| Authentication | All | MISSING | Not implemented |

---

*This is a read-only audit. No production code has been modified.*
