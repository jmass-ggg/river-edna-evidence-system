# FreshWater — Part 3: Scientific Validation and Final Project Assessment

**Assessment date:** 3 October 2026 (Asia/Kathmandu).  
**Scope:** Read-only audit of the current working tree, informed by [Part 1](FRESHWATER_PART1_ARCHITECTURE.md) and [Part 2](FRESHWATER_PART2_TEST_REPORT.md). This report is the only project deliverable created by this audit. Production code, rules, tests, reference artifacts, historical cases, and existing database records were not changed. Additional database probes used isolated SQLite sessions; no production database was queried or mutated.

## A. Executive summary

FreshWater is an explainable, Wigger-focused research prototype for organizing eDNA investigations and comparing follow-up sampling locations using directed river topology. Its strongest demonstrated capability is a reproducible chain from a real historical observation, through an explicitly bounded HydroRIVERS network, to an auditable **topology-only TIE**. It is not yet a validated biological source-identification system, an ecological-health assessment model, or a general-purpose adaptive sampling system.

The three broad scientific claims are **PARTIALLY VERIFIED**. Directed connectivity and pair-separation arithmetic are verified against the supplied network; biological interpretation, field effectiveness, and optimal sampling are not independently validated. Initial and follow-up eDNA observations are stored but have no interpretation rule that can change source hypotheses. Context adapters exist, but the frozen Wigger result contains no collected context evidence.

**Important corrections to the earlier reports:**

- Part 2 D7 is contradicted by independent traversal: Site D is downstream of Z2/Z3, not Z1. Its signature is `011`, score 2. **Preserve TIE: B, C, D.** Absence from the generated representative list does not imply zero score.
- Parts 1/2 describe all context providers as stubs. Current code implements GBIF and ERA5/Open-Meteo adapters; GHSL extraction remains unavailable. Mocked tests demonstrate adapter behavior, not successful live collection or environmental validation.
- Part 1's 17-table count is unsupported; the models define ten application tables, with Alembic's version table making eleven in Part 2's reported database inventory.
- Creating the detection site before the case does not itself establish an orphan defect: current creation commits both together and rolls back on failure. The rollback regression passes.
- Different registered and generated candidate sets are not intrinsically a scientific contradiction. Mixing their decisions in one latest-decision presentation without clear scope, and storing unresolvable generated-site IDs, are genuine workflow problems.
- A missing system-wide Python dependency is not evidence of a broken scientific algorithm. Environment and working-directory requirements must be explicit.

**Readiness:** suitable for a bounded, supervised Wigger demonstration after the high-priority workflow and claim-presentation issues are addressed; not established as ready for unrestricted multi-user deployment or autonomous scientific recommendations.

## B. Intended product versus actual implementation

The intended problem is real: DNA detected downstream does not by itself locate the organism that shed it. Researchers need to retain observations and provenance, identify hydrologically plausible investigation areas, compare where to sample next, and revise conclusions as evidence arrives. River transport and decay complicate source interpretation; Carraro's research explicitly models those processes, whereas FreshWater currently uses topology only. [Carraro et al., 2018](https://doi.org/10.1073/pnas.1813843115).

| Question | What exists today |
| --- | --- |
| What must a researcher provide? | Taxon, observation date, coordinates and a manually supplied HYRIV_ID within the loaded Wigger network; optionally one initial replicate result and free-text metadata. Source zones require labels, roots and member reach IDs. Follow-up registration requires a site/candidate reference, reach, datetime, replicate counts, assay, controls and collector provenance. |
| How is information processed? | Cases and evidence persist through repositories; a catalog assesses directed-connectivity evidence; a conservative resolver labels hypothesis states; graph traversal computes reachability and distance; candidate generation groups upstream reaches by root-reachability signature. |
| What meaningful outputs exist? | Case-specific network overlays, per-evidence compatibility/reasons, topology signatures, distinguished hypothesis pairs, network distances, decision statuses and traces, follow-up records, versioned run snapshots, and printable reports. |
| What decisions can users support? | Select hydrologically informative areas for expert review, compare topological alternatives, recognize unresolved ties and missing validation, and plan additional measurements. Outputs do not establish a biological source, local organism presence, abundance, disease, or field-optimal sampling. |
| What is incomplete? | General network ingestion, coordinate/reach verification in the creation workflow, comprehensive source-zone validation, biological evidence interpretation, field constraints, and meaningful adaptive changes following positive/negative samples. |

The actual user is a freshwater/eDNA researcher or GIS-capable monitoring analyst, and secondarily an educator or demonstration reviewer. Manual reach IDs and zone definitions make the current interface unsuitable as a self-service citizen-science instrument. A new case does not inherit the Wigger scientific investigation merely because it shares its reach.

Evidence: `frontend/src/pages/Investigations.jsx`, `InvestigationWorkspace.jsx`; `backend/app/api/routes/{cases,sampling,evidence,follow_up_samples}.py`; `backend/app/services/{sampling_service,investigation_service,follow_up_sample_service}.py`.

## C. Scientific claim verification

Here **VERIFIED** means established within the expressly stated dataset/method boundary, not independently field-validated. **PARTIALLY VERIFIED** means a narrower component works but the broad claim is not established. **UNVERIFIED** means insufficient independent evidence; **CONTRADICTED** means contrary reproducible evidence exists. A rule's own `VERIFIED` label is not external scientific endorsement.

### Claim 1 — Evidence assessment: PARTIALLY VERIFIED

`scientific/evidence/engine.py` and `scientific/rules/catalog.py` implement one compatibility rule, `hydrorivers.directed_contribution.v1`, plus a separate connectivity-strength rule. Complete, accepted-status connectivity evidence supports or contradicts a matching zone root; evidence targeting another root is neutral; missing/unverified or unsupported evidence remains unknown. The resolver handles support, conflict, weakening and unknown states. It has no validated elimination criterion.

Evidence IDs, source, provenance, rule version, rationale and limitations accompany assessments. Strength assesses the connectivity claim, not biological occurrence probability. Historical concentration, initial `edna_observation`, follow-up `follow_up_edna_sample`, occurrence context and weather context do not acquire biological meaning merely by being stored: their compatibility remains UNKNOWN and their strength UNASSESSED.

Follow-up replicate counts are structurally validated (`0 ≤ positive_replicates ≤ replicate_count`, positive total), and samples link atomically to evidence. There is no assay sensitivity/specificity model, replicate-consistency inference, contamination interpretation, or validated positive/negative updating rule. Initial input supports only one replicate dropdown. The historical MATLAB observation index 4 is a time-series observation index, **not four laboratory replicates**.

The rules explicitly distinguish detection from confirmed organism presence and hydrological support from biological proof. This conservative boundary is scientifically preferable to invented certainty, but it means the broad claim of assessing uncertain detections using all available evidence is incomplete.

**Trust boundary:** the compatibility engine reads the submitted `can_contribute` boolean and validation-status strings; it does not independently recompute connectivity or verify that the supplied sampling reach is the case's detection reach. The demo computes its connectivity evidence from the graph, but arbitrary API evidence is not independently certified. Provenance records assertions; it does not authenticate them. This is a source-confirmed credibility limitation for researcher-entered evidence.

Evidence: `test_v3_scientific_boundaries.py`, `test_v4_scientific_update.py`, `test_follow_up_samples.py`, `test_context_infrastructure.py` passed in this audit. No biological prediction accuracy was measured.

### Claim 2 — Hydrological source investigation: PARTIALLY VERIFIED

The narrower claim, **directed connectivity and network-length calculations within the supplied Wigger graph**, is VERIFIED. An independent successor walk using CSV `NEXT_DOWN`, rather than the application's traversal function, agreed with `can_contribute` for all **2,401 ordered pairs across 49 reaches**. Independent length summation reproduced the B/C/D distances in section D. GeoJSON declares EPSG:4326.

The three frozen zones are disjoint reach sets of 3, 21 and 11 members. Every member exists in the graph and reaches its corresponding root. These are mapped river segments, not validated organism-distribution polygons or complete terrestrial catchment boundaries. The decision criterion represents each zone by its root, rather than modeling source positions throughout its members. That assumption needs review before extending the method to arbitrary zones or interior sampling locations.

The application does not discover the true source. Demo hypotheses are preconfigured; new hypotheses are entered manually. The zone endpoint checks root existence but accepts invalid member IDs and caller-provided VERIFIED status (reproduced in section H). Runtime network coverage is limited to the supplied Wigger subset. General coordinates are range-checked but not matched to the supplied reach.

The preflight report documents S1's HydroRIVERS match and Swiss hydrography cross-check; this audit independently checked the local network consistency, not the original external Swiss query or raw continental extraction. Connectivity remains a necessary represented-network relationship, not proof of eDNA transport or biological origin.

### Claim 3 — Follow-up sampling decisions: PARTIALLY VERIFIED

The narrower claim, **deterministic comparison under the implemented binary topology criterion**, is VERIFIED. `CandidateSiteGenerator` enumerates upstream reaches, excludes the detection reach, groups by root-reachability signature, discards zero-score groups and selects the nearest-to-detection representative in each useful class. Distance is a representative-selection convention, not an ecological preference among tied classes.

For `n` hypotheses and `r` reachable roots, `r × (n − r)` counts separated unordered pairs. With three roots, the maximum is 2 of 3 pairs. This is neither expected information gain nor a probability of detection. The engine returns RECOMMEND for one strict winner, TIE for equal maxima, ABSTAIN for valid non-discriminating comparisons, and INSUFFICIENT_DATA for unavailable evaluations or incomplete scientific state. A completely empty generated set returns INSUFFICIENT_DATA; not every non-discrimination situation takes the same API path.

Under an **idealized single-source, perfectly informative binary observation model**, a result at B could distinguish Z2 from Z1/Z3; C distinguishes Z3 from Z1/Z2; D distinguishes Z1 from Z2/Z3. Actual positive/negative assays cannot be equated with these bits without transport, persistence, detection error, mixture and assay assumptions. The implemented follow-up pathway deliberately does not make that inference. Positive and negative records can be retained and reviewed, but do not currently resolve hypotheses or improve the sampling recommendation.

No independent field experiment establishes optimality, source-identification accuracy, sample reduction or cost savings. The two candidate scopes and unresolved recommendation identifiers further limit practical use; they do not justify changing the baseline arithmetic.

## D. Wigger case-study assessment

### Observation and geography

The source extraction/regressions identify Carraro H001, *Fredericella sultana*, station S1, observation 4, **2014-06-25**, concentration **1.2983219767633366e-17 mol/L**, state DETECTED. Original LV03 coordinates are `(634537.17, 240447.56)`; the retained historical WGS84 location is latitude `47.31400039098192`, longitude `7.895400745863826`.

The mapped detection reach is **20446064**. The preflight match records a 64.8136 m projection offset and fraction `0.8574012088` along the upstream-to-downstream reach. Historical coordinates and snapped network coordinates are separate. B/C/D are proposed counterfactual sampling sites, not invented historical assay results. The application does not run Carraro's transport/abundance model. The research publication and FreshWater therefore provide different kinds of inference. [Carraro et al., 2018](https://doi.org/10.1073/pnas.1813843115).

Sources: `data_preflight/raw/carraro/{eDNA_data.mat,RUN_MODEL.m}`, `data_preflight/outputs/{site_a.json,site_a_snap_validation.json,FINAL_REPORT.md,candidate_sampling_sites.csv}`, and `test_carraro_validation.py`.

### Evidence, hypotheses and comparisons

The baseline has one historical observation and three graph-derived connectivity evidence items. Each zone gets **one SUPPORTS, two NEUTRAL, one UNKNOWN**, not biological confirmation. All three roots can reach A; no conflicting biological observation is established by this baseline. Missing environmental evidence is not evidence of absence.

| Zone | Root | Member count | Relation to A |
| --- | ---: | ---: | --- |
| Z1 | 20447392 | 3 | Contributes topologically |
| Z2 | 20450127 | 21 | Contributes topologically |
| Z3 | 20451169 | 11 | Contributes topologically |

| Registered site | Reach | Z1/Z2/Z3 signature | Separated pairs | Distance to snapped A |
| --- | ---: | --- | --- | ---: |
| A | 20446064 | 111 | None | 0 km |
| B | 20450127 | 010 | Z1–Z2, Z2–Z3 | 19.225939 km |
| C | 20451169 | 001 | Z1–Z3, Z2–Z3 | 23.935939 km |
| D | 20448315 | 011 | Z1–Z2, Z1–Z3 | 10.940939 km |

Z1 joins farther downstream than D; “shared trunk” means shared by **Z2 and Z3**. Each B/C/D score is 2. The direct registered-site decision correctly remains **TIE: B, C, D**. The current route includes registered case sites, including A; A's zero score does not make it a winner.

Generated representatives are a separate comparison:

| Reach | Signature | Score | Distance to snapped A |
| ---: | --- | ---: | ---: |
| 20451169 | 001 | 2 | 23.935939 km |
| 20450127 | 010 | 2 | 19.225939 km |
| 20446568 | 011 | 2 | 2.285939 km |
| 20447392 | 100 | 2 | 3.585939 km |

D is represented by a nearer member of its `011` equivalence class. Reinvestigation evaluates these four generated representatives and also returns TIE. That result must not be described as four registered Wigger sites. An isolated reinvestigation reproduced four recommended UUIDs with **zero matching `sampling_sites` rows**.

### Follow-up and levels of validation

Follow-up registration persists samples and linked evidence. Existing tests verify that unsupported follow-up evidence leaves hypotheses and substantive decisions unchanged, with an explicit limitation in the trace. Repeated runs preserve snapshots; this is versioned bookkeeping, not demonstrated adaptive biological inference.

| Verification level | Established result |
| --- | --- |
| Reproducibility | Repeated isolated Wigger loading/evaluation is idempotent and retains the baseline TIE; regression passed. |
| Internal consistency | Independent graph traversal, zone checks, pair arithmetic and distance summation agree. |
| Historical agreement | Source extraction preserves S1 and the source series; station inventory test reproduces 15 stations and 301 observations per species. |
| Limited historical overlap | Stored station crosswalk and the rerun scope audit identify S14 at B's reach, status SUPPORTED, with same-date Fs detection `1.3338877637558446e-17 mol/L`. This is not a FreshWater-designed follow-up experiment. |
| Independent scientific validation | Not established for true source location, counterfactual outcomes, sampling effectiveness or ecological/health impact. |

The S14 mapping still requires independent watercourse confirmation. Historical detections do not establish negative outcomes at unobserved sites or identify which proposed zone contains the biological source. The source paper's existence does not validate FreshWater's new decision criterion.

## E. Urban freshwater and One Health alignment

Current context routes instantiate a GBIF occurrence-search adapter and an Open-Meteo archive adapter pinned to ERA5. Weather handling retains dates, units, grid coordinates, source resolution, retrieval provenance and missingness; mocked route tests passed. ERA5 air-temperature and precipitation estimates are not site-measured stream temperature or hydrological transport observations. GBIF presence records do not prove current local occupancy. Its query uses a bounding box around the requested radius and a limited result set, not a complete circular-buffer inventory.

GHSL built-up raster provisioning/extraction is explicitly unavailable. No demonstrated Wigger pollution, nutrient, habitat-condition or urban-stressor evidence drives the scientific decision. The deterministic baseline has zero collected context records. Successful live GBIF/weather collection was not tested here; no synthetic fixture values are represented as real Wigger observations. Context remains uninterpreted by the scientific rules.

`one_health_service.py` constructs a narrowly gated Fs/S1/date pathway. The host relationship between *F. sultana* and *T. bryosalmonae* is supported by published research; this supports relevance for further fish-health monitoring, not proof of infection in this case. [Morris and Adams, 2007](https://pubmed.ncbi.nlm.nih.gov/17205353/). The repository additionally cites [Sudhagar et al., 2020](https://doi.org/10.3390/pathogens9010016); its full text was not independently reviewed in this audit.

The service explicitly leaves parasite presence, fish-disease status and direct human-health impact unknown. Its environmental-context claim is triggered by evidence type rather than a full validation of weather contents, and its pathway gate relies on case metadata; these labels should not be treated as authenticated observations. Other cases return no pathway. No evidence establishes improved ecosystem health, human health, community outcomes or conservation effectiveness.

For researchers and monitoring managers, the present value is transparent planning and communication. A general urban-health platform, citizen-data integration, biodiversity condition index and predictive early-warning service remain proposed applications.

## F. Practical research value

| Benefit | Evidence level and boundary |
| --- | --- |
| Organize observations and provenance | Demonstrated by persistence, evidence linkage and Wigger workflow tests; not user-study validated. |
| Reproduce an investigation | Demonstrated for frozen Wigger data and deterministic rules; not proof that arbitrary inputs are correct. |
| Explain decisions | Rule IDs, signatures, reasons and assumptions exist. Direct decisions use topology rather than observation evidence; reinvestigation's unresolvable IDs weaken end-to-end traceability. |
| Identify upstream investigation areas | Verified within the 49-reach graph; biological source localization unverified. |
| Compare candidate locations | Arithmetic verified; four generated representatives and three registered sites remain tied within their respective scopes. |
| Save analyst time or field/laboratory costs | Unmeasured. `benchmark_summary.json` reports NO_MEASUREMENTS; the measurement template is empty. |
| Update conclusions from samples | Recording and rerunning demonstrated; biological interpretation absent. |

A reproducible simple baseline selects the nearest **generated representative**, reach 20446568: it also scores 2. A random selection among the same four representatives always scores 2. Thus this restricted Wigger comparison shows **no pair-score advantage** for selecting a maximum-score representative over those baselines. This is a comparison within an already filtered candidate set, not evidence about random sampling anywhere in the basin. Among registered B/C/D, nearest D also scores 2. None of these observations supports travel-cost savings or field superiority.

`scientific_validation_outputs/sampling_execution_benchmark.json` records a pre-existing synthetic benchmark of 100 repeated runs, with medians about 0.619 ms for generation and 0.510 ms for decision evaluation. These are reported software timings on synthetic graph inputs, not newly measured timings in this audit, analyst workflow duration, or ecological performance. `test_benchmark_sampling.py` passed; that validates benchmark handling, not the stored timing values on this machine today.

Sources: `scripts/{validate_sampling,benchmark_sampling}.py`, `scientific_validation_outputs/{sampling_audit,benchmark_summary,sampling_execution_benchmark}.json`, `test_sampling_scope_audit.py`, and [the existing scientific assessment](SCIENTIFIC_VALIDATION_REPORT.md).

## G. Consolidated functional and architectural findings

Part 1 provides the layer map; Part 2 reports 178 backend passes and 18 Playwright passes with six intentional skips. Those are **prior report results**, not fresh full-suite results. Current source inspection and focused tests take precedence where those reports conflict.

| Major feature / intended behavior | Actual implementation and functional evidence | Scientific status / outstanding boundary |
| --- | --- | --- |
| Create an investigation | Atomic case/site creation; current HTTP probe 201; creation/rollback tests pass | Manual network assignment; outside-network reaches rejected; no coordinate matching |
| Display the case geography | Current isolated GET map 200, 49 reaches, one own detection site, zero source overlays | Real dataset geometry returned; browser rendering not rerun; request errors silently discarded |
| Preserve case isolation | New case beside a loaded demo had empty evidence/zones/candidates and null decision | No copying of baseline findings observed |
| Ingest and assess evidence | Storage/provenance and connectivity catalog implemented; boundary tests pass | Biological/replicate/environmental inference absent; submitted topology assertions trusted |
| Collect environmental context | Real GBIF/ERA5 adapters with mocked tests; GHSL unavailable | No live collection validation or evidence-driven Wigger result |
| Define source zones | Manual registration and frozen demo zones | Arbitrary member validity/root consistency not enforced |
| Trace hydrology | Directed graph, upstream/downstream paths, contribution and network distance | Verified locally; finite network and reach-resolution assumptions |
| Generate candidates | Signature equivalence classes and nearest representative | Verified topology heuristic; no field accessibility or detection model |
| Evaluate sampling | Registered-site path and generated-site reinvestigation path | Both internally coherent; scope differs; generated IDs unresolved |
| Register follow-up | Structural validation and atomic linked evidence; tests pass | Assay/control text is recorded, not scientifically interpreted |
| Reinvestigate | Versioned snapshots and substantive change comparison; tests pass | Unsupported observations cannot change source inference; old-run comparison concern below |
| Communicate One Health | Evidence-labelled Wigger pathway | Narrow gate, no demonstrated health outcome; generic cases unsupported |
| Browse/report | React maps, tables, reports and browser print; Part 2 browser evidence | Sites page is demo-scoped; generated locations not map markers; current PDF quality not rechecked |
| Operate/deploy | FastAPI, SQLAlchemy, migrations, React/Vite; no authentication in inspected API | Clean PostgreSQL migration/deployment, multi-user isolation and operational resilience not verified |

### Additional verification performed for Part 3

1. **89 selected tests passed, 141 warnings**, in 1.86 seconds of pytest-reported execution, using the existing virtualenv from `backend/`. The selected files were `test_wigger_reproducible_workflow`, `test_wigger_scientific_regression`, `test_hydrology_engine`, `test_carraro_validation`, `test_carraro_v4_extraction`, `test_context_infrastructure`, `test_follow_up_samples`, `test_investigation_runs`, `test_v3_scientific_boundaries`, `test_v4_scientific_update`, `test_sampling_scope_audit`, `test_benchmark_sampling`, `test_case_creation_integration`, and `test_wigger_map_api`, all under `tests/unit/` with `.py` suffixes.
2. Execution used `PYTHONDONTWRITEBYTECODE=1`, `DATABASE_URL=sqlite:///<unique temporary directory>/audit.sqlite`, `../venv/bin/python -m pytest -p no:cacheprovider <selected files> -q --tb=short`. Existing database fixtures create separate in-memory sessions. No production database was used.
3. Independent CSV successor traversal checked 2,401 reach pairs; zone membership/disjointness and B/C/D distance summations passed. These are independent implementations over the same reference data, not independent field evidence.
4. Isolated HTTP probes: new-case creation 201; map 200; empty evidence/zones/candidates and null decision; invalid zone-member creation 201. A demo reinvestigation produced TIE with four unresolvable site IDs.
5. An in-memory JavaScript probe loaded the API module with mocked fetch responses: a map HTTP 500 with explicit detail became `bundle.map = null`, with no Error retained. No frontend source was edited.

**Unsuccessful setup attempts, retained for transparency:** an in-memory application DATABASE_URL caused seven collection errors because `max_overflow` is incompatible with that SQLite pool. Switching to file-backed isolated SQLite allowed collection, but running from repository root produced 61 passes, one failure and 27 errors because several tests resolve `../data_preflight` relative to the working directory. Rerunning the same selection from `backend/` passed all 89. These were setup/path failures, not demonstrated scientific regressions. Warnings concern deprecated UTC datetime calls and SQLite teardown of circular foreign keys.

**Not completed:** full current backend/property suite, new browser/visual/PDF run, production database verification, clean PostgreSQL migration, live environmental API collection, raw continental dataset re-extraction, independent Swiss hydrography revalidation, scientist user study, prospective field validation, or confirmation of the team's registered hackathon track/submission assets. The earlier repair task was superseded by this read-only audit; no map-root-cause fix is claimed. The reported map outage was not reproduced against the isolated current endpoint.

## H. Confirmed defects, gaps, and limitations

Severity reflects impact on the current prototype and its advertised workflow. No CRITICAL failure was reproduced within the frozen Wigger baseline. Public deployment and biological automation remain gated by evidence and controls, rather than being implied safe by passing tests.

| ID / severity / type | Issue and supporting evidence | Affected claim or workflow | Recommended correction and expected verification |
| --- | --- | --- | --- |
| H1 — HIGH — confirmed defect | `frontend/src/services/api.js:loadCaseBundle` converts rejected subordinate requests to null; trace errors are also swallowed. Mocked map 500 reproduced information loss. Workspace treats null as unavailable geography/empty scientific state. | Map and investigation trustworthiness | Retain endpoint-specific errors and display them distinctly from valid empty results. Verify map/evidence/decision 500, network failure, valid empty response and recovery. Diagnose any actual deployed map failure from its exposed error; do not infer a backend cause from the placeholder. |
| H2 — HIGH — confirmed defect | `investigation_service.py:reinvestigate` persists run-specific transient UUIDs as recommended sites without site rows; isolated probe found 0/4 resolvable. Reports resolve recommendations against registered sites. | Actionable follow-up and audit references | Persist an explicit candidate reference or registered site mapping with decision scope. Verify each recommendation resolves to its reach, coordinates and run, including report and follow-up selection. |
| H3 — HIGH — confirmed workflow inconsistency | Direct decision evaluates registered sites; reinvestigation evaluates generated representatives; both populate latest decision. Workspace displays generated comparisons beside a possibly registered-site decision. | Sampling interpretation | Label and preserve candidate scope through API, trace and UI. Verify both Wigger TIE sets are explained and new cases cannot imply evaluation of a different candidate set. Do not merge scopes by changing the scientific baseline. |
| H4 — HIGH — confirmed validation defect | `sampling.py:create_candidate_zone` checks root only. An isolated POST with root 20450127, member `[999999999]`, VERIFIED returned 201. Repository/schema do not establish membership connectivity or verification provenance. | Geographic integrity / claim 2 | Validate known members, root membership and defined zone topology; establish controlled verification. Test unknown/disconnected/root-excluded members and ensure overlays and scoring use a consistent accepted hypothesis. |
| H5 — HIGH — source-confirmed trust gap | Evidence engine trusts submitted topology booleans/status; case creation accepts coordinates without reach matching. Rule applicability does not certify case-site correspondence. | Claims 1–2 | Recompute/validate derived connectivity against the case and graph; distinguish asserted from independently checked geography. Verify contradictory payloads and mismatched coordinates/sites cannot acquire unwarranted scientific verification. |
| H6 — HIGH for general workflow — confirmed limitation | New UI sites/zones are NOT_VERIFIED, no verification action is exposed, initial/returned assays have no interpretation rule, and generated candidates are not the direct decision's site set. | End-to-end new investigations | Provide an explicit expert validation workflow and honest scope/next-step messaging. Defer new biological rules until reviewed and validated. Verify a new case reaches an interpretable state without borrowed demo evidence or false readiness labels. |
| H7 — MEDIUM — source-confirmed geographic assumption | Sampling and investigation services receive Wigger S1's fixed fraction from dependencies and reuse it for other detection reaches. | Distances and representative selection outside S1 | Store/derive a case-specific verified fraction or report distance unavailable. Test another detection reach and two positions along it with independently calculated distances. Frozen S1 distances must remain unchanged. |
| H8 — MEDIUM — confirmed capability gap | No initial/follow-up eDNA, weather or occurrence interpretation rule; GHSL unavailable; baseline has no context records. | Evidence integration, adaptation and urban claims | State limitations prominently; add reviewed rules/data only with provenance and scientific validation. Verify unknown stays unknown and no fabricated health/source claim appears. |
| H9 — MEDIUM — source-confirmed observability gap | Context collection persists only SUCCESS/PARTIAL results; workspace discards returned collection outcomes then reloads stored context. UNAVAILABLE/ERROR outcomes can disappear. | Missing-evidence transparency | Preserve or display attempted-provider outcomes. Verify a failed provider remains visibly unavailable after reload rather than vanishing. |
| H10 — MEDIUM — source-confirmed operational limitations | No authentication/authorization in inspected API; repeated sampling requests reload CSV/GeoJSON and graph; map loads geometry again. | Deployment and scalability | Gate public writes and profile intended load; cache immutable data with explicit version invalidation if warranted. Verify case access boundaries and measured latency. No present performance failure or attack is claimed. |
| H11 — LOW — confirmed usability/maintenance gaps | Demo-only Sites page; no generated candidate map markers; duplicate repository converters; root-CWD tests fail; SQLite memory URL fails at import. | General use and reproducibility | Clarify demo scope, improve candidate display and setup documentation; remove duplicates later. Verify non-demo navigation and documented clean-environment test command. |

**Unverified concerns requiring targeted checks, not established outcome defects:** `InvestigationService.detail()` obtains the latest completed run excluding the requested run, without restricting it to earlier runs; old-run comparisons may therefore use a future run. Test three chronologically distinct runs. Direct decision persistence commits an initial placeholder trace before the service replaces it with detailed content; failure between commits could leave an incomplete trace. Test injected failure without touching historical records. Arbitrary GBIF radius/temporal interpretation and externally collected weather metadata need domain review before broader claims.

**Withdrawn or narrowed earlier findings:** do not “fix” Site D out of the TIE; do not call all context providers stubs; do not treat preflight reload as measured performance failure; do not equate a single-case One Health pathway with a general health inference engine; do not claim orphan creation based only on insertion order. The current map HTTP probe succeeds, so a specific backend map failure remains unconfirmed here.

## I. Prioritized recommendations

### Before submission or a general-workflow demonstration

1. Correct the scientific narrative and prior-report contradictions: retain Site D, state candidate scope, distinguish topology verification from biological validation, and disclose absent assay updating and absent measured benefit.
2. Resolve H1–H4 for any demonstration that creates cases, edits zones, or reinvestigates. Show actual errors, meaningful recommendation references, clear candidate scopes and valid zone membership. Confirm behavior with isolated failure-path and browser tests.
3. Address or visibly constrain H5–H7: only claim validated geography where it was checked; do not label arbitrary inputs verified; do not use S1-specific distances as verified measurements for another case.
4. Make unavailable context and unsupported stages visible. Demonstrate a repeatable Wigger chain and preserved TIE without importing its evidence into new cases.
5. Confirm the team's chosen track, public repository/startup instructions, prototype access and required demonstration assets. A clean deployment and current browser run are still needed; passing local selected tests does not substitute for them.

### Safe to defer beyond the hackathon, with accurate scope disclosure

Multi-basin ingestion, map-assisted source delineation, GHSL processing, pollution/nutrient/habitat integrations, field-access optimization, sophisticated report export, larger-scale performance tuning, and additional One Health pathways can be deferred. Biological assay/transport/decay and adaptive sampling models require scientific review and independent validation, not a rushed rule addition to make the demo change its answer. Authentication and operational controls can be deferred only for a controlled local demonstration, not an unrestricted public writable deployment.

A future evaluation should predefine source ground truth, assay/error assumptions, sampling budget and baseline strategies, then measure analyst time, samples, cost and source recovery on independent cases. No expected percentage improvement is justified today.

## J. Final project and hackathon-readiness assessment

1. **What is FreshWater today?** A research prototype combining case management, Wigger HydroRIVERS topology, conservative evidence labels, candidate comparisons and explainable reports.
2. **What problem does it demonstrably solve?** It makes a bounded downstream-detection investigation reproducible and makes alternative upstream sampling locations comparable under one transparent topology criterion.
3. **Which major features work?** Isolated case/site persistence, demo idempotency, source extraction, graph operations, Wigger candidate arithmetic, traces, follow-up recording, and versioned runs pass focused tests. Prior Part 2 provides browser/report evidence; it was not rerun here.
4. **Which scientific claims are validated?** The local graph relationships and topology-only score/decision consistency are verified. The three broader claims remain PARTIALLY VERIFIED. Biological-source accuracy, effective adaptive sampling and health outcomes are UNVERIFIED.
5. **Strongest demonstrated capability?** An auditable historical Wigger workflow that preserves the observation, records assumptions and reproducibly abstains from choosing a unique winner when B/C/D tie.
6. **Remaining limits?** Limited geography, trusted input assertions, incomplete zone validation, unsupported biological updates, scope/identifier defects, incomplete environmental coverage and no prospective field validation.
7. **Researcher usefulness?** Useful as an expert-supervised evidence organizer and hypothesis-comparison aid within known geography; insufficient as a stand-alone scientific conclusion or field sampling prescription.
8. **Hackathon alignment?** The official event emphasizes urban freshwater monitoring, citizen/environmental data and One Health. The closest demonstrated fit is **Track 2: Data-to-Insight**; explainable checks also overlap Track 3. This is an assessment of fit, **not confirmation of the team's selected track**, which was not established from the supplied reports or inspected project descriptions. Citizen-data integration, stream-health interpretation and measured urban impact remain gaps. [Official hackathon overview and tracks](https://oneaquahealth-ieee-hackathon.devpost.com/).
9. **What must be corrected before submission?** Scientific overstatements and contradictory audit claims, and the high-priority defects exercised by the submitted demo; submission artifacts and track choice must be verified. Do not claim general investigation readiness based on the Wigger path alone.
10. **What can wait?** Broader geographic/context coverage and advanced models can wait under a clearly bounded prototype claim. Independent validation should remain a planned study, not an invented result.

| Readiness dimension | Final assessment |
| --- | --- |
| Software readiness | Functional core demonstrated; important input-validation and recommendation-reference defects remain. Full current deployment verification incomplete. |
| Scientific validity | Internally consistent, explicitly bounded topology reasoning; broader biological and field claims unvalidated. |
| Demonstration readiness | Conditional for a supervised Wigger demonstration, preserving TIE and disclosing scope. Current browser/demo packaging requires confirmation. |
| Real-world deployment readiness | Not established: access control, general geography, operational verification and prospective scientific validation are outstanding. |

The defensible submission claim is: **FreshWater demonstrates reproducible, explainable topology-based investigation support for a historical freshwater eDNA case. It helps researchers compare hypotheses and plan further inquiry while retaining uncertainty.** It does not yet demonstrate that it finds the biological source, selects the best field site, reduces monitoring costs, or improves ecosystem or human health.

**Audit complete. No recommended implementation changes were started.**
