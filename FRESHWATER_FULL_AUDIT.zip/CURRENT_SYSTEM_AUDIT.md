# FreshWater eDNA Evidence Investigator — Architecture Report

**Audit type:** Implementation-based read-only code audit  
**Date:** 2026-10-02  
**Files inspected:** 65 source files across backend, frontend, tests, data pipeline, and configuration

---

## 1. Project Overview

### What it is

FreshWater is a full-stack scientific investigation workflow system for freshwater environmental DNA (eDNA) detections. It answers a specific real-world problem: when eDNA of a species is detected at a river station, where upstream did it come from, and where should field teams sample next to distinguish between competing source hypotheses?

### Real-world problem it solves

An eDNA detection at a river station is ambiguous — the organism could have originated from any upstream tributary. Without a structured workflow, investigators cannot tell which upstream area is the most likely source, or which follow-up sampling location would most efficiently discriminate between competing upstream source zones.

### Intended users

- Freshwater ecologists and eDNA laboratory scientists
- River conservation managers
- Scientific teams investigating parasite or biodiversity incidents in river catchments

### Primary features (as actually implemented)

1. Create and manage eDNA investigation cases linked to validated HydroRIVERS reaches
2. Load the validated Wigger River / Carraro H001 historical case as a demonstration
3. Register candidate source zones (upstream regions as hypotheses)
4. Evaluate evidence (hydrological connectivity, follow-up samples, environmental context) against each zone hypothesis
5. Generate topology-based candidate sampling sites — one representative per unique reachability signature
6. Compute a sampling decision (RECOMMEND / TIE / ABSTAIN / INSUFFICIENT_DATA) using pair-separation scoring
7. Collect environmental context (GBIF occurrences, ERA5 historical weather, urbanization placeholder)
8. Generate a One Health relevance pathway (implemented only for the *Fredericella sultana* / *Tetracapsuloides bryosalmonae* relationship)
9. Display all of the above in a React SPA with an interactive MapLibre GL map
10. Export a printable/PDF investigation report via the browser print API

### Current implementation status

The system is a functionally verified research prototype. The scientific workflow is end-to-end operational for the Wigger demonstration case. Prospective real-world field validation has not been performed. See Section 8 for a feature-by-feature classification.

---

## 2. User Inputs

### 2.1 New investigation form (`frontend/src/pages/Investigations.jsx → NewInvestigationForm`)

| Input | Required | Validation | Stored where |
|-------|----------|-----------|--------------|
| Investigation name | Yes | Non-empty string | `cases.meta.name` |
| Target species (scientific name) | Yes | Non-empty string | `cases.target_taxon` |
| Latitude | Yes | −90 to 90 decimal degrees | `sampling_sites.latitude` (detection site) |
| Longitude | Yes | −180 to 180 decimal degrees | `sampling_sites.longitude` (detection site) |
| HydroRIVERS reach ID (HYRIV_ID) | Yes | Integer; validated against loaded network on backend | `sampling_sites.hyriv_id` |
| Observation date | Yes | Date ≤ today | `cases.observation_date` |
| Replicate 1 result | Optional | Dropdown: Positive / Negative / Invalid | `evidence_items` as `edna_observation` |
| Laboratory/assay metadata | Optional | Free text | `cases.metadata` |

The frontend validates client-side before submission. The backend re-validates independently (reach existence, date bounds, coordinate ranges, taxon non-empty).

### 2.2 Source hypothesis (zone) registration (`InvestigationWorkspace.jsx → ZoneForm`)

| Input | Required | Validation |
|-------|----------|-----------|
| Hypothesis label (e.g. "Z1") | Yes | Non-empty string |
| Root HydroRIVERS reach ID | Yes | Integer; validated in backend against loaded network |
| Reach IDs (comma-separated) | Yes | List of integers |

### 2.3 Follow-up sample registration (`InvestigationWorkspace.jsx → FollowUpForm`)

| Input | Required | Validation |
|-------|----------|-----------|
| Target site or candidate reach | Yes | Selected from registered sites or generated candidates |
| Sample date/time | Yes | datetime-local |
| Replicate count | Yes | Integer > 0 |
| Positive replicates | Yes | Integer 0–replicate_count |
| Assay | Yes | Non-empty string |
| Controls status | Yes | Non-empty string |
| Collector source | Yes | Non-empty string |
| Concentration / unit | Optional | Float ≥ 0; unit required if concentration supplied |
| Provenance | Auto | `{"entry_method": "frontend"}` |

### 2.4 Environmental context collection (`InvestigationWorkspace.jsx`)

Triggered by the "Collect available context" button. The frontend sends:

```json
{ "radius_m": 5000, "weather_window_days": 0 }
```

The backend derives coordinates from the case's detection site unless overridden. No user coordinate input is required.

### 2.5 Candidate zone creation (backend-only for Wigger demo; also via form)

Automated via `GET /demo/wigger` which creates Z1, Z2, Z3 from the frozen `candidate_zones_real.geojson` preflight artifact. Manual creation is also available from the workspace ZoneForm.

### 2.6 Automatically populated fields

- All UUIDs (generated server-side with `uuid4()`)
- `created_at`, `updated_at` (set by SQLAlchemy defaults)
- Detection site snapped network coordinates (from preflight data for the Wigger demo; `NOT_VERIFIED` for manually created sites)
- Evidence items linked from follow-up samples (auto-created atomically in `FollowUpSampleService.create`)
- Wigger historical H001 observation evidence (loaded via `GET /demo/wigger`)
- Topology evidence items per zone (loaded idempotently by `_ensure_wigger_evidence`)

---

## 3. Complete Application Workflow

### 3.1 New investigation path

```
User opens /investigations/new
 → NewInvestigationForm rendered (modal overlay)
 → User fills form and clicks "Create investigation"
 → Frontend validates (client-side)
 → POST /cases {target_taxon, observation_date, lat, lon, hyriv_id, metadata}
   → cases.py route: validate reach exists via get_hydrology_engine()
   → create_site() (commit=False) → SamplingRepository
   → create_case() (commit=False) → CaseRepository
   → link site.case_id = case.id
   → db.commit() (atomic)
   → Returns 201 CaseResponse
 → Optional: POST /cases/{id}/evidence (replicate_results)
 → navigate to /investigations/{case_id}
```

### 3.2 Investigation workspace path

```
User opens /investigations/{caseId}
 → loadCaseBundle(caseId) — 12 parallel API calls via Promise.allSettled:
   GET /cases/{id}                    → case record
   GET /cases/{id}/evidence           → evidence items
   GET /cases/{id}/evidence-assessment → zone assessments
   GET /cases/{id}/sites              → registered sites
   GET /cases/{id}/zones              → candidate zones
   GET /cases/{id}/generated-candidates → topology candidates
   GET /cases/{id}/sampling-decision  → latest decision
   GET /cases/{id}/context            → environmental context records
   GET /cases/{id}/one-health         → One Health pathway
   GET /cases/{id}/follow-up-samples  → follow-up records
   GET /cases/{id}/investigation-runs → run history
   GET /cases/{id}/map                → GeoJSON river/zone/sites
 → Bundle assembled → rendered in InvestigationWorkspace
```

### 3.3 Wigger demo path

```
User opens /investigations/demo
 → GET /demo/wigger
   → WiggerPreflightLoader validates 6 required files
   → CarraroHistoricalLoader reads eDNA_data.mat + RUN_MODEL.m
   → Idempotency check: scan cases for demo_key or matching H001 signature
   → If existing: update metadata, ensure evidence, return existing IDs
   → If new:
     → Create Site A detection site
     → Create case with H001 metadata
     → Link site.case_id
     → Create Sites B, C, D from candidate_sampling_sites.csv
     → Create Zones Z1, Z2, Z3 from candidate_zones_real.geojson
     → _ensure_wigger_evidence:
       → Add H001 historical observation evidence
       → Add directed_hydrological_connectivity evidence per zone
   → Returns WiggerDemoResponse {case_id, ...}
 → Frontend: navigate to /investigations/{case_id}
```

### 3.4 Sampling decision evaluation path

```
User clicks "Evaluate sampling decision"
 → POST /cases/{id}/sampling-decision
   → Get case, zones, candidate_sites from DB
   → SamplingService.evaluate_sampling_candidates(case, zones, sites)
     → ScaffoldSamplingDecisionEngine.evaluate_candidates()
       → For each site × each zone: hydrology_engine.can_contribute(zone.root, site.hyriv)
       → Compute signature [0/1 per zone] and pair_separation_score = r*(n-r)
     → make_recommendation() → RECOMMEND / TIE / ABSTAIN / INSUFFICIENT_DATA
     → save_decision() → SamplingDecisionModel + DecisionTraceModel in DB
     → create_decision_trace() → replaces initial placeholder in DecisionTraceModel
   → Returns SamplingDecisionResponse
 → Frontend: reload bundle → display decision + trace
```

### 3.5 Candidate generation path

```
User clicks "Generate candidate comparison"
 → GET /cases/{id}/generated-candidates
   → Get zones, detection_site from DB
   → CandidateSiteGenerator.generate(zones, site_a_hyriv_id, site_a_fraction)
     → get_upstream_reaches(site_a_hyriv_id) → all upstream reach IDs
     → For each eligible upstream reach:
       → signature = [can_contribute(zone.root, reach) for zone in sorted_zones]
       → distance = network_distance_km(reach, site_a, from_fraction=0.5, to_fraction=site_a_fraction)
       → group by signature
     → For each group with score > 0: select nearest-to-A representative
   → Run through sampling engine evaluate_candidates → get decision_status
   → Return CandidateGenerationResponse
 → Frontend: display candidate table
```

### 3.6 Reinvestigation path

```
User clicks "Run reinvestigation"
 → POST /cases/{id}/reinvestigate {trigger_evidence_id, trigger_follow_up_sample_id}
   → InvestigationService.reinvestigate()
     → InvestigationRepository.create_running() → RUNNING status
     → For each zone: evidence_engine.assess_evidence_for_zone()
                      hypothesis_resolver.resolve() → HypothesisStatus
     → candidate_generator.generate(eligible_zones, ...)
     → sampling_engine.evaluate_candidates() + make_recommendation()
     → Create SamplingDecisionModel + DecisionTraceModel
     → Create HypothesisStateModel per zone
     → Create GeneratedCandidateSnapshotModel per candidate
     → Mark run COMPLETED with snapshots
   → Return InvestigationRunResponse with before/after diff
```

---

## 4. Complete Technical Architecture

### 4.1 Frontend

**Framework:** React 18 via Vite  
**Router:** react-router-dom  
**Map:** MapLibre GL JS (WebGL-based, OpenStreetMap basemap tiles)  
**Icons:** lucide-react  
**Build:** Vite (1,601 modules in production build)  
**Tests:** Playwright (18 pass, 6 intentionally skipped)

**Route structure (`App.jsx`):**

| Route | Component | Purpose |
|-------|-----------|---------|
| `/` | `Home` | Public landing page with demo map |
| `/dashboard` | `Dashboard` | Case statistics and quick actions |
| `/investigations` | `Investigations` | List, filter, create investigations |
| `/investigations/new` | `Investigations (formOpen)` | Opens creation form directly |
| `/investigations/:caseId` | `InvestigationWorkspace` | Full scientific workspace |
| `/sites` | `Sites` | Sampling site explorer |
| `/reports` | `Reports` | Printable scientific report + PDF |

**Key data flow pattern (`useRemoteData.js`):**

```javascript
useEffect(() => reload(), [dependencies])
// reload() → setState(LOADING) → loader() → setState(READY/EMPTY/ERROR)
// Returns {status, data, error, reload}
```

The `loadCaseBundle()` function in `api.js` fires 12 requests in parallel via `Promise.allSettled`, meaning individual failures do not block the workspace from rendering.

**Authentication:** Not implemented. The nav displays "Authentication unavailable".

### 4.2 Backend

**Framework:** FastAPI 0.115  
**ASGI server:** Uvicorn  
**Python:** 3.12  
**ORM:** SQLAlchemy 2.0 (declarative mapped columns)  
**Migrations:** Alembic  
**Validation:** Pydantic 2.9  
**Scientific libraries:** pandas, geopandas, scipy, shapely  
**Property-based tests:** Hypothesis 6.112  

**Application startup sequence (`main.py → lifespan`):**

1. `config.validate()` — checks DATABASE_URL and PREFLIGHT_DATA_DIR exist
2. `initialize_engines()` — loads `upstream_reaches_real.csv` and `upstream_edges.csv` into `HydrologyEngine`, creates `EvidenceCompatibilityEngineImpl` and `ScaffoldSamplingDecisionEngine`
3. Register all 10 routers
4. Add CORS middleware (currently `allow_origins=["*"]`)

**Layer architecture:**

```
Routes (api/routes/*.py)
   → Services (services/*.py)          — business logic, orchestration
      → Repositories (repositories/*.py) — DB access, domain model conversion
         → ORM Models (db/models.py)    — SQLAlchemy table definitions
      → Scientific Engines (scientific/*) — deterministic algorithms
         → Domain Models (domain/models.py) — pure Python dataclasses
```

**Router prefixes:**

| Router | Prefix | Tags |
|--------|--------|------|
| health | `/health` | health |
| cases | `/cases` | cases |
| evidence | `/cases` | evidence |
| hydrology | `/hydrology` | hydrology |
| sampling | `/cases` | sampling |
| demo | `/demo` | demo |
| context | `/cases` | context |
| follow_up_samples | `/cases` | follow-up samples |
| one_health | `/cases` | one health |
| investigations | `/cases` | investigations |

### 4.3 Database

**Engine:** PostgreSQL 16  
**DB name:** `eDna` (as configured in production environment)  
**Migration head:** `d4c8e1a907b2`  

**Tables (11 total):**

| Table | Purpose |
|-------|---------|
| `sampling_sites` | All locations (detection sites, candidate sites, follow-up sites) |
| `cases` | Investigation records; FK → sampling_sites.id (detection_site_id) |
| `candidate_zones` | Upstream source hypotheses; FK → cases.id |
| `evidence_items` | All evidence including historical obs, topology, context, follow-up; FK → cases.id |
| `sampling_decisions` | Decision records (RECOMMEND/TIE/ABSTAIN/INSUFFICIENT_DATA); FK → cases.id |
| `decision_traces` | Full audit trail per decision; FK → sampling_decisions.id |
| `follow_up_samples` | Field sample metadata; FK → cases.id, sampling_sites.id, evidence_items.id |
| `investigation_runs` | Versioned run history; FK → cases.id, evidence_items.id, sampling_decisions.id |
| `hypothesis_states` | Per-zone hypothesis status per run; FK → investigation_runs.id |
| `generated_candidate_snapshots` | Frozen candidate topology per run; FK → investigation_runs.id |
| `alembic_version` | Migration tracking |

**Cross-database compatibility:** `JSONType` and `ArrayType` custom type decorators use PostgreSQL `JSONB`/`ARRAY` when the dialect is `postgresql`, and fall back to `JSON` otherwise (used in SQLite test environment).

**Circular FK pattern:** `sampling_sites.case_id → cases.id` and `cases.detection_site_id → sampling_sites.id` form a controlled cycle. The code handles it by creating the site first (commit=False), then the case, then linking `site.case_id = case.id` before the final commit.

### 4.4 APIs — Complete Endpoint Reference

| Method | Path | Response | Purpose |
|--------|------|----------|---------|
| GET | `/health` | HealthResponse | Preflight file presence check |
| GET | `/` | dict | API name and docs links |
| POST | `/cases` | CaseResponse 201 | Create investigation + detection site |
| GET | `/cases` | CaseListResponse | List cases with filters |
| GET | `/cases/{id}` | CaseResponse | Get single case |
| POST | `/cases/{id}/evidence` | EvidenceResponse 201 | Add evidence item |
| GET | `/cases/{id}/evidence` | list[EvidenceResponse] | List evidence |
| GET | `/cases/{id}/evidence-assessment` | list[AssessmentSummaryResponse] | Zone-by-zone evidence assessment |
| POST | `/cases/{id}/sites` | SamplingSiteResponse 201 | Register sampling site |
| GET | `/cases/{id}/sites` | list[SamplingSiteResponse] | List sites |
| POST | `/cases/{id}/zones` | CandidateZoneResponse 201 | Create candidate zone |
| GET | `/cases/{id}/zones` | list[CandidateZoneResponse] | List zones |
| GET | `/cases/{id}/map` | InvestigationMapResponse | Case-scoped GeoJSON map data |
| GET | `/cases/{id}/generated-candidates` | CandidateGenerationResponse | Topology candidates |
| POST | `/cases/{id}/sampling-decision` | SamplingDecisionResponse 201 | Evaluate + persist decision |
| GET | `/cases/{id}/sampling-decision` | SamplingDecisionResponse\|null | Latest decision |
| GET | `/cases/{id}/decision-trace` | DecisionTraceResponse | Latest decision audit trail |
| POST | `/cases/{id}/follow-up-samples` | FollowUpSampleResponse 201 | Register field sample |
| GET | `/cases/{id}/follow-up-samples` | list[FollowUpSampleResponse] | List follow-up samples |
| GET | `/cases/{id}/follow-up-samples/{sid}` | FollowUpSampleResponse | Single follow-up sample |
| POST | `/cases/{id}/context/collect` | list[ContextProviderResponse] | Collect + persist context |
| GET | `/cases/{id}/context` | list[ContextProviderResponse] | Retrieve context records |
| GET | `/cases/{id}/one-health` | OneHealthAssessmentSchema | One Health pathway |
| POST | `/cases/{id}/reinvestigate` | InvestigationRunResponse 201 | Run full reinvestigation |
| GET | `/cases/{id}/investigation-runs` | list[InvestigationRunSummary] | Run history |
| GET | `/cases/{id}/investigation-runs/{rid}` | InvestigationRunResponse | Single run detail |
| GET | `/hydrology/reaches/{id}` | ReachResponse | Reach metadata |
| GET | `/hydrology/upstream/{id}` | UpstreamQueryResponse | Upstream reaches |
| GET | `/hydrology/downstream/{id}` | DownstreamPathResponse | Downstream path |
| GET | `/hydrology/distance` | NetworkDistanceResponse | Network distance |
| GET | `/demo/wigger` | WiggerDemoResponse | Load/retrieve Wigger case |
| GET | `/demo/wigger/map` | WiggerMapResponse | Frozen Wigger GeoJSON (no DB) |

### 4.5 External integrations

| Integration | Provider | Transport | Status | Notes |
|-------------|----------|-----------|--------|-------|
| GBIF occurrence search | `api.gbif.org/v1/occurrence/search` | HTTPS (urllib) | Fully implemented | Bounding-box query; up to 100 records; provenance recorded |
| Historical weather (ERA5) | `archive-api.open-meteo.com/v1/archive` | HTTPS (urllib) | Fully implemented | Daily temperature + precipitation; missing-data handling; strict date validation |
| GHSL urbanization | GHSL raster tiles | N/A | Explicitly unavailable | `UnavailableSpatialClient` raises NotImplementedError; returns UNAVAILABLE status |
| HydroRIVERS v10 | Local CSV/GeoJSON preflight files | Filesystem | Fully implemented | Pre-processed; not fetched at runtime |
| Carraro 2020 MATLAB | Local `.mat` + `.m` files | Filesystem / scipy | Fully implemented | SHA-256 verified; read-only |
| OpenStreetMap tiles | `tile.openstreetmap.org` | HTTPS (MapLibre) | Fully implemented | Basemap only; graceful fallback if unavailable |

---

## 5. Map Architecture

### 5.1 Where geographic data originates

All scientific geographic data comes from pre-validated preflight artifacts in `data_preflight/outputs/`:

| File | Content | Used by |
|------|---------|---------|
| `upstream_reaches_real.csv` | 49 reach records (HYRIV_ID, NEXT_DOWN, LENGTH_KM, etc.) | HydrologyEngine graph |
| `upstream_edges.csv` | Directed upstream→downstream relationships | HydrologyEngine reverse graph |
| `upstream_reaches_real.geojson` | LineString geometries per reach in EPSG:4326 | Map rendering, candidate midpoint coords |
| `candidate_zones_real.geojson` | Zone membership (HYRIV_ID, zone label Z1/Z2/Z3) | Zone overlay rendering |
| `candidate_sampling_sites.csv` | Sites B/C/D coordinates, distances, roles | Demo site creation |
| `site_a.json` | Site A coordinates and HYRIV_ID 20446064 | Detection site creation |
| `site_a_snap_validation.json` | Fraction-along-reach (0.8574) for Site A | Distance calculations |

### 5.2 How geographic data flows to the map

**`GET /demo/wigger/map` (Sites page):**  
Reads `upstream_reaches_real.geojson` and `candidate_zones_real.geojson` directly from disk, no DB required. Returns frozen Wigger geometry without creating any rows.

**`GET /cases/{id}/map` (Investigation Workspace / Reports):**  
1. Load case + detection site from DB
2. Collect all reach IDs: from registered sites, zone reach memberships, and all upstream reaches of the detection site (via `HydrologyEngine.get_upstream_reaches`)
3. Filter `upstream_reaches_real.geojson` to only those IDs → `river_network` GeoJSON
4. Build zone feature GeoJSON from zone membership × geometry lookup
5. Return `InvestigationMapResponse` with river_network, source_zones, and persisted sites

### 5.3 Map rendering (`ScientificMap.jsx`)

The component uses **MapLibre GL JS** with:
- OpenStreetMap raster basemap (handles tile failures gracefully, scientific overlays remain)
- Two GeoJSON sources: `river` (river network lines) and `zones` (source zone colored lines)
- Site markers rendered as DOM `<button>` elements via `maplibregl.Marker` (not GeoJSON layers)
- A static SVG `PrintMap` component rendered alongside for print/PDF output

**Layer control:** River network, site markers, and zone overlays can be toggled independently via checkboxes.

**Site selection synchronization:** Selecting a site via the list, map marker, or legend all update the same `activeSite` state, which applies the `.selected` CSS class to all three simultaneously.

**Coordinate extraction:** The `coordinates()` utility recursively extracts all coordinate pairs from any GeoJSON geometry (LineString, MultiLineString, Polygon, etc.) to compute the initial bounding box for `fitBounds`.

**Candidate coordinates:** Derived in `sampling.py` by loading `upstream_reaches_real.geojson` via geopandas, then interpolating the midpoint of each reach geometry (`geometry.interpolate(0.5, normalized=True)`), storing in a `{hyriv_id: (lat, lon)}` lookup for the `CandidateSiteGenerator`.

### 5.4 Missing geographic data handling

If `mapData.available === false` or `mapData.river_network.features.length === 0`, the map container shows a placeholder with the `unavailable_reason` string. If the basemap tiles fail to load, a warning is displayed but the scientific overlays remain functional.

---

## 6. Outputs and Results

### 6.1 Evidence assessment

**What it shows:** For each candidate zone, for each evidence item: compatibility (SUPPORTS / CONTRADICTS / NEUTRAL / UNKNOWN), the rule ID applied, the reason text, and strength (HIGH / MEDIUM / LOW / UNASSESSED).

**How calculated:** `EvidenceCompatibilityEngineImpl.assess_evidence_for_zone()` applies `hydrorivers.directed_contribution.v1` to evidence items of type `directed_hydrological_connectivity`. All other evidence types receive `UNKNOWN`.

**Computed result:** Yes, for topology evidence. The historical H001 observation gets `UNKNOWN` because no validated rule covers the `historical_edna_measurement` evidence type.

### 6.2 Candidate generation

**What it shows:** One representative reach per topology equivalence class (signature group), with pair_separation_score, network_distance_km, which zone pairs are distinguished, and validation status.

**How calculated:** 
1. Get all upstream reaches of Site A
2. For each reach, compute `signature = [can_contribute(zone.root, reach) for zone in zones]`
3. Group reaches with identical signatures
4. For each group where score > 0: select the reach with minimum distance to Site A
5. Score = r × (n − r) where r = number of zones whose root can reach this reach, n = total zones

**Computed result:** Yes, fully deterministic. Candidates are counterfactual — not registered field sites.

### 6.3 Sampling decision

**What it shows:** Status (RECOMMEND / TIE / ABSTAIN / INSUFFICIENT_DATA) with rationale and recommended site IDs.

**How calculated:** `ScaffoldSamplingDecisionEngine.make_recommendation()` finds the maximum pair-separation score among evaluated candidates. If one site uniquely maximizes it → RECOMMEND. If multiple tie → TIE. If no site separates any pair → ABSTAIN. If inputs incomplete → INSUFFICIENT_DATA.

**For the Wigger case:** TIE (Sites B, C, D each separate 2 of 3 pairs, with score = 2).

**Computed result:** Yes, deterministic topology-only criterion.

### 6.4 Decision trace

**What it shows:** Evidence IDs used, rule IDs applied (`hydrorivers.directed_contribution.v1`, `sampling.topology_pair_separation.v1`), hydrology checks (one record per zone × site reachability check), assumptions, and limitations.

**Computed result:** Yes, generated per decision.

### 6.5 Environmental context

**What it shows:**
- **GBIF:** Count and compact records of species occurrences within a bounding box around the detection site
- **Historical weather (ERA5):** Daily mean temperature (°C) and precipitation (mm) for the observation date window
- **Urbanization:** UNAVAILABLE (no raster extraction configured)

**Computed result:** GBIF and weather are real API calls. Urbanization is explicitly unavailable.

**Scientific boundary explicitly noted:** Context does not establish source presence, pollution, disease, or health risk.

### 6.6 One Health pathway

**What it shows:** A structured pathway for the *Fredericella sultana* detection linking it to *Tetracapsuloides bryosalmonae* biology, proliferative kidney disease relevance, and fish health monitoring considerations.

**How calculated:** `OneHealthService._is_verified_fs_case()` checks exact match against H001 case identity. If matched, returns a static pathway with literature DOIs and explicit epistemic status per claim (OBSERVED / SUPPORTED_RELATIONSHIP / POSSIBLE_RELEVANCE / UNKNOWN).

**Computed result:** Partially. The pathway structure is deterministic and derived from the case record. The claim statements and literature links are static — hardcoded for the single verified case. No pathway exists for non-Fs cases.

### 6.7 Investigation report

**What it shows:** All of the above in a multi-section printable document.

**PDF export:** `window.print()` with `@media print` CSS. The `PrintMap` SVG component provides a print-safe fallback for the MapLibre canvas. Playwright test generates `WIGGER_BROWSER_REPORT.pdf` via `page.pdf()`.

### 6.8 Investigation run comparison

**What it shows:** Before/after diff between the current run and the previous completed run, showing which of hypothesis states, candidate representatives, and decision changed.

**Computed result:** Yes. The `changed` object is computed by comparing serialized snapshots (`_hypothesis_signature`, `_decision_signature`).

---

## 7. Architecture Diagrams

### 7.1 High-level system architecture

```mermaid
graph TB
    subgraph Browser
        UI[React SPA<br/>Vite + MapLibre GL]
    end

    subgraph FastAPI Backend
        MW[CORS Middleware]
        R[API Routes<br/>10 routers]
        S[Services Layer]
        SC[Scientific Engines]
        RE[Repositories]
        CFG[Config<br/>DATABASE_URL<br/>PREFLIGHT_DATA_DIR]
    end

    subgraph PostgreSQL
        DB[(eDna DB<br/>11 tables)]
    end

    subgraph Preflight Data
        CSV[upstream_reaches_real.csv<br/>upstream_edges.csv<br/>candidate_sampling_sites.csv]
        GEO[candidate_zones_real.geojson<br/>upstream_reaches_real.geojson]
        JSON[site_a.json<br/>site_a_snap_validation.json<br/>sampling_design_validation.json]
        MAT[eDNA_data.mat<br/>RUN_MODEL.m]
    end

    subgraph External APIs
        GBIF[GBIF API]
        OM[Open-Meteo ERA5 Archive]
        OSM[OpenStreetMap Tiles]
    end

    UI -->|HTTP/JSON| MW
    MW --> R
    R --> S
    S --> SC
    S --> RE
    RE -->|SQLAlchemy| DB
    SC -->|pandas / geopandas / scipy| CSV
    SC --> GEO
    SC --> JSON
    SC --> MAT
    S -->|urllib| GBIF
    S -->|urllib| OM
    UI -->|HTTPS tiles| OSM
```

### 7.2 User input → processing → output workflow

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant API
    participant DB
    participant HydroEngine
    participant EvidenceEngine
    participant SamplingEngine
    participant CandidateGen

    User->>Frontend: Fill new investigation form
    Frontend->>API: POST /cases
    API->>HydroEngine: get_reach(hyriv_id) — validate
    API->>DB: INSERT sampling_sites (detection site)
    API->>DB: INSERT cases
    DB-->>API: case_id
    API-->>Frontend: 201 {case_id}
    Frontend->>API: navigate to /investigations/{id}

    Frontend->>API: loadCaseBundle (12 parallel GETs)
    API->>DB: SELECT * for case, evidence, sites, zones, map
    API-->>Frontend: bundle with map GeoJSON

    User->>Frontend: Register source hypothesis
    Frontend->>API: POST /cases/{id}/zones
    API->>DB: INSERT candidate_zones

    User->>Frontend: Generate candidates
    Frontend->>API: GET /cases/{id}/generated-candidates
    API->>HydroEngine: get_upstream_reaches(site_a)
    API->>CandidateGen: generate(zones, site_a_hyriv_id)
    CandidateGen->>HydroEngine: can_contribute(zone_root, reach) per reach×zone
    CandidateGen->>HydroEngine: network_distance_km(reach, site_a)
    CandidateGen-->>API: CandidateGenerationResult
    API-->>Frontend: candidates with signatures and scores

    User->>Frontend: Evaluate sampling decision
    Frontend->>API: POST /cases/{id}/sampling-decision
    API->>DB: SELECT zones, sites
    API->>SamplingEngine: evaluate_candidates + make_recommendation
    SamplingEngine->>HydroEngine: can_contribute per site×zone
    SamplingEngine-->>API: status, rationale, trace
    API->>DB: INSERT sampling_decisions, decision_traces
    API-->>Frontend: decision (TIE/RECOMMEND/ABSTAIN/INSUFFICIENT_DATA)

    User->>Frontend: Click Export PDF
    Frontend->>Browser: window.print()
    Browser-->>User: PDF via print dialog / headless
```

### 7.3 Data flow within the scientific pipeline

```mermaid
graph LR
    subgraph Preflight Files
        CSV[upstream_reaches_real.csv<br/>upstream_edges.csv]
        GJ[upstream_reaches_real.geojson]
        SITES[candidate_sampling_sites.csv]
        ZONES[candidate_zones_real.geojson]
        SA[site_a.json + snap_validation]
        MAT[eDNA_data.mat + RUN_MODEL.m]
    end

    subgraph Startup
        LOADER[WiggerPreflightLoader]
        HE[HydrologyEngine<br/>adjacency lists]
    end

    subgraph Demo Load
        DEMO[GET /demo/wigger]
        CARR[CarraroHistoricalLoader]
        EVID[EvidenceItems: H001 + topology]
    end

    subgraph Per-Request
        CGEN[CandidateSiteGenerator<br/>signatures per reach]
        EE[EvidenceCompatibilityEngine<br/>SUPPORTS/CONTRADICTS/NEUTRAL/UNKNOWN]
        SE[ScaffoldSamplingDecisionEngine<br/>pair_separation_score]
        HR[ConservativeHypothesisStateResolver<br/>SUPPORTED/WEAKENED/UNKNOWN]
        IS[InvestigationService<br/>versioned run + snapshots]
    end

    CSV --> LOADER --> HE
    GJ --> CGEN
    SITES --> DEMO
    ZONES --> DEMO
    SA --> DEMO
    MAT --> CARR --> DEMO
    DEMO --> EVID

    HE --> CGEN
    HE --> SE
    EVID --> EE
    EE --> HR
    HR --> IS
    CGEN --> SE
    SE --> IS
```

---

## 8. Implementation Assessment

| Feature | Status | Notes |
|---------|--------|-------|
| Case creation (POST /cases) | ✅ Fully implemented | Atomic site+case transaction; HYRIV_ID validated |
| Case listing / retrieval | ✅ Fully implemented | Filters: status, taxon, limit, offset |
| Wigger demo load (idempotent) | ✅ Fully implemented | SHA-256 checksums on MATLAB files; demo_key deduplication |
| HydrologyEngine (graph, upstream, distance, reachability) | ✅ Fully implemented | BFS upstream, NEXT_DOWN downstream, fraction-aware distance |
| `can_contribute` / topology | ✅ Fully implemented | is_upstream OR same reach |
| Evidence CRUD and assessment | ✅ Fully implemented | One validated rule (hydrorivers.directed_contribution.v1); all other types → UNKNOWN |
| Evidence strength assessment | ✅ Fully implemented | hydrorivers.directed_connectivity_strength.v1 |
| Candidate generation | ✅ Fully implemented | Deterministic equivalence classes; nearest-to-A representative |
| Sampling decision (topology pair-separation) | ✅ Fully implemented | RECOMMEND / TIE / ABSTAIN / INSUFFICIENT_DATA |
| Decision trace / audit trail | ✅ Fully implemented | Evidence used, rules, hydrology checks, assumptions, limitations |
| Follow-up sample registration | ✅ Fully implemented | Atomic with linked evidence item; HYRIV_ID validated |
| Reinvestigation engine | ✅ Fully implemented | Versioned runs with hypothesis states, candidate snapshots, before/after diff |
| GBIF context provider | ✅ Fully implemented | Real HTTP call; bbox from radius_m |
| Historical weather provider (ERA5) | ✅ Fully implemented | Real HTTP call; strict date/unit validation; missing data tracking |
| Urbanization context provider | ⚠️ Explicitly unavailable | `UnavailableSpatialClient` — no raster extraction configured |
| One Health pathway | ⚠️ Partially implemented | Only implemented for the specific Fs/H001/S1/2014-06-25 case identity; no pathway for other taxa |
| Interactive map (MapLibre GL) | ✅ Fully implemented | River network, zone overlays, site markers, layer toggles, fullscreen, basemap fallback |
| Print / PDF export | ✅ Fully implemented | `window.print()` + SVG PrintMap fallback; Playwright test generates actual PDF |
| Investigation workspace (5 accordions) | ✅ Fully implemented | Evidence, sources, decision, next steps; real-time reload after each action |
| Investigations page (filters + creation form) | ✅ Fully implemented | Search, workflow/decision/date filters; full creation form with client-side validation |
| Dashboard (metrics + recent table) | ✅ Fully implemented | Real counts from loaded cases; not hardcoded |
| Sites page (filter + map sync) | ✅ Fully implemented | List ↔ map ↔ details synchronized; search + type filter |
| Reports page (all sections) | ✅ Fully implemented | 14 sections; all driven by live backend data |
| Authentication | ❌ Not implemented | UI shows "Authentication unavailable" |
| Coordinate snapping (new sites) | ❌ Not implemented | Reach must be explicitly provided; system validates reach exists but does not snap |
| Elimination of contradicted hypotheses | ❌ Not implemented | `ConservativeHypothesisStateResolver` marks WEAKENED but never ELIMINATED; all zones remain eligible |
| Urbanization context | ❌ Not implemented | Explicitly flagged as unavailable |
| Non-Fs One Health pathways | ❌ Not implemented | Service returns empty `pathways: []` for non-Fs cases |
| Rate limiting / caching | ❌ Not implemented | No caching layer; each request reloads preflight data from disk (hydrology route) |

---

## 9. Architectural Observations

### 9.1 Inconsistency: HydrologyEngine reloads preflight data on every request

In `hydrology.py` and `sampling.py`, the dependency injector `get_hydrology_service` / `get_sampling_service` calls `WiggerPreflightLoader(…)` and constructs a fresh `HydrologyEngine` on every request. `dependencies.py` has a global `_hydrology_engine` initialized at startup, but the route-level dependencies do not use it — they each call `initialize_engines()`'s equivalent locally. This means CSV files are read and the graph is rebuilt per request. Functionally correct but wasteful.

### 9.2 CORS is fully open

`allow_origins=["*"]` in production. Acceptable for a development prototype, but a risk for any deployment.

### 9.3 No authentication

All endpoints are publicly accessible. The application UI acknowledges this.

### 9.4 Decision trace placeholder replacement

`SamplingService.evaluate_sampling_candidates()` saves an initial trace via `save_decision()` (with empty arrays) then immediately replaces its content with `sampling_engine.create_decision_trace()` output by mutating the ORM object and committing again. This is a two-phase write — could be simplified to a single transaction.

### 9.5 Missing evidence interpretation for follow-up samples

Follow-up samples are stored as `follow_up_edna_sample` evidence items, but no rule in the catalog classifies this evidence type. The reinvestigation trace explicitly documents: "New follow-up sample recorded, but no validated interpretation rule currently allows this observation to alter source hypotheses." The hypothesis state will always remain UNKNOWN until a rule is added to the catalog.

### 9.6 Zone root ID derivation in demo loader

The demo loader finds the zone root by `zone_data.loc[zone_data["UPLAND_SKM"].idxmax()]`. This produces the correct Z1/Z2/Z3 roots (20447392, 20450127, 20451169) for the Wigger case, but it is a derived heuristic, not a field read directly from the validated artifact.

---

## 10. End-to-End Concrete Example

**Scenario:** A field team detects *Fredericella sultana* eDNA at the Wigger River station S1 on 2014-06-25. The team loads the historical case and evaluates where to sample next.

### Step 1: Load the Wigger demo

```http
GET /demo/wigger
```

**Internally:**
1. `WiggerPreflightLoader` reads `site_a.json` — Site A at 47.31400°N 7.89540°E, HYRIV_ID 20446064, snap distance 64.81 m, fraction 0.8574
2. `CarraroHistoricalLoader` reads `eDNA_data.mat` — `Fs.S1[3]` = `1.2983219767633366e-17 mol/L`, date serial → 2014-06-25
3. Idempotency check finds no existing demo case → creates new records
4. Inserts Site A (DETECTION_SITE, MATCHED, case_id=NULL initially)
5. Inserts Case: target_taxon="Fredericella sultana", observation_date=2014-06-25, detection_site_id=Site_A.id
6. Links site.case_id = case.id
7. Inserts Sites B (HYRIV_ID 20450127, 19.226 km), C (20451169, 23.936 km), D (20448315, 10.941 km)
8. Inserts Zones Z1 (root 20447392), Z2 (root 20450127), Z3 (root 20451169) from GeoJSON
9. `_ensure_wigger_evidence`:
   - 1× `historical_edna_measurement` evidence (concentration, state=DETECTED)
   - 3× `directed_hydrological_connectivity` evidence, one per zone, each with `can_contribute: true`

**Returns:** `{case_id: "...", sites_created: 4, zones_created: 3}`

### Step 2: Frontend loads the workspace

`loadCaseBundle(caseId)` fires 12 parallel requests. Key results:

- `/cases/{id}` → case with H001 metadata
- `/cases/{id}/evidence-assessment` → for Z1, Z2, Z3: each zone's topology evidence → SUPPORTS (can_contribute=true), H001 evidence → UNKNOWN (no rule)
- `/cases/{id}/generated-candidates` → CandidateSiteGenerator finds 48 upstream reaches; groups by signature; produces 3 candidates (signatures [1,0,0], [0,1,0], [0,0,1], [0,1,1], [1,0,1], [1,1,0], [1,1,1] minus zero-score signatures)
- `/cases/{id}/map` → GeoJSON of 49 reaches colored by zone membership

The map displays: 49 river reaches as blue lines, three colored zone overlays (Z1 sky blue, Z2 green, Z3 purple), four site markers (A orange, B blue, C green, D purple).

### Step 3: Evaluate sampling decision

```http
POST /cases/{id}/sampling-decision
```

**Internally:**
1. Loads zones Z1/Z2/Z3 and sites A, B, C, D from DB
2. `evaluate_candidates`:
   - Site B (20450127): can_contribute(Z1.root=20447392, 20450127)=false, (Z2.root=20450127, 20450127)=true (same reach), (Z3.root=20451169, 20450127)=false → signature [0,1,0], score = 1×2 = 2
   - Site C (20451169): signature [0,0,1], score = 1×2 = 2
   - Site D (20448315): signature [0,1,1], score = 2×1 = 2
   - Site A (20446064, detection site): all zones contribute → [1,1,1], score = 3×0 = 0
3. `make_recommendation`: best_score = 2, multiple winners → **TIE: Site B, Site C, Site D**
4. Inserts `sampling_decisions` (status=TIE, recommended_site_ids=[B.id, C.id, D.id])
5. Inserts `decision_traces` (rules_applied=["sampling.topology_pair_separation.v1"])

**Returns:** `{status: "TIE", rationale: "Multiple sites share the maximum topology-only pair separation score (2 pairs): Site B, Site C, Site D"}`

### Step 4: User reads the report

`GET /reports` → select "Wigger River Investigation"

Report shows:
- Detection section: *Fredericella sultana*, S1, 2014-06-25, 1.2983219767633366e-17 mol/L, DETECTED
- Evidence assessment: topology evidence → SUPPORTS for Z1/Z2/Z3; historical evidence → UNKNOWN
- Hydrology: 3 zones, 4 sites, 49 reaches, ~145 km total
- Map: embedded MapLibre GL canvas with river network and colored zone overlays
- Decision: **TIE — Site B, Site C, Site D** (pair-separation score 2 each)
- Assumptions: "The supplied zones are the remaining hypotheses…"
- Limitations: "Reachability is a mapped-network relation, not eDNA detection probability…"

User clicks "Export PDF" → `window.print()` → browser print dialog (or headless PDF via Playwright).

---

*End of architecture report. All findings are based on direct inspection of the source code. No claims are made about real-world scientific validity, field accuracy, or deployment readiness beyond what is stated in the verified implementation status.*
