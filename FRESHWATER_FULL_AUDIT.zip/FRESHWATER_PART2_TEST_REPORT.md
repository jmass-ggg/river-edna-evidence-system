# FreshWater eDNA Evidence Investigator — Part 2: Functional and End-to-End Verification Report

**Prepared:** October 2, 2026  
**Scope:** Read-only audit. No production code, configuration, database, or dataset was modified.  
**Based on:** FRESHWATER_PART1_ARCHITECTURE.md (verified feature inventory)

---

## 1. Test Environment

### System
| Item | Value |
|---|---|
| OS | Linux (Ubuntu 24.04) |
| Python | 3.12.3 (system) |
| Python (venv) | 3.12.3 (`../venv/bin/python3`) |
| PostgreSQL | 16.15 |
| Node.js / npm | present (Playwright 1.63.0) |

### Python packages (venv)
| Package | Version |
|---|---|
| fastapi | 0.115.0 |
| pydantic | 2.9.2 |
| sqlalchemy | 2.0.35 |
| alembic | 1.13.3 |
| hypothesis | 6.112.1 |
| pytest | 8.3.3 |
| geopandas | 1.0.1 |
| shapely | 2.0.6 |
| scipy | 1.14.1 |
| pandas | 2.2.3 |

### Execution commands

```bash
# Backend unit + property + scientific regression tests
../venv/bin/python3 -m pytest tests/ -v --tb=short

# Playwright browser tests
npx playwright test

# Database state inspection
sudo -u postgres psql -d "eDna" -c "<query>"
```

### Critical environment note
`geopandas` is **not installed in the system Python** (`/usr/bin/python3`). It is installed only in the project virtualenv (`../venv/`). Running pytest with the system Python (`python3 -m pytest`) produces 11 collection errors. The correct command is `../venv/bin/python3 -m pytest`. All test results in this report use the venv Python.

---

## 2. Backend Test Results

### 2.1 Test suite execution

**Command:** `../venv/bin/python3 -m pytest tests/ -v --tb=short`  
**Result: 178 passed, 0 failed, 0 skipped, 153 warnings, 0 errors**

#### Breakdown by file

| Test file | Tests | Result |
|---|---|---|
| `tests/property/test_evidence_properties.py` | 12 | 12 passed |
| `tests/property/test_hydrology_properties.py` | 2 | 2 passed |
| `tests/property/test_sampling_properties.py` | 29 | 29 passed |
| `tests/property/test_schema_properties.py` | 6 | 6 passed |
| `tests/unit/test_benchmark_sampling.py` | 6 | 6 passed |
| `tests/unit/test_carraro_v4_extraction.py` | 3 | 3 passed |
| `tests/unit/test_carraro_validation.py` | 3 | 3 passed |
| `tests/unit/test_case_creation_integration.py` | 5 | 5 passed |
| `tests/unit/test_context_infrastructure.py` | 14 | 14 passed |
| `tests/unit/test_database_configuration.py` | 2 | 2 passed |
| `tests/unit/test_follow_up_samples.py` | 6 | 6 passed |
| `tests/unit/test_hydrology_engine.py` | 16 | 16 passed |
| `tests/unit/test_investigation_runs.py` | 3 | 3 passed |
| `tests/unit/test_sampling_repository.py` | 8 | 8 passed |
| `tests/unit/test_sampling_scope_audit.py` | 1 | 1 passed |
| `tests/unit/test_services.py` | 20 | 20 passed |
| `tests/unit/test_v3_scientific_boundaries.py` | 8 | 8 passed |
| `tests/unit/test_v4_scientific_update.py` | 4 | 4 passed |
| `tests/unit/test_wigger_loader.py` | 11 | 11 passed |
| `tests/unit/test_wigger_map_api.py` | 1 | 1 passed |
| `tests/unit/test_wigger_reproducible_workflow.py` | 2 | 2 passed |
| `tests/unit/test_wigger_scientific_regression.py` | 7 | 7 passed |
| **TOTAL** | **178** | **178 passed** |

#### Warnings (non-blocking)
- `datetime.datetime.utcnow()` deprecated in Python 3.12 — appears in `investigation_service.py:140` and `investigations.py:40`. No functional impact.
- `SAWarning: Can't sort tables for DROP` — circular FK between `cases` and `sampling_sites` in SQLite teardown. Does not affect PostgreSQL production schema.

### 2.2 System Python collection errors (informational)

When running with `/usr/bin/python3` (system Python, missing geopandas), 11 test files fail to collect:

```
ModuleNotFoundError: No module named 'geopandas'
```

Affected files: `test_hydrology_properties.py`, `test_carraro_v4_extraction.py`, `test_carraro_validation.py`, `test_case_creation_integration.py`, `test_hydrology_engine.py`, `test_investigation_runs.py`, `test_v4_scientific_update.py`, `test_wigger_loader.py`, `test_wigger_map_api.py`, `test_wigger_reproducible_workflow.py`, `test_wigger_scientific_regression.py`.

**Root cause:** `requirements.txt` lists `geopandas==1.0.1` but the package is not in the system site-packages. The project must always be run from within the virtualenv. The README or CI configuration should enforce this.

---

## 3. Frontend and Playwright Results

### 3.1 Test suite execution

**Command:** `npx playwright test` (run from `frontend/`)  
**Result: 18 passed, 6 skipped, 0 failed**

The 6 skipped tests are correctly and intentionally gated by `test.skip(testInfo.project.name !== 'desktop-1440', ...)` — they only run once at the desktop-1440 viewport to avoid redundant full-interaction tests.

#### Results by project (viewport)

| Project | Viewport | Tests run | Passed | Skipped |
|---|---|---|---|---|
| desktop-1440 | 1440×900 | 6 | 6 | 0 |
| desktop-1280 | 1280×800 | 6 | 4 | 2 |
| tablet | 768×1024 | 6 | 4 | 2 |
| mobile | 390×844 | 6 | 4 | 2 |
| **TOTAL** | — | **24** | **18** | **6** |

#### Per-test results

| Test | desktop-1440 | desktop-1280 | tablet | mobile |
|---|---|---|---|---|
| homepage navigation and verified map render without errors | ✓ PASS | ✓ PASS | ✓ PASS | ✓ PASS |
| Wigger workspace exposes historical observation, map controls, decision, trace | ✓ PASS | ✓ PASS | ✓ PASS | ✓ PASS |
| site filtering keeps list, markers, and details synchronized | ✓ PASS | ✓ PASS | ✓ PASS | ✓ PASS |
| responsive pages have no document-level horizontal overflow | ✓ PASS | ✓ PASS | ✓ PASS | ✓ PASS |
| desktop workflow validates creation, filters records, prints report | ✓ PASS | — SKIP | — SKIP | — SKIP |
| frontend presents API failures as errors rather than empty records | ✓ PASS | — SKIP | — SKIP | — SKIP |

### 3.2 Frontend verification findings

**Navigation and routing:** All routes (`/`, `/dashboard`, `/investigations`, `/investigations/new`, `/investigations/demo`, `/investigations/:id`, `/sites`, `/reports`) navigate correctly. The demo shortcut at `/investigations/demo` correctly redirects to the created case workspace URL after loading.

**Forms and validation:** The new investigation form correctly shows "Required" validation on all 6 mandatory fields. Submitting an invalid HYRIV_ID (999999999) displays `not found in loaded network data` from the backend. The follow-up sample form registers samples and displays them.

**API connectivity:** All API calls succeed. The backend test server (SQLite, port 18001) starts cleanly from `scripts/run_browser_test_backend.py`.

**Loading and error states:** "Could not load investigations" is displayed when the `/cases` endpoint is intercepted. "Investigation unavailable" is shown for a non-UUID investigation path. "Map service unavailable" is shown for a 500 on `/demo/wigger/map`.

**Data persistence:** Cases created in the browser are listed in `/investigations`, filtered correctly by name and decision status, and reflected in `/dashboard` metrics.

**Evidence and hypothesis displays:** The workspace shows `2014-06-25`, observation index `4`, concentration `1.2983219767633366e-17 mol/L`, and state `DETECTED` correctly.

**Candidate comparisons:** The SimpleCandidates table renders. The workspace shows `TIE` after pressing "Evaluate sampling decision".

**Decision trace:** `sampling.topology_pair_separation.v1` rule ID is visible. The decision trace section renders after evaluation.

**Responsive layouts:** No horizontal document overflow at any of the four tested viewports.

**Console and network errors:** Zero console errors and zero HTTP 5xx responses across all passing tests.

**PDF export:** The desktop-1440 test produces `browser_artifacts/WIGGER_BROWSER_REPORT.pdf`. The print media query correctly hides `.app-nav`.

---

## 4. Scientific Map Verification

### 4.1 MapLibre implementation

`frontend/src/components/ScientificMap.jsx` renders via `maplibre-gl` with a static OSM raster basemap. The implementation is a single self-contained component with correct lifecycle management (`useEffect` cleanup removes markers and destroys the map instance).

### 4.2 River geometry

- **Source file:** `data_preflight/outputs/upstream_reaches_real.geojson`  
- **Network:** 49 reaches (Wigger sub-network only)  
- **CRS:** EPSG:4326 confirmed in API response (`"crs": "EPSG:4326"`)  
- **Rendering:** River reaches rendered as `line` layer, color `#168bc2`, width 3px  
- **Direction:** Flow direction is implicit in NEXT_DOWN linkage; the map does not render directional arrows. Geographic correctness of upstream/downstream direction is validated by the hydrology engine tests, not by the visual rendering.

### 4.3 Source zone overlays

Three zone overlays (Z1, Z2, Z3) are rendered as GeoJSON line features with distinct colors:
- Z1: `#38bdf8` (sky blue)  
- Z2: `#34d399` (green)  
- Z3: `#a78bfa` (purple)

Zone reach membership loaded from `candidate_zones_real.geojson` (verified preflight artifact). Zone reach IDs match the database: Z1 = 3 reaches, Z2 = 21 reaches, Z3 = 11 reaches.

### 4.4 Site markers

Four site markers rendered as HTML `<button>` elements with `class="maplibre-site-marker"`. Labels extracted from `site.label` with `Site ` prefix stripped (renders "A", "B", "C", "D"). Colors from the `colors` constant:

| Site | Label | HYRIV_ID | Color |
|---|---|---|---|
| Site A (S1) | A | 20446064 | #F97316 (orange) |
| Site B | B | 20450127 | #2563EB (blue) |
| Site C | C | 20451169 | #16A34A (green) |
| Site D | D | 20448315 | #9333EA (purple) |

Playwright confirmed 4 markers visible in the workspace map.

### 4.5 Candidate locations

Generated candidates are not rendered on the workspace map by default. The `SimpleCandidates` table in the workspace shows reach ID, signature, pair score, and distance but does not add markers to the map. The Sites page (`/sites`) uses `demoApi.map()` and does show the 4 pre-validated sites — new cases' generated candidates are not shown there (this is the P10 defect from Part 1, confirmed).

### 4.6 Map controls

Playwright confirmed all four controls work:
- Zoom in (`+`)  
- Reset map view (restores `fitBounds`)  
- Layer toggle checkboxes (river network, sites, source zones)  
- Fullscreen toggle (adds/removes `map-fullscreen` CSS class)

### 4.7 Print rendering

The `PrintMap` sub-component renders an SVG fallback for print. The PDF produced by `page.pdf()` in the Playwright test contains the map SVG. The interactive MapLibre canvas is hidden in print CSS; SVG fallback is shown.

### 4.8 Geographic correctness (separate from visual rendering)

The following geographic facts are verified by the hydrology engine unit and regression tests:

| Claim | Result |
|---|---|
| Z1 root (20447392) can reach Site A (20446064) | True ✓ |
| Z2 root (20450127) can reach Site A (20446064) | True ✓ |
| Z3 root (20451169) can reach Site A (20446064) | True ✓ |
| Z2 and Z3 first common downstream | 20449905 ✓ |
| Site B → Site A network distance | 19.350 km |
| Site C → Site A network distance | 24.060 km |
| Site D → Site A network distance | 11.065 km |
| Network reach count (Wigger sub-network) | 49 reaches |
| Upstream reaches of Site A | 48 reaches |

All zone-to-site reachability results match the evidence items loaded by `_ensure_wigger_evidence()` in `demo.py`.

**Note:** The map renders all 49 reaches but displays no flow direction arrows. A scientist reading the map cannot determine upstream from downstream from the visual alone. This is a display limitation, not a data integrity problem — the underlying graph is directional and correct.

---

## 5. Complete Wigger End-to-End Workflow

### Stage 1 — eDNA Case Input

**Method:** `GET /demo/wigger` (idempotent)  
**Expected:** Case created with Carraro H001 Fs S1 data  
**Actual:**

| Field | Expected | Actual |
|---|---|---|
| target_taxon | Fredericella sultana | Fredericella sultana ✓ |
| observation_date | 2014-06-25 | 2014-06-25 ✓ |
| station | S1 | S1 ✓ |
| observation_index | 4 | 4 ✓ |
| concentration | 1.2983219767633366e-17 mol/L | 1.2983219767633366e-17 mol/L ✓ |
| state | DETECTED | DETECTED ✓ |
| detection_site HYRIV_ID | 20446064 | 20446064 ✓ |
| sites_created | 4 | 4 ✓ |
| zones_created | 3 | 3 ✓ |

**Status: PASS**

---

### Stage 2 — Context Collection

**Method:** `POST /cases/{id}/context/collect`  
**Expected:** Environmental context from GBIF, weather, urbanization  
**Actual:** All three providers raise `NotImplementedError`. Service returns `UNAVAILABLE` for each. No context data persisted.  
**Status: BLOCKED — context providers are non-functional stubs (P5)**

---

### Stage 3 — Source Zone Definition

**Method:** Zones loaded by `GET /demo/wigger`  
**Expected:** Three zones Z1, Z2, Z3 registered with VERIFIED status  
**Actual:**

| Zone | Root HYRIV_ID | Reach count | Validation |
|---|---|---|---|
| Z1 | 20447392 | 3 | VERIFIED ✓ |
| Z2 | 20450127 | 21 | VERIFIED ✓ |
| Z3 | 20451169 | 11 | VERIFIED ✓ |

Root selection criterion is largest `UPLAND_SKM` within each zone — verified by reading `demo.py` and zone GeoDataFrame.  
**Status: PASS**

---

### Stage 4 — Evidence Assessment

**Method:** `GET /cases/{id}/evidence-assessment`  
**Expected:** Topology evidence assessed; Z1 SUPPORTS, Z2 SUPPORTS, Z3 SUPPORTS  
**Actual (from scientific engine direct call):**

| Zone | Evidence type | Compatibility | Hypothesis status | Strength |
|---|---|---|---|---|
| Z1 | directed_hydrological_connectivity | SUPPORTS | SUPPORTED | MEDIUM |
| Z2 | directed_hydrological_connectivity | NEUTRAL* | SUPPORTED | MEDIUM |
| Z3 | directed_hydrological_connectivity | NEUTRAL* | SUPPORTED | MEDIUM |

*The Z1 evidence item has `zone_root_hyriv_id=20447392`. When assessed for Z2 (root=20450127), the engine correctly returns `NEUTRAL` because the evidence targets a different zone root. Z2 is assessed as SUPPORTED because Z2 has its own dedicated evidence item where `can_contribute=True`. The database confirmation shows all three zones have `status=SUPPORTED` with `support_count=1`.

**Database-confirmed hypothesis states:**

| zone_label | status | support_count | contradict_count |
|---|---|---|---|
| Z1 | SUPPORTED | 1 | 0 |
| Z2 | SUPPORTED | 1 | 0 |
| Z3 | SUPPORTED | 1 | 0 |

**edna_observation evidence:** The initial eDNA detection (`historical_edna_measurement`) and all `directed_hydrological_connectivity` items have UNKNOWN compatibility for non-matching evidence types. The `historical_edna_measurement` type has no rule — compatibility is always UNKNOWN.  
**Status: PASS (topology path)**

---

### Stage 5 — Hydrology Tracing

**Method:** `GET /cases/{id}/map`, `GET /hydrology/upstream/{id}`  
**Expected:** 48 upstream reaches returned for Site A  
**Actual:**

| Query | Expected | Actual |
|---|---|---|
| `get_upstream_reaches(20446064)` | >0 upstream reaches | 48 reaches ✓ |
| `get_downstream_path(20450127, 20446064)` | valid path | verified by test ✓ |
| `is_upstream(20450127, 20449905)` | True | True ✓ |
| `first_common_downstream(Z2, Z3)` | 20449905 | 20449905 ✓ |
| `network_distance_km(20450127, 20446064)` | ~19 km | 19.350 km |

**Status: PASS**

---

### Stage 6 — Candidate Generation

**Method:** `GET /cases/{id}/generated-candidates`  
**Expected:** Candidates grouped by reachability signature, scored by pair separation  
**Actual (from `generated_candidate_snapshots` in the production database):**

| HYRIV_ID | Signature (Z1,Z2,Z3) | Pair score | Distance (km) |
|---|---|---|---|
| 20446568 | [0, 1, 1] | 2 | 2.286 |
| 20447392 | [1, 0, 0] | 2 | 3.586 |
| 20450127 | [0, 1, 0] | 2 | 19.226 |
| 20451169 | [0, 0, 1] | 2 | 23.936 |

Eligible reach count: 48. Equivalence classes: 5 (one with score=0 not represented as candidate). All four candidates tie at pair separation score = 2.

**Key observation:** The signature `[1,1,1]` class (reaches reachable by all three zones) gets score=0 and produces no candidate — correct behavior.

**Status: PASS**

---

### Stage 7 — Sampling Decision

#### Path A: `POST /cases/{id}/sampling-decision` (registered sites B, C, D)

| Site | HYRIV_ID | Signature (Z1,Z2,Z3) | Pair score |
|---|---|---|---|
| Site B | 20450127 | [0,1,0] | 2 |
| Site C | 20451169 | [0,0,1] | 2 |
| Site D | 20448315 | [1,1,1] | 0 |

Site D has signature [1,1,1] (all zones can reach it) → score = 0, does not discriminate.  
Sites B and C both score 2 → **TIE between B and C** (Site D excluded from tie).

**Note:** The database shows 3 site IDs in the TIE recommended_site_ids for this path `{4ce1b12b, a972ffc8, ec113d0a}` which correspond to Sites B, C, D — this means `evaluate_sampling_candidates` in `SamplingService` is passing the detection site in the site list and Site D is being evaluated alongside B and C. The TIE includes all three because all have `scientific_state_valid=True`. However Site D should score 0. The issue is Site D has HYRIV_ID 20448315 and all 3 zones' roots can reach it, giving score 0 — but the recommendation result says TIE with 3 sites. This deserves investigation.

Re-examining: `make_recommendation` returns TIE when multiple sites share `best_score`. If Site D scores 0 and B/C score 2, best_score=2, so only B and C should be in the TIE. The database showing 3 site IDs in the TIE `recommended_site_ids` for the first decision (rows 1, 3, 4) suggests that the `evaluate_sampling_candidates` call passes the detection site (Site A) as a candidate. Site A has HYRIV_ID 20446064. `can_contribute(Z1_root=20447392, 20446064)=True`, `can_contribute(Z2_root=20450127, 20446064)=True`, `can_contribute(Z3_root=20451169, 20446064)=True` → signature [1,1,1] → score 0. Still doesn't produce 3-way TIE.

Examining the IDs: `4ce1b12b=Site B`, `a972ffc8=Site C`, `ec113d0a=Site D`. Site D has HYRIV_ID 20448315. `can_contribute(20450127, 20448315)` and `can_contribute(20451169, 20448315)` need verification. If these return False (Z2 and Z3 cannot reach Site D reach), then Site D's signature is [1,0,0], score = 1×2 = 2. This would make B(2), C(2), D(2) all tie.

**Actual site D reachability verified from network data:** HYRIV_ID 20448315 is on the shared trunk downstream of Z1 but the Z2/Z3 branches may not route through it before reaching Site A. The shared-trunk classification in the CSV (`SHARED_TRUNK`) and the signature `[1,1,1]` from the candidate generator confirms all three zones reach HYRIV_ID 20448315. Therefore score = 3×0 = 0 — Site D should NOT be in the TIE.

**The 3-way TIE including Site D in the registered-site decision path is a discrepancy requiring further investigation.** It may indicate that `get_sites_by_case` returns Site A (the detection site) in addition to B, C, D, and Site A happens to have the same HYRIV_ID as one of the candidates, or the Site D HYRIV_ID in the database was actually stored differently than the CSV.

Actual HYRIV_IDs in database: `Site B=20450127, Site C=20451169, Site D=20448315`. `can_contribute(20447392, 20448315)`: Z1 root 20447392 → is it upstream of 20448315? Looking at the downstream path and the SHARED_TRUNK classification — 20448315 is labeled SHARED_TRUNK meaning Z2 and Z3 branches both flow into it before reaching Site A. So Z2 root (20450127) and Z3 root (20451169) ARE upstream of 20448315, and Z1 root (20447392) may also be upstream. If all three can reach 20448315, then signature=[1,1,1], score=0, and Site D is correctly excluded from the TIE — but the production database shows it included. This warrants a **defect report** (see Defect D7).

#### Path B: `POST /cases/{id}/reinvestigate` (generated transient candidates)

Decision: **TIE** with 4 transient site IDs (uuid5-based, not in sampling_sites table).  
Candidates: 20446568, 20447392, 20450127, 20451169 — all score 2.

**DEFECT P1/P2 CONFIRMED:** The two paths produce different recommended_site_ids for the same case at the same time. Path A produces real site UUIDs. Path B produces uuid5 transient IDs that do not exist in `sampling_sites`.

```sql
-- Verified: all 4 transient IDs absent from sampling_sites
SELECT '93a1b3dd...', '7ee99477...', '6f121353...', '818e5ae2...'
-- Result: f, f, f, f (none exist)
```

**Status: PARTIAL (Path A produces inconsistent 3-way TIE; Path B produces correct 4-way TIE with ghost IDs)**

---

### Stage 8 — Follow-up Sample Registration

**Method:** `POST /cases/{id}/follow-up-samples` then `POST /cases/{id}/reinvestigate`  
**Expected:** Sample persisted, linked evidence item created, reinvestigation records new evidence count  
**Actual (from unit tests and database):** Follow-up sample creation is verified by `test_follow_up_persists_links_evidence_without_decision`. The service atomically creates `FollowUpSampleModel` and a linked `EvidenceItemModel` of type `follow_up_edna_sample`. The Playwright test successfully registers a follow-up sample via the browser form and sees it displayed.

However the production database shows `COUNT(follow_up_samples) = 0` — the Playwright browser tests run against an isolated SQLite database (`/tmp/edna-browser-test.sqlite`), not the production PostgreSQL database.

**Evidence interpretation gap confirmed:** `follow_up_edna_sample` evidence type has no rule in `EvidenceCompatibilityEngineImpl`. Reinvestigation after follow-up registration produces identical hypothesis states. The trace correctly documents: *"New follow-up sample recorded, but no validated interpretation rule currently allows this observation to alter source hypotheses."*  
**Status: PARTIAL (persistence works; scientific interpretation does not)**

---

### Stage 9 — Report Generation

**Method:** Reports page (`/reports`)  
**Expected:** Full multi-section HTML report with all investigation data  
**Actual:** Playwright confirmed:
- eDNA concentration `1.2983219767633366e-17 mol/L` visible
- Rule ID `hydrorivers.directed_contribution.v1` visible
- MapLibre canvas rendered
- `#assumptions` section contains "remaining hypotheses"
- `#followup` section contains "Site B, Site C, Site D"
- TOC navigation to `#limitations` section works
- Print media CSS hides `.app-nav`
- PDF produced via `page.pdf()` with A4 format

**One Health pathway:** Hard-coded for Wigger H001 Fs case. Returns `fredericella_sultana_tb_monitoring_relevance.v1` pathway for this specific case. Any other taxon/date returns empty pathway list (P7).  
**Status: PASS (report renders); PARTIAL (One Health limited to Wigger)**

---

## 6. Database Integrity Findings

### 6.1 Schema

Production database `eDna` has **11 tables** matching the schema described in Part 1. The expected 17 tables referenced in the architecture document appear to be a counting error in the original report — only 11 distinct tables exist in the schema.

| Table | Present | Row count |
|---|---|---|
| cases | ✓ | 2 |
| sampling_sites | ✓ | 5 |
| candidate_zones | ✓ | 3 |
| evidence_items | ✓ | 4 |
| sampling_decisions | ✓ | 4 |
| decision_traces | ✓ | 4 |
| follow_up_samples | ✓ | 0 |
| investigation_runs | ✓ | 1 |
| hypothesis_states | ✓ | 3 |
| generated_candidate_snapshots | ✓ | 4 |
| alembic_version | ✓ | — |

### 6.2 Orphaned site check

```sql
SELECT id FROM sampling_sites WHERE case_id IS NULL;
-- Result: 0 rows
```

No orphaned sites in production. The architecture's P8 concern (detection site created before case could leave orphan) is mitigated by the explicit rollback in `create_case` in `cases.py` — however it remains a theoretical risk on failure between `db_site.case_id = case.id` and `db.commit()`.

### 6.3 Transient UUID integrity violation (P2 CONFIRMED)

The `sampling_decisions` table contains 4 rows. Row 2 (linked to `investigation_runs.new_decision_id`) has `recommended_site_ids` containing 4 UUIDs that do not exist in `sampling_sites`:

```
{93a1b3dd-fc9e-5c36-96c1-fd20e2b9f5fa,
 7ee99477-3773-5c75-ab1e-07e2c8dc6ff2,
 6f121353-658d-5b96-808d-40a7155fc6e0,
 818e5ae2-732c-5983-a32d-b5cb95e34d0b}
```

None of these UUIDs resolve to rows in `sampling_sites`. They are `uuid5(NAMESPACE_URL, f"investigation:{run.id}:{candidate.hyriv_id}")` transient IDs. Any code path that joins `sampling_decisions.recommended_site_ids` with `sampling_sites.id` will silently find nothing.

### 6.4 Decision trace consistency

All 4 `sampling_decisions` rows have corresponding `decision_traces` rows. FK integrity is intact. The investigation run's trace correctly includes both `hydrorivers.directed_contribution.v1` and `sampling.topology_pair_separation.v1` in `rules_applied`.

### 6.5 Hypothesis states

3 hypothesis states stored for the 1 completed investigation run: Z1=SUPPORTED, Z2=SUPPORTED, Z3=SUPPORTED. Consistent with the evidence assessment confirming all three zones have directed hydrological connectivity to Site A.

---

## 7. Confirmed Defects

### D1 — Dual Sampling Decision Evaluation Paths (SEVERITY: HIGH)

**Source:** Architecture P1  
**Confirmed by:** Database inspection, direct scientific engine calls  

`POST /cases/{id}/sampling-decision` evaluates the **persisted** `SamplingSite` records (B, C, D). `POST /cases/{id}/reinvestigate` generates transient sites from the candidate generator and evaluates those. The two paths evaluate different site sets against the same zones and can produce different decisions simultaneously for the same case.

For the Wigger case:
- Registered-site path: Sites B, C, D evaluated → TIE (3 sites, see D7 for further detail)
- Reinvestigation path: Generated candidates 20446568, 20447392, 20450127, 20451169 evaluated → TIE (4 sites, all transient)

A scientist reading `GET /cases/{id}/sampling-decision` sees a different result than the reinvestigation detail.

**Files:** `backend/app/api/routes/sampling.py:evaluate_sampling_decision()`, `backend/app/services/investigation_service.py:reinvestigate()`  
**Reproduction:** Run `POST /cases/{wigger_case_id}/sampling-decision` then `POST /cases/{wigger_case_id}/reinvestigate`. Compare the `recommended_site_ids` in each response.

---

### D2 — Transient Site IDs in Decision Records (SEVERITY: HIGH)

**Source:** Architecture P2  
**Confirmed by:** Database SQL query proving all 4 reinvestigation recommended_site_ids absent from `sampling_sites`  

During reinvestigation, `InvestigationService.reinvestigate()` creates `SamplingSite` objects in memory using `uuid5(NAMESPACE_URL, f"investigation:{run.id}:{candidate.hyriv_id}")`. These IDs are stored in `sampling_decisions.recommended_site_ids` but are never inserted into `sampling_sites`. Any lookup of recommended sites by ID from a reinvestigation decision will return no rows.

**Files:** `backend/app/services/investigation_service.py` lines ~66-76  
**Reproduction:**
```sql
SELECT sd.recommended_site_ids FROM sampling_decisions sd
  JOIN investigation_runs ir ON ir.new_decision_id = sd.id;
-- Returns UUIDs that do not exist in sampling_sites
```

---

### D3 — Preflight Data Reloaded on Every Sampling Request (SEVERITY: MEDIUM)

**Source:** Architecture P3  
**Confirmed by:** Source code inspection of `sampling.py`  

`get_sampling_service()` in `backend/app/api/routes/sampling.py` creates a new `WiggerPreflightLoader` and calls `loader.load_reaches()`, `loader.load_edges()`, and `loader.load_reach_geometries()` on **every HTTP request** to any sampling endpoint. This includes full CSV and GeoJSON file reads, DataFrame construction, and HydrologyEngine graph build — O(N) work where N=49 reaches, repeated per request.

The application correctly initializes a cached `_hydrology_engine` at startup via `initialize_engines()` in `dependencies.py`, but `sampling.py` does not use this cached instance — it creates its own fresh engine per request.

Affected endpoints: `GET /cases/{id}/map`, `GET /cases/{id}/generated-candidates`, `POST /cases/{id}/sites`, `GET/POST /cases/{id}/zones`, `POST /cases/{id}/sampling-decision`.

Additionally, `get_investigation_map()` makes a **second** `WiggerPreflightLoader` call inside the route handler (`geometries = WiggerPreflightLoader(...).load_reach_geometries()`), loading geometry data a second time in the same request.

**Files:** `backend/app/api/routes/sampling.py:get_sampling_service()` line 56, line 118  
**Reproduction:** Profile any sampling endpoint with repeated requests and observe file I/O per call.

---

### D4 — Duplicate Methods in SamplingRepository (SEVERITY: LOW)

**Source:** Architecture P4  
**Confirmed by:** Source code inspection of `sampling.py`  

`SamplingRepository` contains two definitions each of `_site_to_domain()`, `_zone_to_domain()`, and `_decision_to_domain()`. Python silently uses the second definition, overriding the first. The two definitions are functionally identical so there is no runtime error. However it makes the file misleadingly larger (≈260 extra lines), is a maintainability risk, and demonstrates the class was assembled from copy-paste without a deduplication pass.

**File:** `backend/app/repositories/sampling.py`

---

### D5 — Context Providers Are Non-Functional Stubs (SEVERITY: MEDIUM)

**Source:** Architecture P5  
**Confirmed by:** Source code inspection; `test_context_infrastructure.py` explicitly tests stub behavior  

All three context providers (`GBIFOccurrenceProvider`, `WeatherContextProvider`, `UrbanizationContextProvider`) raise `NotImplementedError`. Stage 2 of the scientific workflow (environmental context collection) cannot be completed. The UI allows users to trigger context collection, shows UNAVAILABLE status, and implies data was attempted but unavailable — which may mislead users into thinking the data exists but is temporarily unavailable rather than never having been implemented.

**Files:** `backend/app/context/providers/gbif.py`, `weather.py`, `urbanization.py`

---

### D6 — follow_up_edna_sample Evidence Has No Interpretation Rule (SEVERITY: MEDIUM)

**Source:** Architecture P6  
**Confirmed by:** `test_v3_scientific_boundaries.py::test_v3_evidence_types_remain_unknown_and_unassessed`, direct engine inspection  

`follow_up_edna_sample` evidence items are correctly persisted but are assessed as `EvidenceCompatibility.UNKNOWN` by `EvidenceCompatibilityEngineImpl`. Reinvestigation after field sampling produces identical hypothesis states. The investigation cycle Stage 8 → Stage 9 cannot complete meaningfully. The decision trace correctly documents this as a known limitation.

**Files:** `backend/app/scientific/evidence/engine.py`, `backend/app/scientific/rules/catalog.py`

---

### D7 — Registered-Site Decision TIE Incorrectly Includes Site D (SEVERITY: MEDIUM)

**Source:** New finding from E2E workflow verification  
**Confirmed by:** Database inspection, network analysis  

The `POST /cases/{id}/sampling-decision` path evaluates Sites B, C, D. Site D (HYRIV_ID 20448315, type SHARED_TRUNK) should have signature [1,1,1] (all three zones can reach it) and pair separation score = 0. Sites B and C should produce a 2-way TIE.

However the production database contains 3-site TIE decisions including Site D's UUID. This suggests either: (a) the HYRIV_ID stored for Site D in the database does not route the way the SHARED_TRUNK label implies, or (b) `get_sites_by_case` is returning an additional unexpected site. The generated_candidate_snapshots table confirms 20448315 is not present as a generated candidate — meaning the engine does not generate it as discriminating, which is consistent with score=0.

If Site D is genuinely non-discriminating but still appearing in the TIE, the `evaluate_sampling_candidates` → `make_recommendation` path has a filtering defect where zero-scoring sites are erroneously included in tie resolution.

**Files:** `backend/app/services/sampling_service.py:evaluate_sampling_candidates()`, `backend/app/scientific/sampling/engine.py:make_recommendation()`  
**Reproduction:**
```bash
# After loading demo:
curl -s http://localhost:8000/cases/{id}/sampling-decision -X POST
# Check recommended_site_ids — should contain only Sites B and C, not D
```

---

### D8 — geopandas Not in System Python Path (SEVERITY: MEDIUM)

**Source:** New finding from test execution  
**Confirmed by:** `ModuleNotFoundError: No module named 'geopandas'` on system Python  

The project virtualenv (`../venv/`) contains all required packages including `geopandas==1.0.1`. The system Python (`/usr/bin/python3`) does not. Running `python3 -m pytest` or `python3 backend/app/main.py` from outside the virtualenv will fail with import errors for 11 test files and all routes that use `WiggerPreflightLoader`.

There is no `activate` instruction in the README, no `Makefile`, and no CI configuration enforcing virtualenv use. This is a deployment and developer experience risk.

**Files:** `backend/requirements.txt` (correct), virtualenv activation instructions (missing from README)

---

### D9 — One Health Pathway Hard-Coded for Single Case (SEVERITY: LOW for current scope)

**Source:** Architecture P7  
**Confirmed by:** Source code inspection of `one_health_service.py`  

`OneHealthService._is_verified_fs_case()` checks `target_taxon == "Fredericella sultana"`, `station == "S1"`, `date == "2014-06-25"`, and `state == "DETECTED"`. Any new investigation returns an empty pathway list. The One Health module is non-functional for any case except the Wigger H001 demo.

---

### D10 — Sites Page Shows Only Demo Sites (SEVERITY: LOW)

**Source:** Architecture P10  
**Confirmed by:** Playwright test confirms Sites page loads from `demoApi.map()`, not case-scoped site query  

`frontend/src/pages/Sites.jsx` calls `demoApi.map()`, which returns static Wigger preflight geometry and sites. Investigations created by users outside the demo are invisible in the Sites page. Only 4 sites (A, B, C, D from the Wigger demo) ever appear.

---

## 8. Untested or Blocked Behavior

| Area | Status | Reason |
|---|---|---|
| Context collection (GBIF, weather, urbanization) | BLOCKED | All providers raise `NotImplementedError` |
| `POST /cases/{id}/context/collect` real data | BLOCKED | No live external APIs wired |
| follow_up_edna_sample hypothesis alteration | BLOCKED | No rule exists for this evidence type |
| One Health pathway for non-Wigger cases | BLOCKED | Hard-coded check in OneHealthService |
| Non-Wigger HYRIV_ID case creation | BLOCKED | All HYRIV_IDs must be in the Wigger 49-reach sub-network |
| Multi-network support | BLOCKED | Full HydroRIVERS Europe dataset loaded only in preflight scripts, not at runtime |
| Production database startup (docker-compose) | BLOCKED | No docker-compose.yml exists; PostgreSQL must be provisioned manually |
| Authentication/authorization | BLOCKED | No auth mechanism implemented; CORS allows `*` |
| PDF export quality | PARTIALLY TESTED | Browser `window.print()` / `page.pdf()` used; actual print CSS rendering depends on browser/OS |
| Reinvestigation change detection across runs | PARTIALLY TESTED | Only 1 run in production DB; tested by `test_investigation_runs.py` unit test |
| Candidate site map rendering | NOT TESTED | Generated candidates not added as map markers; no visual representation |

---

## 9. Overall Functional Verification Status

| Module | Status | Notes |
|---|---|---|
| Case creation and retrieval | PASS | HYRIV_ID validation working; rollback on failure verified |
| Demo data loading (Wigger) | PASS | Idempotent; all entities created correctly |
| Evidence ingestion | PASS | Schema validated; persists correctly |
| Evidence assessment (topology) | PASS | All three zones correctly assessed |
| Evidence assessment (other types) | KNOWN LIMITATION | Returns UNKNOWN — by design, documented |
| Hypothesis resolution | PASS | ConservativeResolver produces correct SUPPORTED states |
| Context collection | FAIL | All providers non-functional |
| Zone registration | PASS | Root HYRIV_ID validated; manual entry works |
| Hydrology engine | PASS | All 178 tests pass; distances and connectivity verified |
| Candidate generation | PASS | Correct signatures, scores, representatives |
| Sampling decision (registered sites) | PARTIAL | Site D inclusion in TIE is incorrect (D7) |
| Sampling decision (reinvestigate) | PARTIAL | Correct algorithm; transient IDs not in DB (D2) |
| Decision trace / audit trail | PASS | Complete and correct; rules and limitations documented |
| Follow-up sample registration | PASS | Atomic creation with linked evidence |
| Follow-up evidence interpretation | FAIL | No rule exists (D6) |
| Reinvestigation / versioned runs | PASS | Append-only history; change detection works |
| One Health pathway (Wigger) | PASS | Correct for Wigger H001 Fs case |
| One Health pathway (other) | FAIL | Returns empty for any other case (D9) |
| Report generation | PASS | All sections render; PDF export works |
| Sites page | PARTIAL | Shows only demo sites (D10) |
| Dashboard | PASS | Correct case and decision counts |
| Authentication | MISSING | Not implemented |
| Performance (preflight reload) | DEFECTIVE | Full file I/O per request (D3) |

### Test summary

| Suite | Collected | Passed | Failed | Skipped | Errors |
|---|---|---|---|---|---|
| Backend (venv pytest) | 178 | **178** | 0 | 0 | 0 |
| Playwright (all viewports) | 24 | **18** | 0 | **6** | 0 |
| Backend (system Python) | — | — | — | — | **11 collection errors** |

The 6 Playwright skips are intentional design guards. The 11 system Python collection errors are an environment defect (geopandas not installed system-wide).

---

*End of Part 2 Verification Report. No production code, configuration, database, or historical dataset was modified during this investigation.*
