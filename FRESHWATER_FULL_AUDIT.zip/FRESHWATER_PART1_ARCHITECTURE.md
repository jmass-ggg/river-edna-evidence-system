# FreshWater eDNA Evidence Investigator — Part 1: Architecture Report

**Prepared:** October 2, 2026  
**Scope:** Read-only investigation of the entire repository. No production code, configuration, database, or dataset was modified.

---

## 1. Executive Summary

FreshWater is a research-grade web application for investigating uncertain eDNA detections in urban freshwater systems. It is designed around the **Wigger River case study** (Carraro H001, *Fredericella sultana* at station S1, 2014-06-25) and uses a validated subset of HydroRIVERS v1.0 Europe as its river-network backbone.

The product has a working, clearly-layered architecture with a React/Vite frontend, a FastAPI/Python backend, PostgreSQL, and a set of immutable preflight data artifacts. The core scientific workflow — load a case, register evidence, define source zones, generate topology-based candidate sites, evaluate a sampling decision, persist an audit trace, register follow-up field results, and trigger a reinvestigation — is **substantially implemented end-to-end for the Wigger demo case**.

However, the implementation is tightly coupled to the single Wigger demonstration. Several of the nine intended workflow stages are either partially implemented, carry hard-coded assumptions, or lack runtime verification. The One Health pathway, context collection, and case-creation flows for non-Wigger species all have significant gaps. No authentication, no production configuration, and no external API integrations are operational.

---

## 2. Technology Stack

| Layer | Technology | Version |
|---|---|---|
| Frontend framework | React | 18.3 |
| Frontend build | Vite | (package.json default) |
| Frontend routing | React Router | 7.1 |
| Frontend map | MapLibre GL | 5.24 |
| Backend framework | FastAPI | 0.115.0 |
| Backend ASGI server | Uvicorn | 0.31.0 |
| Data validation | Pydantic v2 | 2.9.2 |
| ORM | SQLAlchemy | 2.0.35 |
| Database | PostgreSQL | (psycopg2-binary 2.9.9) |
| Migrations | Alembic | 1.13.3 |
| Data processing | pandas + geopandas + shapely | 2.2.3 / 1.0.1 / 2.0.6 |
| Scientific data | scipy (MATLAB .mat reader) | 1.14.1 |
| Geospatial projection | pyproj | (geopandas dependency) |
| Testing | pytest + hypothesis | 8.3.3 / 6.112.1 |
| River-network data | HydroRIVERS v1.0 Europe | Wigger sub-network |
| Historical eDNA data | Carraro et al. MATLAB files | H001 / Fs+Tb |

No authentication library, no message queue, no caching layer, no container orchestration configuration, and no cloud-specific SDK is present.

---

## 3. Architecture Overview

```mermaid
graph TD
    subgraph "Browser (React + Vite)"
        UI_Home[Home / Landing]
        UI_Dash[Dashboard]
        UI_Inv[Investigations List]
        UI_WS[Investigation Workspace]
        UI_Sites[Sites Browser]
        UI_Report[Reports / PDF export]
        UI_Map[ScientificMap — MapLibre GL]
        UI_API[api.js — REST client]
    end

    subgraph "FastAPI Backend (Uvicorn)"
        subgraph "API Routes"
            R_health[/health]
            R_cases[/cases]
            R_evidence[/cases/{id}/evidence*]
            R_sampling[/cases/{id}/sites, zones, decision*]
            R_candidates[/cases/{id}/generated-candidates]
            R_hydrology[/hydrology/*]
            R_demo[/demo/wigger*]
            R_context[/cases/{id}/context*]
            R_followup[/cases/{id}/follow-up-samples*]
            R_oneheal[/cases/{id}/one-health]
            R_invest[/cases/{id}/reinvestigate, investigation-runs*]
        end
        subgraph "Services"
            SVC_case[CaseService]
            SVC_evidence[EvidenceService]
            SVC_sampling[SamplingService]
            SVC_investigation[InvestigationService]
            SVC_oneheal[OneHealthService]
            SVC_followup[FollowUpSampleService]
            SVC_context[ContextCollectionService]
        end
        subgraph "Scientific Engines (stateless)"
            ENG_hydro[HydrologyEngine — directed graph]
            ENG_evidence[EvidenceCompatibilityEngineImpl]
            ENG_sampling[ScaffoldSamplingDecisionEngine]
            ENG_candidate[CandidateSiteGenerator]
            ENG_hypothesis[ConservativeHypothesisStateResolver]
        end
        subgraph "Repositories (SQLAlchemy)"
            REPO_case[CaseRepository]
            REPO_evidence[EvidenceRepository]
            REPO_sampling[SamplingRepository]
            REPO_invest[InvestigationRepository]
            REPO_followup[FollowUpSampleRepository]
        end
        PREFLIGHT[Preflight artifacts\ndata_preflight/outputs/]
        CARRARO[Carraro raw data\ndata_preflight/raw/carraro/]
    end

    subgraph "PostgreSQL"
        DB[(17 tables)]
    end

    UI_API -->|HTTP JSON| R_cases
    UI_API -->|HTTP JSON| R_evidence
    UI_API -->|HTTP JSON| R_sampling
    UI_API -->|HTTP JSON| R_candidates
    UI_API -->|HTTP JSON| R_demo
    UI_API -->|HTTP JSON| R_context
    UI_API -->|HTTP JSON| R_followup
    UI_API -->|HTTP JSON| R_oneheal
    UI_API -->|HTTP JSON| R_invest
    UI_API -->|HTTP JSON| R_hydrology

    R_cases --> SVC_case --> REPO_case --> DB
    R_evidence --> SVC_evidence --> REPO_evidence --> DB
    R_sampling --> SVC_sampling --> REPO_sampling --> DB
    R_invest --> SVC_investigation --> DB
    R_oneheal --> SVC_oneheal --> DB
    R_followup --> SVC_followup --> DB
    R_context --> SVC_context --> DB
    R_demo -->|idempotent load| DB

    SVC_sampling --> ENG_hydro
    SVC_sampling --> ENG_evidence
    SVC_sampling --> ENG_sampling
    SVC_sampling --> ENG_candidate
    SVC_investigation --> ENG_evidence
    SVC_investigation --> ENG_hypothesis
    SVC_investigation --> ENG_candidate
    SVC_investigation --> ENG_sampling

    ENG_hydro -->|reads on init| PREFLIGHT
    ENG_candidate -->|reads on init| PREFLIGHT
    R_demo -->|reads| PREFLIGHT
    R_demo -->|reads| CARRARO
```

---

## 4. Database Schema

**17 tables** in three groups:

### Core investigation tables
| Table | Purpose |
|---|---|
| `cases` | eDNA investigation case: taxon, observation date, detection site FK, status, metadata JSONB |
| `sampling_sites` | Sites (detection, branch-specific, shared-trunk, follow-up): lat/lon, HYRIV_ID, validation status |
| `candidate_zones` | Hypothetical source zones: root HYRIV_ID, member reach IDs array, validation status |
| `evidence_items` | Flexible evidence store: type, source, value JSONB, quality, provenance JSONB |
| `sampling_decisions` | Recommendation record: status enum, recommended_site_ids array, rationale |
| `decision_traces` | Full audit trail: evidence_used, rules_applied, hydrology_checks, assumptions, limitations |

### Follow-up tables
| Table | Purpose |
|---|---|
| `follow_up_samples` | Field sample results: replicate counts, assay, controls, collector source; FK to evidence_items |

### Investigation run tables
| Table | Purpose |
|---|---|
| `investigation_runs` | Versioned orchestration run: trigger type, status, snapshots (hypothesis/candidate/decision), timestamps |
| `hypothesis_states` | Per-zone resolved hypothesis state for one run: status, counts, rule IDs |
| `generated_candidate_snapshots` | Per-reach candidate output for one run: signature, pair score, distance |

---

## 5. Five Logical Modules

### Module 1 — Investigation Management

**Responsibility:** Case lifecycle, site registration, zone registration, evidence ingestion, context collection, follow-up sample registration. Persists all domain entities and enforces structural integrity.

**Key files:**
- `backend/app/services/case_service.py` — `CaseService.create_case()`, `get_case()`, `list_cases()`
- `backend/app/services/evidence_service.py` — `EvidenceService.add_evidence()`, `get_evidence_for_case()`, `assess_evidence_for_zones()`
- `backend/app/services/follow_up_sample_service.py` — `FollowUpSampleService.create()`, validates replicates, creates linked evidence item atomically
- `backend/app/services/case_service.py` — wraps repository with HTTP-friendly exceptions
- `backend/app/repositories/cases.py` — `CaseRepository`
- `backend/app/repositories/evidence.py` — `EvidenceRepository`
- `backend/app/repositories/follow_up_samples.py` — `FollowUpSampleRepository`
- `backend/app/api/routes/cases.py`, `evidence.py`, `follow_up_samples.py`, `context.py`
- `backend/app/context/service.py`, `providers/gbif.py`, `providers/weather.py`, `providers/urbanization.py`

**API endpoints:**
- `POST /cases` — create case (takes site coords + HYRIV_ID; creates detection site and case atomically)
- `GET /cases`, `GET /cases/{id}`
- `POST /cases/{id}/evidence`, `GET /cases/{id}/evidence`, `GET /cases/{id}/evidence-assessment`
- `POST /cases/{id}/context/collect`, `GET /cases/{id}/context`
- `POST /cases/{id}/follow-up-samples`, `GET /cases/{id}/follow-up-samples`

**Outputs:** Persisted Case, SamplingSite, EvidenceItem, FollowUpSample domain objects

**Relationships:** Feeds all other modules. Scientific Evidence Engine reads from its evidence store. Sampling Decision Engine reads zones created here.

**Known issues:**
- Context providers (GBIF, weather, urbanization) all raise `NotImplementedError` — no live data source is wired. They persist a PARTIAL/UNAVAILABLE evidence record with no actual data.
- The `create_case` API endpoint in `cases.py` atomically creates the detection site first, then the case. This means a detection site can exist without a case if the case creation fails.
- `EvidenceCompatibilityEngine` returns `UNKNOWN` for all evidence types except `directed_hydrological_connectivity`. The `edna_observation` evidence type created by the "New Investigation" form is assessed as `UNKNOWN` always.

---

### Module 2 — Scientific Evidence Engine

**Responsibility:** Apply validated scientific rules to assess evidence compatibility with source zone hypotheses. Resolve hypothesis states from cumulative assessments. Enforce the principle that no speculation beyond validated rules is produced.

**Key files:**
- `backend/app/scientific/evidence/engine.py` — `EvidenceCompatibilityEngineImpl.assess_evidence_for_zone()`, `summarize_zone_assessment()`
- `backend/app/scientific/hypothesis.py` — `ConservativeHypothesisStateResolver.resolve()`, `UnknownHypothesisStateResolver`
- `backend/app/scientific/rules/catalog.py` — `TOPOLOGY_CONTRIBUTION_RULE` ("hydrorivers.directed_contribution.v1"), `TOPOLOGY_STRENGTH_RULE`
- `backend/app/services/evidence_service.py` — `EvidenceService.assess_evidence_for_zones()`

**Inputs:** `Case`, `CandidateZone`, list of `EvidenceItem`

**Processing:** For each evidence item, applies matching rule from catalog. Only one compatibility rule exists (`directed_hydrological_connectivity`). Assigns UNKNOWN when no rule matches. `ConservativeHypothesisStateResolver` uses only validated directional rule IDs; all other evidence leaves hypothesis as UNKNOWN.

**Outputs:** `EvidenceAssessment` per item per zone, with compatibility (SUPPORTS/CONTRADICTS/NEUTRAL/UNKNOWN), strength (HIGH/MEDIUM/LOW/UNASSESSED), rule ID, reason, and full provenance.

**Limitations (by design):**
- Only one rule is validated and cataloged. No biological, abundance, degradation, transport, or detection-probability rules exist. This is architecturally deliberate and documented.
- `EvidenceStrength` assessment only applies to `directed_hydrological_connectivity`; all other types are UNASSESSED.
- Hypothesis resolver has no elimination criterion — even WEAKENED hypotheses remain eligible for candidate generation.

---

### Module 3 — Sampling Decision Engine

**Responsibility:** Generate topology-based candidate sampling sites from upstream river network, rank them by hypothesis pair-separation score, produce a traceable sampling recommendation.

**Key files:**
- `backend/app/scientific/sampling/candidate_generator.py` — `CandidateSiteGenerator.generate()` — enumerates upstream reaches, groups by reachability signature, selects nearest-to-A representative per equivalence class
- `backend/app/scientific/sampling/engine.py` — `ScaffoldSamplingDecisionEngine.evaluate_candidates()`, `make_recommendation()`, `create_decision_trace()`
- `backend/app/services/sampling_service.py` — `SamplingService.generate_sampling_candidates()`, `evaluate_sampling_candidates()`
- `backend/app/repositories/sampling.py` — `SamplingRepository.save_decision()` — atomically persists decision + trace
- `backend/app/api/routes/sampling.py` — `GET /cases/{id}/generated-candidates`, `POST /cases/{id}/sampling-decision`, `GET /cases/{id}/decision-trace`, `GET /cases/{id}/map`

**Score formula:** `pair_separation_score = reachable_count × (total_zones − reachable_count)` where a reach reaching r of n zones separates r×(n−r) unordered pairs. Purely topological — no probability, transport, or field-access component.

**Decision outcomes:** `RECOMMEND` (single winner), `TIE`, `ABSTAIN` (no site separates any pair), `INSUFFICIENT_DATA` (unverified network state)

**Outputs:** `CandidateGenerationResult` with equivalence classes and ranked representatives, `SamplingDecision` + `DecisionTrace`

**Relationships:** Depends on HydrologyEngine for reachability queries, reads zones from Investigation Management module.

**Known issues:**
- The `evaluate_sampling_candidates` method in the old `SamplingService` evaluates the **persisted** sites (B, C, D), not the generated candidates. The `reinvestigate` endpoint generates transient `SamplingSite` objects and evaluates those. These are two different evaluation paths.
- When the sampling decision endpoint is called directly via the UI (`POST /cases/{id}/sampling-decision`), it evaluates registered sites B, C, D against zones. When called via reinvestigate, it evaluates generated candidates. The UI does both and shows the result of the direct call.

---

### Module 4 — Reinvestigation Engine

**Responsibility:** Orchestrate a versioned, full-pass investigation run triggered by new evidence or follow-up samples. Produce comparable snapshots for change detection.

**Key files:**
- `backend/app/services/investigation_service.py` — `InvestigationService.reinvestigate()` (the main orchestrator), `detail()`, `list()`
- `backend/app/repositories/investigations.py` — `InvestigationRepository.create_running()`, `mark_failed()`, `latest_completed()`
- `backend/app/api/routes/investigations.py` — `POST /cases/{id}/reinvestigate`, `GET /cases/{id}/investigation-runs`, `GET /cases/{id}/investigation-runs/{run_id}`
- DB tables: `investigation_runs`, `hypothesis_states`, `generated_candidate_snapshots`

**Workflow per run:**
1. Validate trigger (MANUAL, EVIDENCE, or FOLLOW_UP_SAMPLE)
2. Load all evidence and zones for case
3. `EvidenceCompatibilityEngineImpl.assess_evidence_for_zone()` for each zone
4. `ConservativeHypothesisStateResolver.resolve()` for each zone
5. `CandidateSiteGenerator.generate()` on eligible zones (all zones since no elimination)
6. Create transient `SamplingSite` objects for each generated candidate
7. `ScaffoldSamplingDecisionEngine.evaluate_candidates()` on transient sites
8. `make_recommendation()` → `create_decision_trace()`
9. Persist `SamplingDecisionModel`, `DecisionTraceModel`, `HypothesisStateModel[]`, `GeneratedCandidateSnapshotModel[]`, update `InvestigationRunModel`

**Outputs:** Versioned run with hypothesis snapshot, candidate snapshot, decision snapshot; change detection vs previous run.

**Known issues:**
- Follow-up `edna_observation` evidence (type `follow_up_edna_sample`) is recorded in `EvidenceItemModel` but no validated rule exists to interpret it. The limitation message confirms this is known: "New follow-up sample recorded, but no validated interpretation rule currently allows this observation to alter source hypotheses."
- The reinvestigation always keeps all zones eligible (no elimination criterion). Every run produces the same hypothesis states unless new `directed_hydrological_connectivity` evidence is added.
- Transient sites created during reinvestigation use `uuid5(NAMESPACE_URL, ...)` — they are not persisted to `sampling_sites`, meaning the `recommended_site_ids` in the decision refer to IDs that do not exist in the DB.

---

### Module 5 — Scientific Communication

**Responsibility:** Produce structured investigation reports (frontend), One Health relevance pathways (backend), draft PDF export, and decision trace presentation.

**Key files:**
- `frontend/src/pages/Reports.jsx` — full report layout: detection, evidence assessment, hydrology, map, competing sources, candidate comparison, decision, follow-up, context, methodology, assumptions, limitations; browser `window.print()` for PDF export
- `backend/app/services/one_health_service.py` — `OneHealthService.assess()` — returns `fredericella_sultana_tb_monitoring_relevance.v1` pathway only when case is exactly the Wigger H001 Fs detection
- `backend/app/api/routes/one_health.py` — `GET /cases/{id}/one-health`
- `backend/app/domain/models.py` — `OneHealthAssessment`, `OneHealthPathway`, `OneHealthClaim` domain objects
- `backend/app/schemas/one_health.py` — Pydantic schemas for API response

**Outputs:** HTML report rendered in browser (printable as PDF), One Health pathway JSON

**Known issues:**
- One Health pathway is hard-coded for the Wigger H001 *Fredericella sultana* case. Any other taxon, station, or date returns an empty pathway list. There is no general pathway generation logic.
- PDF export uses browser `window.print()` — no programmatic PDF generation library. Actual output quality depends entirely on browser print CSS.
- The Reports page is read-only; it calls `loadCaseBundle` but offers no edit actions.
- The `latestDecision` API call in `loadCaseBundle` returns the latest `SamplingDecision`; the trace endpoint returns the trace. These are fetched sequentially (trace depends on decision existing), which is correctly handled.

---

## 6. Architecture Data-Flow Diagram

```mermaid
sequenceDiagram
    participant Browser
    participant FastAPI
    participant DB as PostgreSQL
    participant Preflight as Preflight Artifacts

    Browser->>FastAPI: GET /demo/wigger
    FastAPI->>Preflight: load site_a.json, candidate_zones_real.geojson, candidate_sampling_sites.csv
    FastAPI->>Preflight: load eDNA_data.mat, RUN_MODEL.m (Carraro)
    FastAPI->>DB: INSERT cases, sampling_sites x4, candidate_zones x3
    FastAPI->>DB: INSERT evidence_items (H001 observation + 3 topology items)
    FastAPI-->>Browser: {case_id, sites_created:4, zones_created:3}

    Browser->>FastAPI: GET /cases/{id}/evidence-assessment
    FastAPI->>DB: SELECT evidence_items WHERE case_id
    FastAPI->>DB: SELECT candidate_zones WHERE case_id
    FastAPI->>FastAPI: EvidenceCompatibilityEngineImpl.assess_evidence_for_zone() × 3 zones
    FastAPI-->>Browser: [{zone_id, assessments:[{compatibility, rule_id, reason}]}]

    Browser->>FastAPI: GET /cases/{id}/generated-candidates
    FastAPI->>Preflight: WiggerPreflightLoader (reaches, edges, geometries, snap validation)
    FastAPI->>FastAPI: HydrologyEngine.get_upstream_reaches(site_a_hyriv_id)
    FastAPI->>FastAPI: CandidateSiteGenerator.generate(zones, site_a_hyriv_id)
    FastAPI-->>Browser: {candidates:[{hyriv_id, signature, pair_separation_score}]}

    Browser->>FastAPI: POST /cases/{id}/sampling-decision
    FastAPI->>DB: SELECT sampling_sites, candidate_zones WHERE case_id
    FastAPI->>FastAPI: ScaffoldSamplingDecisionEngine.evaluate_candidates()
    FastAPI->>FastAPI: make_recommendation() → RECOMMEND|TIE|ABSTAIN|INSUFFICIENT_DATA
    FastAPI->>DB: INSERT sampling_decisions, decision_traces
    FastAPI-->>Browser: {status, recommended_site_ids, rationale}

    Browser->>FastAPI: POST /cases/{id}/follow-up-samples
    FastAPI->>DB: INSERT follow_up_samples
    FastAPI->>DB: INSERT evidence_items (follow_up_edna_sample)
    FastAPI-->>Browser: {id, hyriv_id, replicate_count, ...}

    Browser->>FastAPI: POST /cases/{id}/reinvestigate
    FastAPI->>DB: SELECT evidence_items, candidate_zones WHERE case_id
    FastAPI->>FastAPI: EvidenceCompatibilityEngineImpl + ConservativeHypothesisStateResolver
    FastAPI->>FastAPI: CandidateSiteGenerator.generate() → GeneratedCandidateSite[]
    FastAPI->>FastAPI: ScaffoldSamplingDecisionEngine on transient sites
    FastAPI->>DB: INSERT investigation_runs, hypothesis_states, generated_candidate_snapshots
    FastAPI->>DB: INSERT sampling_decisions, decision_traces
    FastAPI-->>Browser: {investigation_run_id, hypotheses, candidates, decision, changed:{}}
```

---

## 7. Nine-Stage Comparison: Intended vs Actual

### Stage 1 — Input the eDNA Case
**Intended:** Input species, location, date, replicates, laboratory metadata.

**Actual:** 
- `POST /cases` creates a case from taxon name, observation date, site coordinates, and a HYRIV_ID. The detection site is created implicitly.
- The "New Investigation" form in `Investigations.jsx` captures name, species, lat/lon, HYRIV_ID, date, one replicate result, and optional metadata. It calls `casesApi.create()` then optionally `evidenceApi.create()` for the replicate.
- The HYRIV_ID must be entered manually by the user — there is no map-based selection, nearest-reach lookup, or coordinate-to-network snapping in the creation flow.
- Replicate data is stored as a single `edna_observation` evidence item with `value: {replicate_results: ["Positive"]}`. No replicate count validation, no assay metadata schema, and this evidence type is never assessed by any rule.

**Relevant code:** `frontend/src/pages/Investigations.jsx` → `NewInvestigationForm`, `backend/app/api/routes/cases.py`, `backend/app/services/case_service.py`

**Tests:** `test_case_creation_integration.py`, `test_services.py`

**Status:** `PARTIAL`

**Missing/Defective:**
- No coordinate-to-HYRIV_ID snapping in the creation path (must be done offline)
- Replicate data schema is not validated; assay, controls, lab metadata are free text in `metadata` only
- `edna_observation` evidence type has no associated rule, so the initial observation never influences hypothesis assessment

---

### Stage 2 — Collect Scientific and Urban Freshwater Context
**Intended:** Collect environmental and urban context relevant to the detection.

**Actual:**
- Three context providers exist: `GBIFOccurrenceProvider` (`gbif.py`), `WeatherContextProvider` (`weather.py`), `UrbanizationContextProvider` (`urbanization.py`)
- All three raise `NotImplementedError` — they are structural placeholders only
- `ContextCollectionService.collect()` catches `NotImplementedError` and returns `ContextProviderStatus.UNAVAILABLE`
- The UI shows provider status and limitations; no actual context data is ever returned
- `POST /cases/{id}/context/collect` calls all providers but records nothing useful

**Relevant code:** `backend/app/context/providers/`, `backend/app/context/service.py`, `backend/app/context/interfaces.py`

**Tests:** `test_context_infrastructure.py` — tests service orchestration but not actual data collection (providers are stubs)

**Status:** `MISSING` (infrastructure exists, data collection not implemented)

---

### Stage 3 — Define Plausible Upstream Source Hypotheses
**Intended:** Define candidate source zones using river-network knowledge.

**Actual:**
- The demo loads three pre-validated zones (Z1, Z2, Z3) from `candidate_zones_real.geojson` via `GET /demo/wigger`
- The frontend workspace has a `ZoneForm` component allowing manual zone registration: label, root HYRIV_ID, comma-separated reach IDs
- `POST /cases/{id}/zones` validates the root HYRIV_ID exists in the network graph and persists the zone
- Zone reach IDs are entered manually — no tool assists the scientist in identifying upstream reaches from a map
- Validation status defaults to `NOT_VERIFIED` when entered manually

**Relevant code:** `backend/app/api/routes/sampling.py:create_candidate_zone()`, `frontend/src/pages/InvestigationWorkspace.jsx:ZoneForm`

**Tests:** Property tests in `test_sampling_properties.py`

**Status:** `PARTIAL`

**Missing:** No interactive map-based zone drawing, no upstream reach suggestion tool, no automated zone generation from a HYRIV_ID boundary

---

### Stage 4 — Assess the Evidence Against Each Hypothesis
**Intended:** Assess scientific evidence for each candidate zone.

**Actual:**
- `GET /cases/{id}/evidence-assessment` applies `EvidenceCompatibilityEngineImpl` to all evidence items against all zones
- The demo automatically loads `directed_hydrological_connectivity` evidence for each zone (Z1, Z2, Z3) via `_ensure_wigger_evidence()` in demo.py
- The topology rule correctly classifies each zone as SUPPORTS (if can_contribute=True) or CONTRADICTS (if False) for the Wigger case
- `ConservativeHypothesisStateResolver` resolves hypothesis states based on these assessments
- All other evidence types (including the initial `edna_observation`) return `UNKNOWN`
- The frontend workspace shows per-zone assessment results with compatibility labels

**Relevant code:** `backend/app/scientific/evidence/engine.py`, `backend/app/scientific/rules/catalog.py`, `backend/app/scientific/hypothesis.py`

**Tests:** `test_evidence_properties.py` (property-based), `test_services.py`

**Status:** `PARTIAL` (works for topology evidence; no biological or multi-criterion rules)

**Missing:** Only one evidence type (`directed_hydrological_connectivity`) produces non-UNKNOWN results. Real investigations require abundance, presence/absence, and environmental co-variate rules that do not yet exist.

---

### Stage 5 — Trace Potential Sources Using River Network and Flow Direction
**Intended:** Use river-network topology to trace connectivity from candidate zones to detection site.

**Actual:**
- `HydrologyEngine` provides: `get_upstream_reaches()` (BFS), `get_downstream_path()`, `is_upstream()`, `can_contribute()`, `first_common_downstream()`, `network_distance_km()`, `zone_can_contribute_to_site()`
- Network is loaded from `upstream_reaches_real.csv` and `upstream_edges.csv` (Wigger sub-network only)
- `GET /hydrology/reaches/{id}`, `/upstream/{id}`, `/downstream/{id}`, `/distance` expose these to the frontend
- The `ScientificMap` renders the river network GeoJSON and source zone overlays
- The `GET /cases/{id}/map` endpoint assembles case-specific map data: upstream reaches of the detection site + zone reach overlays

**Relevant code:** `backend/app/scientific/hydrology/engine.py`, `backend/app/api/routes/hydrology.py`, `frontend/src/components/ScientificMap.jsx`

**Tests:** `test_hydrology_engine.py`, `test_hydrology_properties.py` (property-based, comprehensive)

**Status:** `COMPLETE` for the Wigger network. The network is limited to the validated Wigger sub-network — any HYRIV_ID outside this network will raise `ValueError`.

**Limitation:** Only the Wigger sub-network is loaded. The full HydroRIVERS Europe dataset is present in `HydroRIVERS_v10_eu_shp/` but is not loaded at runtime.

---

### Stage 6 — Generate and Compare Candidate Sampling Locations
**Intended:** Generate candidate sampling sites and compare their discrimination power.

**Actual:**
- `CandidateSiteGenerator.generate()` enumerates all upstream reaches of the detection site, groups by hypothesis reachability signature, and selects the nearest-to-A representative per equivalence class
- `pair_separation_score = reachable_count × (n − reachable_count)` is the sole ranking criterion
- `GET /cases/{id}/generated-candidates` returns candidates with signatures, pair scores, distance, and which hypothesis pairs each candidate distinguishes
- `ScaffoldSamplingDecisionEngine.evaluate_candidates()` + `make_recommendation()` produce a `RECOMMEND`, `TIE`, `ABSTAIN`, or `INSUFFICIENT_DATA` result
- The frontend workspace `SimpleCandidates` table shows reach, signature, distinguished pairs, pair score, and distance
- The `Reports.jsx` page also renders candidate comparison with an explanatory note about equivalence classes

**Relevant code:** `backend/app/scientific/sampling/candidate_generator.py`, `backend/app/scientific/sampling/engine.py`, `backend/app/api/routes/sampling.py`

**Tests:** `test_sampling_properties.py` (property-based), `test_benchmark_sampling.py`

**Status:** `COMPLETE` (topology criterion only, by design)

**Limitation:** Generated candidates are not automatically registered as `SamplingSite` records. The `POST /cases/{id}/sampling-decision` endpoint evaluates the **persisted** sites (B, C, D from demo), while `POST /cases/{id}/reinvestigate` evaluates the **generated** transient candidates. This dual path can produce different decisions.

---

### Stage 7 — Collect Targeted Field Samples Outside the Software
**Intended:** Field sampling occurs outside the system; no software action.

**Actual:** This stage correctly has no software component. The UI displays next-steps guidance. The follow-up registration in Stage 8 is the re-entry point.

**Status:** `COMPLETE` (correctly out-of-scope)

---

### Stage 8 — Register New Evidence and Update the Investigation
**Intended:** Register collected field samples, update evidence, trigger reinvestigation.

**Actual:**
- `POST /cases/{id}/follow-up-samples` accepts full sample metadata (replicate counts, assay, controls, collector source, provenance) and atomically creates both a `FollowUpSampleModel` and a linked `EvidenceItemModel` of type `follow_up_edna_sample`
- The frontend workspace `FollowUpForm` allows selecting a site or candidate reach, entering sampling datetime, replicate counts, assay, controls, and collector source
- `POST /cases/{id}/reinvestigate` triggers a full investigation run incorporating all current evidence
- `GET /cases/{id}/investigation-runs` and `/{run_id}` expose run history with change detection

**Relevant code:** `backend/app/services/follow_up_sample_service.py`, `backend/app/services/investigation_service.py`, `frontend/src/pages/InvestigationWorkspace.jsx:FollowUpForm`

**Tests:** `test_follow_up_samples.py`, `test_investigation_runs.py`

**Status:** `PARTIAL`

**Missing/Known gaps:**
- `follow_up_edna_sample` evidence type is persisted but never interpreted by any rule. The reinvestigation limitation message explicitly states this.
- Re-investigation always produces the same hypothesis states unless `directed_hydrological_connectivity` evidence is explicitly added; follow-up samples currently do not alter the investigation outcome
- Recommended site IDs in decisions created during reinvestigation reference transient UUID5 site IDs that do not exist in the `sampling_sites` table

---

### Stage 9 — Communicate Monitoring Outcomes and One Health Relevance
**Intended:** Generate report and communicate One Health context.

**Actual:**
- `Reports.jsx` renders a comprehensive multi-section HTML report covering all investigation stages
- Browser `window.print()` is used for PDF export — no server-side rendering
- `GET /cases/{id}/one-health` returns One Health pathways via `OneHealthService.assess()`
- The One Health pathway is fully implemented for the specific Wigger H001 *Fredericella sultana* case with species-specific references and structured claim objects
- The Reports page links the One Health pathway (Fs→Tb monitoring relevance) if context evidence exists

**Relevant code:** `frontend/src/pages/Reports.jsx`, `backend/app/services/one_health_service.py`, `backend/app/schemas/one_health.py`

**Tests:** No specific report or One Health unit tests found

**Status:** `PARTIAL`

**Missing/Known gaps:**
- One Health pathway is hard-coded for Wigger H001 Fs. Any other taxon, station, or date yields an empty pathway list
- PDF quality depends entirely on browser print CSS, not a dedicated rendering library
- No evidence that the report has been validated against scientific review requirements

---

## 8. Feature Inventory

| Feature | Status | Notes |
|---|---|---|
| Case creation (new investigation form) | PARTIAL | Manual HYRIV_ID entry; no snapping |
| Demo case loading (Wigger) | COMPLETE | Idempotent; loads case, sites, zones, evidence |
| Evidence ingestion | PARTIAL | Only topology evidence has a rule |
| Evidence assessment against zones | PARTIAL | One rule type produces non-UNKNOWN results |
| Hypothesis state resolution | PARTIAL | ConservativeResolver; no elimination criterion |
| Context collection (GBIF, weather, urban) | MISSING | All providers raise NotImplementedError |
| Zone registration (manual) | PARTIAL | No map assistance; NOT_VERIFIED default |
| Zone loading from preflight (demo) | COMPLETE | Three Wigger zones loaded with VERIFIED status |
| Hydrology queries (upstream, downstream, distance) | COMPLETE | Wigger sub-network only |
| Map rendering (river network + zones + sites) | COMPLETE | MapLibre GL; HydroRIVERS GeoJSON |
| Candidate generation (topology pair-separation) | COMPLETE | Topology criterion only |
| Sampling decision evaluation (registered sites) | PARTIAL | Different evaluation path than reinvestigate |
| Sampling decision evaluation (reinvestigate) | COMPLETE | Transient generated candidates |
| Decision trace / audit trail | COMPLETE | Full provenance including rules, assumptions, limitations |
| Follow-up sample registration | COMPLETE | Atomically creates evidence record |
| Follow-up evidence interpretation | MISSING | follow_up_edna_sample has no rule |
| Reinvestigation (versioned run) | PARTIAL | Follow-up samples don't alter outcome |
| Investigation run history / change detection | COMPLETE | Snapshot comparison across runs |
| One Health pathway (Fs/Tb Wigger) | COMPLETE | Hard-coded Wigger case only |
| One Health pathway (other taxa) | MISSING | Empty pathway for any other case |
| Report generation (HTML) | COMPLETE | All sections rendered |
| Report export (PDF) | PARTIAL | Browser print only; no PDF library |
| Case list and filtering | COMPLETE | Status, decision, date, and text filters |
| Sites browser | PARTIAL | Demo sites only; reads /demo/wigger/map |
| Dashboard metrics | PARTIAL | Calls API but metrics may be stale |
| Authentication | MISSING | CORS allows all origins; no auth |
| Multi-network support (non-Wigger) | MISSING | Only Wigger sub-network loaded |

---

## 9. Confirmed Architectural Problems

### P1 — Dual Sampling Decision Evaluation Paths
`POST /cases/{id}/sampling-decision` evaluates the **persisted** `SamplingSite` records (B, C, D). `POST /cases/{id}/reinvestigate` generates transient sites and evaluates those. The two paths can produce different recommendations for the same case at the same time. The UI calls both and shows the `sampling-decision` result in the workspace and the reinvestigation result separately, but a user may not realize these are evaluated against different site sets.

Files: `backend/app/api/routes/sampling.py:evaluate_sampling_decision()`, `backend/app/services/investigation_service.py:reinvestigate()`

### P2 — Transient Site IDs in Decision Records
During reinvestigation, `SamplingSite` objects are created in memory with `uuid5(NAMESPACE_URL, ...)`. These are evaluated and their IDs are stored as `recommended_site_ids` in `SamplingDecisionModel`. These IDs do not exist in the `sampling_sites` table. Any code that tries to look up a recommended site by ID from a reinvestigation decision will find nothing.

File: `backend/app/services/investigation_service.py` lines ~66-76

### P3 — Preflight Loaded on Every Request (Sampling Routes)
`get_sampling_service()` in `sampling.py` creates a new `WiggerPreflightLoader`, loads reaches CSV, edges CSV, and reach geometries GeoJSON on every request. This is called by all sampling endpoints (sites, zones, generated-candidates, map, decision, zones). This means full file I/O and DataFrame construction on every HTTP request with no caching.

File: `backend/app/api/routes/sampling.py:get_sampling_service()`

### P4 — Duplicate `_site_to_domain` and `_zone_to_domain` in SamplingRepository
`SamplingRepository` contains two definitions each of `_site_to_domain()` and `_zone_to_domain()` — the second definitions override the first. Python silently accepts this. The duplicate methods are identical, so there is no functional error, but it is a code quality issue.

File: `backend/app/repositories/sampling.py`

### P5 — Context Providers Are Non-Functional Stubs
All three context providers (`GBIFOccurrenceProvider`, `WeatherContextProvider`, `UrbanizationContextProvider`) raise `NotImplementedError`. The UI allows users to "Collect available context" and shows UNAVAILABLE/ERROR status, which is confusing. Stage 2 of the workflow cannot be completed with any real data.

Files: `backend/app/context/providers/gbif.py`, `weather.py`, `urbanization.py`

### P6 — follow_up_edna_sample Evidence Has No Rule
Follow-up sample registration correctly creates an `EvidenceItem` of type `follow_up_edna_sample`. However, `EvidenceCompatibilityEngineImpl` has no rule for this type, so it always returns UNKNOWN. Reinvestigation after field sampling produces the same hypothesis states and decision as before the sample was registered. The system correctly documents this as a limitation, but it means Stage 8 cannot complete the intended investigation update cycle.

Files: `backend/app/scientific/evidence/engine.py`, `backend/app/scientific/rules/catalog.py`

### P7 — One Health Pathway Is Hard-Coded for Single Case
`OneHealthService._is_verified_fs_case()` checks that `target_taxon == "Fredericella sultana"`, `station == "S1"`, `date == "2014-06-25"`, and `state == "DETECTED"`. Any case with a different species, date, or station returns an empty pathway list. This means the entire One Health module is non-functional for any new investigation.

File: `backend/app/services/one_health_service.py`

### P8 — No Authentication or Authorization
CORS middleware allows all origins (`allow_origins=["*"]`). No API key, OAuth, JWT, or session mechanism exists anywhere in the stack. The application is fully open. The comment `# TODO: Configure based on deployment environment` is present but unaddressed.

File: `backend/app/main.py`

### P9 — `edna_observation` Evidence Type Has No Assessment Rule
The initial eDNA observation created by the case creation form (type `edna_observation`) is never assessed by any rule. This is the primary observation motivating the entire investigation, yet it has no scientific interpretation path. It appears in the evidence list but its compatibility with any hypothesis is always UNKNOWN.

Files: `backend/app/scientific/rules/catalog.py`, `backend/app/scientific/evidence/engine.py`

### P10 — Sites Page Only Shows Demo Sites
`frontend/src/pages/Sites.jsx` calls `demoApi.map()` (which returns the static Wigger preflight geometry), not any case-specific site list. Any new investigation created by a user is not visible in the Sites page. The page is effectively a Wigger-only view.

File: `frontend/src/pages/Sites.jsx`

---

## 10. Questions and Uncertainties for Part 2

The following items require runtime verification or deeper investigation:

### Architecture
- **Q1:** Does the application start successfully from a clean PostgreSQL database? The demo endpoint is idempotent, but migrations must be run first. Is there a `docker-compose` or startup script that handles this? (No `docker-compose.yml` was found in the repository.)
- **Q2:** Does the `data_preflight/outputs/` directory contain all required files (`site_a.json`, `upstream_reaches_real.csv`, `upstream_edges.csv`, `candidate_zones_real.geojson`, `candidate_sampling_sites.csv`, `sampling_design_validation.json`, `upstream_reaches_real.geojson`, `site_a_snap_validation.json`)? The application will fail to start if any are missing.
- **Q3:** What is the Wigger sub-network size? How many reaches are in `upstream_reaches_real.csv`? This determines the candidate generation search space.

### Scientific correctness
- **Q4:** Does the evidence assessment produce the expected results for the Wigger demo case? Specifically: do all three zones (Z1, Z2, Z3) get the expected SUPPORTS/CONTRADICTS/NEUTRAL classifications? This requires runtime verification.
- **Q5:** Does the sampling decision engine recommend the correct site (B, C, or D) for the Wigger case under the registered-site evaluation path? What does it return under the reinvestigation path?
- **Q6:** The `root_hyriv_id` of each zone is computed in the demo loader as the reach with the largest `UPLAND_SKM` within the zone. Is this correct? The scientific design document should confirm the intended zone root selection criterion.

### Data integrity
- **Q7:** Do the transient `uuid5` site IDs in reinvestigation decisions cause problems in practice? Are they ever looked up after the run completes? The `detail()` method in `InvestigationService` returns `recommended_site_ids` from the snapshot, but the UI also shows the decision status — does the UI ever try to resolve those IDs to site labels?
- **Q8:** Are there any orphaned `SamplingSiteModel` records without a `case_id`? The demo creates Site A before the case, and if case creation fails, the site would have `case_id = NULL`.

### Testing gaps
- **Q9:** Do the property-based tests in `test_hydrology_properties.py`, `test_evidence_properties.py`, and `test_sampling_properties.py` pass currently? The `.hypothesis/` directory exists, suggesting they have been run, but no test report is available.
- **Q10:** Are there integration tests that test the full request-to-database round-trip for the Wigger demo workflow? The existing unit tests mock engines or use SQLite; it is unclear whether any test exercises the full PostgreSQL stack.

### Frontend
- **Q11:** Does the "Start investigation" / "New investigation" form work end-to-end for a non-Wigger species? The HYRIV_ID must correspond to the Wigger sub-network. What happens if a user enters a HYRIV_ID that is not in the loaded network?
- **Q12:** Does the map render correctly when the Wigger demo is loaded? Are all four sites (A, B, C, D) and three zone overlays (Z1, Z2, Z3) visible?

---

*End of Part 1 Architecture Report. No code was modified during this investigation.*
