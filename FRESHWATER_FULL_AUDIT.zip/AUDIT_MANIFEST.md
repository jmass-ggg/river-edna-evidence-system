# FreshWater eDNA Evidence Investigator — Audit Manifest

**Prepared:** October 2026  
**Archive:** `FRESHWATER_FULL_AUDIT.zip`  
**Purpose:** External code review covering 15 issues across scientific validation, existing functionality, and AI integration.

---

## 1. Actual Project Directory Structure

```
freshwater-edna/                         ← archive root (mapped from workspace root)
│
├── backend/                             ← Python / FastAPI backend
│   ├── app/
│   │   ├── main.py                      ← FastAPI application entry point
│   │   ├── api/
│   │   │   ├── dependencies.py          ← engine initialisation + DI factories
│   │   │   └── routes/
│   │   │       ├── cases.py             ← POST/GET /cases
│   │   │       ├── evidence.py          ← POST/GET /cases/{id}/evidence*
│   │   │       ├── sampling.py          ← sites, zones, candidates, decision, map
│   │   │       ├── investigations.py    ← reinvestigate, investigation-runs
│   │   │       ├── demo.py              ← GET /demo/wigger, /demo/wigger/map
│   │   │       ├── follow_up_samples.py ← POST/GET /cases/{id}/follow-up-samples
│   │   │       ├── context.py           ← POST /cases/{id}/context/collect
│   │   │       ├── one_health.py        ← GET /cases/{id}/one-health
│   │   │       ├── hydrology.py         ← GET /hydrology/reaches, upstream, distance
│   │   │       └── health.py            ← GET /health
│   │   ├── context/
│   │   │   ├── interfaces.py            ← ContextProvider protocol
│   │   │   ├── service.py               ← ContextCollectionService
│   │   │   └── providers/
│   │   │       ├── gbif.py              ← GBIFOccurrenceProvider (stub — NotImplementedError)
│   │   │       ├── weather.py           ← WeatherContextProvider (stub — NotImplementedError)
│   │   │       └── urbanization.py      ← UrbanizationContextProvider (stub — NotImplementedError)
│   │   ├── db/
│   │   │   ├── base.py                  ← SQLAlchemy declarative base
│   │   │   ├── models.py                ← all ORM models (11 tables)
│   │   │   └── session.py               ← engine factory, get_db, create_tables
│   │   ├── domain/
│   │   │   ├── enums.py                 ← all domain enumerations
│   │   │   └── models.py                ← domain dataclasses (Case, EvidenceItem, …)
│   │   ├── preflight/
│   │   │   └── carraro_v4.py            ← CarraroV4Extractor (preflight processing)
│   │   ├── repositories/
│   │   │   ├── cases.py                 ← CaseRepository
│   │   │   ├── evidence.py              ← EvidenceRepository
│   │   │   ├── follow_up_samples.py     ← FollowUpSampleRepository
│   │   │   ├── investigations.py        ← InvestigationRepository
│   │   │   └── sampling.py              ← SamplingRepository (⚠ duplicate methods — defect D4)
│   │   ├── schemas/
│   │   │   ├── cases.py
│   │   │   ├── context.py
│   │   │   ├── evidence.py
│   │   │   ├── follow_up_samples.py
│   │   │   ├── hydrology.py
│   │   │   ├── investigations.py
│   │   │   ├── one_health.py
│   │   │   └── sampling.py
│   │   ├── scientific/
│   │   │   ├── data_loader.py           ← WiggerPreflightLoader, CarraroHistoricalLoader
│   │   │   ├── historical_validation.py ← historical dataset validation helpers
│   │   │   ├── hypothesis.py            ← ConservativeHypothesisStateResolver, UnknownHypothesisStateResolver
│   │   │   ├── interfaces.py            ← HydrologyEngine, SamplingDecisionEngine protocols
│   │   │   ├── evidence/
│   │   │   │   └── engine.py            ← EvidenceCompatibilityEngineImpl
│   │   │   ├── hydrology/
│   │   │   │   └── engine.py            ← HydrologyEngine (directed graph, BFS)
│   │   │   ├── rules/
│   │   │   │   └── catalog.py           ← TOPOLOGY_CONTRIBUTION_RULE, TOPOLOGY_STRENGTH_RULE
│   │   │   └── sampling/
│   │   │       ├── candidate_generator.py ← CandidateSiteGenerator
│   │   │       └── engine.py              ← ScaffoldSamplingDecisionEngine
│   │   └── services/
│   │       ├── case_service.py
│   │       ├── evidence_service.py
│   │       ├── follow_up_sample_service.py
│   │       ├── hydrology_service.py
│   │       ├── investigation_service.py ← InvestigationService.reinvestigate()
│   │       ├── one_health_service.py    ← OneHealthService (hard-coded Wigger H001 Fs)
│   │       └── sampling_service.py
│   ├── alembic/
│   │   ├── env.py
│   │   ├── script.py.mako
│   │   └── versions/
│   │       ├── 6758ca39bed9_initial_schema_with_all_tables.py
│   │       ├── a31f6c729d0a_add_follow_up_samples.py
│   │       ├── d4c8e1a907b2_add_investigation_history.py
│   │       └── f1a2b3c4d5e6_decision_candidate_scope.py
│   ├── tests/
│   │   ├── conftest.py                  ← in-memory SQLite fixture
│   │   ├── property/
│   │   │   ├── test_evidence_properties.py
│   │   │   ├── test_hydrology_properties.py
│   │   │   ├── test_sampling_properties.py
│   │   │   └── test_schema_properties.py
│   │   └── unit/
│   │       ├── test_benchmark_sampling.py
│   │       ├── test_carraro_v4_extraction.py
│   │       ├── test_carraro_validation.py
│   │       ├── test_case_creation_integration.py
│   │       ├── test_context_infrastructure.py
│   │       ├── test_database_configuration.py
│   │       ├── test_defect_repairs.py
│   │       ├── test_follow_up_samples.py
│   │       ├── test_hydrology_engine.py
│   │       ├── test_investigation_runs.py
│   │       ├── test_sampling_repository.py
│   │       ├── test_sampling_scope_audit.py
│   │       ├── test_services.py
│   │       ├── test_v3_scientific_boundaries.py
│   │       ├── test_v4_scientific_update.py
│   │       ├── test_wigger_loader.py
│   │       ├── test_wigger_map_api.py
│   │       ├── test_wigger_reproducible_workflow.py
│   │       ├── test_wigger_scientific_regression.py
│   │       └── test_wigger_workflow_repairs.py
│   ├── alembic.ini
│   ├── config.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── .python-version
│   └── README.md
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx                      ← React router root
│   │   ├── main.jsx                     ← Vite entry point
│   │   ├── styles.css
│   │   ├── components/
│   │   │   ├── ApplicationLayout.jsx
│   │   │   ├── BundleErrors.jsx
│   │   │   ├── ScientificMap.jsx        ← MapLibre GL map component
│   │   │   └── UI.jsx
│   │   ├── data/
│   │   │   └── appData.js
│   │   ├── hooks/
│   │   │   └── useRemoteData.js
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Home.jsx
│   │   │   ├── Investigations.jsx       ← list + NewInvestigationForm
│   │   │   ├── InvestigationWorkspace.jsx ← workspace, evidence, candidates, follow-up
│   │   │   ├── Reports.jsx              ← full scientific report + PDF export
│   │   │   └── Sites.jsx                ← sites browser (Wigger demo only)
│   │   └── services/
│   │       └── api.js                   ← REST client (all API calls)
│   ├── tests/
│   │   └── wigger.spec.js               ← Playwright E2E tests (24 test instances)
│   ├── index.html
│   ├── package.json
│   ├── package-lock.json
│   ├── playwright.config.js
│   ├── vite.config.js
│   └── eslint.config.js
│
├── data_preflight/
│   ├── outputs/                         ← immutable Wigger reference artifacts (all included)
│   │   ├── site_a.json                  ← Site A coordinates + network representation
│   │   ├── upstream_reaches_real.csv    ← 49-reach Wigger sub-network
│   │   ├── upstream_edges.csv           ← directed graph edges
│   │   ├── upstream_reaches_real.geojson ← river network GeoJSON (rendered by map)
│   │   ├── candidate_zones_real.geojson ← Z1/Z2/Z3 zone polygons
│   │   ├── candidate_sampling_sites.csv ← Sites A–D with validated coordinates
│   │   ├── sampling_design_validation.json
│   │   ├── site_a_snap_validation.json
│   │   ├── generated_artifact_manifest.json
│   │   ├── hydrorivers_site_match.json
│   │   ├── FINAL_REPORT.md
│   │   └── (other outputs — see archive)
│   ├── raw/carraro/                     ← Carraro et al. historical eDNA data
│   │   ├── eDNA_data.mat                ← MATLAB eDNA measurement data (4 KB)
│   │   ├── data_wigger.mat              ← MATLAB Wigger dataset (4.7 MB)
│   │   ├── RUN_MODEL.m
│   │   ├── ANALYSE_DATA.m
│   │   ├── data_explanation.xlsx
│   │   └── README.md
│   └── scripts/                         ← preflight generation scripts
│       ├── analyze_candidate_zones.py
│       ├── build_upstream_graph.py
│       ├── complete_hydrorivers_match.py
│       ├── generate_candidate_sites.py
│       ├── validate_sampling_design.py
│       └── verify_candidate_zones.py
│
├── scripts/
│   ├── reproduce_wigger.py              ← Wigger reproducibility script
│   ├── benchmark_sampling.py
│   ├── validate_sampling.py
│   └── run_browser_test_backend.py      ← isolated SQLite backend for Playwright
│
├── reproducibility_outputs/
│   ├── wigger_result.json               ← machine-readable reproducibility result
│   └── WIGGER_INVESTIGATION_REPORT.md
│
├── scientific_validation_outputs/
│   ├── benchmark_summary.json
│   ├── sampling_audit.json
│   ├── sampling_execution_benchmark.json
│   └── benchmark_measurements_template.csv
│
├── README.md
├── REPRODUCIBILITY.md
├── FRESHWATER_PART1_ARCHITECTURE.md     ← Part 1 architecture audit
├── FRESHWATER_PART2_TEST_REPORT.md      ← Part 2 functional test report
├── SCIENCE_FREEZE_v1.md through v4.md   ← scientific boundary freeze documents
├── SCIENCE_FREEZE_v*.sha256             ← integrity checksums
├── HISTORICAL_VALIDATION_V4.md
├── SCIENTIFIC_VALIDATION_REPORT.md
├── SCIENTIFIC_RESOURCE_AUDIT.md
├── BACKEND_AUDIT_SUMMARY.md
├── BACKEND_TEST_REPORT.md
├── BROWSER_VERIFICATION_REPORT.md
├── COMPLETE_BACKEND_AUDIT.md
├── CURRENT_SYSTEM_AUDIT.md
├── FILE_MANIFEST.md
├── FRESHWATER_COMPLETE_PROJECT_DESCRIPTION.md
├── UPGRADE_V2_REPORT.md through V4_REPORT.md
├── V3_PROMPT_CONTEXT.md, V4_PROMPT_CONTEXT.md
├── CODEX_HANDOFF.md
└── AUDIT_MANIFEST.md                   ← this file
```

---

## 2. Backend and Frontend Entry Points

| Layer | Entry point | Command |
|---|---|---|
| Backend (production) | `backend/app/main.py` | `uvicorn app.main:app --host 0.0.0.0 --port 8000` |
| Backend (Playwright test) | `scripts/run_browser_test_backend.py` | `../venv/bin/python scripts/run_browser_test_backend.py` |
| Frontend (dev) | `frontend/src/main.jsx` | `npm run dev` (from `frontend/`) |
| Frontend (E2E tests) | `frontend/tests/wigger.spec.js` | `npx playwright test` (from `frontend/`) |
| Backend tests | `backend/tests/` | `../venv/bin/python3 -m pytest tests/ -v` (from `backend/`) |

**Python environment:** The project requires the virtualenv at `../venv/` (relative to `backend/`). `geopandas`, `scipy`, and `shapely` are only available in the venv, not the system Python.

---

## 3. Database Models and Migrations

### ORM models (`backend/app/db/models.py`) — 11 tables

| Model class | Table | Purpose |
|---|---|---|
| `CaseModel` | `cases` | eDNA case: taxon, date, detection_site FK, status, meta JSONB |
| `SamplingSiteModel` | `sampling_sites` | All sites: detection, branch, trunk, follow-up; HYRIV_ID, coords |
| `CandidateZoneModel` | `candidate_zones` | Upstream source zone: root HYRIV_ID, reach_ids array |
| `EvidenceItemModel` | `evidence_items` | Flexible evidence: type, source, value JSONB, provenance JSONB |
| `SamplingDecisionModel` | `sampling_decisions` | Recommendation: status enum, recommended_site_ids UUID[] |
| `DecisionTraceModel` | `decision_traces` | Audit trail: evidence_used, rules_applied, hydrology_checks |
| `FollowUpSampleModel` | `follow_up_samples` | Field sample: replicates, assay, controls, evidence FK |
| `InvestigationRunModel` | `investigation_runs` | Versioned run: trigger, status, snapshots JSONB |
| `HypothesisStateModel` | `hypothesis_states` | Per-zone per-run hypothesis status |
| `GeneratedCandidateSnapshotModel` | `generated_candidate_snapshots` | Per-candidate per-run snapshot |
| `alembic_version` | `alembic_version` | Migration tracking |

**Circular FK:** `cases.detection_site_id → sampling_sites.id` and `sampling_sites.case_id → cases.id`. This creates a circular dependency that causes SQLite teardown warnings in tests.

### Migrations (`backend/alembic/versions/`)

| File | Description |
|---|---|
| `6758ca39bed9_initial_schema_with_all_tables.py` | Initial schema: cases, sampling_sites, candidate_zones, evidence_items, sampling_decisions, decision_traces |
| `a31f6c729d0a_add_follow_up_samples.py` | Add `follow_up_samples` table |
| `d4c8e1a907b2_add_investigation_history.py` | Add `investigation_runs`, `hypothesis_states` |
| `f1a2b3c4d5e6_decision_candidate_scope.py` | Add `generated_candidate_snapshots` |

Run migrations: `alembic upgrade head` (from `backend/`)

---

## 4. Major Scientific Modules

### 4.1 HydroRIVERS river-network engine
**File:** `backend/app/scientific/hydrology/engine.py`  
**Class:** `HydrologyEngine`  
**Loaded from:** `data_preflight/outputs/upstream_reaches_real.csv` + `upstream_edges.csv`  
**Network size:** 49 reaches (Wigger sub-network only)  
**Methods:** `get_reach()`, `get_upstream_reaches()` (BFS), `get_downstream_path()`, `is_upstream()`, `can_contribute()`, `first_common_downstream()`, `network_distance_km()`, `zone_can_contribute_to_site()`

### 4.2 Data loader
**File:** `backend/app/scientific/data_loader.py`  
**Classes:** `WiggerPreflightLoader` (loads all preflight artifacts), `CarraroHistoricalLoader` (loads Carraro MATLAB data)  
**⚠ Known defect D3:** `WiggerPreflightLoader` is instantiated fresh on every sampling HTTP request in `sampling.py:get_sampling_service()` — full file I/O per request.

### 4.3 Evidence compatibility engine
**File:** `backend/app/scientific/evidence/engine.py`  
**Class:** `EvidenceCompatibilityEngineImpl`  
**Supported rule:** `hydrorivers.directed_contribution.v1` (topology only)  
**All other evidence types** return `EvidenceCompatibility.UNKNOWN` and `EvidenceStrength.UNASSESSED`  
**Note:** `follow_up_edna_sample`, `edna_observation`, `context_*` types have no rules

### 4.4 Scientific rule catalog
**File:** `backend/app/scientific/rules/catalog.py`  
**Rules:** `TOPOLOGY_CONTRIBUTION_RULE` (`hydrorivers.directed_contribution.v1`), `TOPOLOGY_STRENGTH_RULE` (`hydrorivers.directed_connectivity_strength.v1`)  
Only two rules exist. No biological, abundance, decay, or transport rules are implemented.

### 4.5 Hypothesis state resolver
**File:** `backend/app/scientific/hypothesis.py`  
**Classes:** `ConservativeHypothesisStateResolver` (uses validated directional rule IDs only; no elimination criterion), `UnknownHypothesisStateResolver` (always returns UNKNOWN)

### 4.6 Candidate site generator
**File:** `backend/app/scientific/sampling/candidate_generator.py`  
**Class:** `CandidateSiteGenerator`  
**Algorithm:** Enumerate upstream reaches → group by zone-reachability signature → select nearest-to-A representative per equivalence class  
**Score formula:** `pair_separation_score = reachable_count × (n − reachable_count)`

### 4.7 Sampling decision engine
**File:** `backend/app/scientific/sampling/engine.py`  
**Class:** `ScaffoldSamplingDecisionEngine`  
**Outcomes:** `RECOMMEND`, `TIE`, `ABSTAIN`, `INSUFFICIENT_DATA`  
**Rule ID:** `sampling.topology_pair_separation.v1`

### 4.8 Investigation service (reinvestigation orchestrator)
**File:** `backend/app/services/investigation_service.py`  
**Class:** `InvestigationService`  
**Method:** `reinvestigate()` — full 9-step orchestration: evidence assessment → hypothesis resolution → candidate generation → transient site evaluation → decision → trace → persist  
**⚠ Known defect D2:** Transient `SamplingSite` objects created with `uuid5` IDs are not persisted to `sampling_sites`. The `recommended_site_ids` in reinvestigation decisions reference non-existent rows.

### 4.9 One Health service
**File:** `backend/app/services/one_health_service.py`  
**⚠ Known defect D9:** Hard-coded check for Wigger H001 *Fredericella sultana* case only. Any other taxon/date/station returns an empty pathway list.

### 4.10 Preflight extraction
**File:** `backend/app/preflight/carraro_v4.py`  
**Class:** `CarraroV4Extractor` — extracts eDNA observations from Carraro MATLAB files for preflight artifact generation.

---

## 5. API Routes

### Investigation creation and management
| Method | Path | File | Notes |
|---|---|---|---|
| `POST` | `/cases` | `routes/cases.py` | Creates detection site + case atomically; validates HYRIV_ID |
| `GET` | `/cases` | `routes/cases.py` | List with status/taxon/limit/offset filters |
| `GET` | `/cases/{id}` | `routes/cases.py` | Retrieve single case |
| `GET` | `/demo/wigger` | `routes/demo.py` | Idempotent Wigger case loader |
| `GET` | `/demo/wigger/map` | `routes/demo.py` | Static Wigger preflight geometry |

### Evidence
| Method | Path | File | Notes |
|---|---|---|---|
| `POST` | `/cases/{id}/evidence` | `routes/evidence.py` | Add evidence item |
| `GET` | `/cases/{id}/evidence` | `routes/evidence.py` | List evidence |
| `GET` | `/cases/{id}/evidence-assessment` | `routes/evidence.py` | Run EvidenceCompatibilityEngine for all zones |

### Sampling sites and zones
| Method | Path | File | Notes |
|---|---|---|---|
| `POST` | `/cases/{id}/sites` | `routes/sampling.py` | Register sampling site |
| `GET` | `/cases/{id}/sites` | `routes/sampling.py` | List sampling sites |
| `POST` | `/cases/{id}/zones` | `routes/sampling.py` | Register candidate zone |
| `GET` | `/cases/{id}/zones` | `routes/sampling.py` | List candidate zones |
| `GET` | `/cases/{id}/map` | `routes/sampling.py` | Case-specific map (⚠ reloads preflight per call) |

### Candidates and decision
| Method | Path | File | Notes |
|---|---|---|---|
| `GET` | `/cases/{id}/generated-candidates` | `routes/sampling.py` | Generate topology candidates (⚠ reloads preflight) |
| `POST` | `/cases/{id}/sampling-decision` | `routes/sampling.py` | Evaluate registered sites (⚠ different path to reinvestigate) |
| `GET` | `/cases/{id}/sampling-decision` | `routes/sampling.py` | Get latest decision |
| `GET` | `/cases/{id}/decision-trace` | `routes/sampling.py` | Get decision audit trail |

### Reinvestigation
| Method | Path | File | Notes |
|---|---|---|---|
| `POST` | `/cases/{id}/reinvestigate` | `routes/investigations.py` | Full versioned run (⚠ transient IDs in decision) |
| `GET` | `/cases/{id}/investigation-runs` | `routes/investigations.py` | List all runs |
| `GET` | `/cases/{id}/investigation-runs/{run_id}` | `routes/investigations.py` | Run detail with change detection |

### Follow-up samples
| Method | Path | File | Notes |
|---|---|---|---|
| `POST` | `/cases/{id}/follow-up-samples` | `routes/follow_up_samples.py` | Atomically creates FollowUpSample + EvidenceItem |
| `GET` | `/cases/{id}/follow-up-samples` | `routes/follow_up_samples.py` | List follow-up samples |

### Context and One Health
| Method | Path | File | Notes |
|---|---|---|---|
| `POST` | `/cases/{id}/context/collect` | `routes/context.py` | All providers raise NotImplementedError |
| `GET` | `/cases/{id}/context` | `routes/context.py` | Returns UNAVAILABLE status items |
| `GET` | `/cases/{id}/one-health` | `routes/one_health.py` | One Health pathway (Wigger H001 Fs only) |

### Hydrology
| Method | Path | File | Notes |
|---|---|---|---|
| `GET` | `/hydrology/reaches/{id}` | `routes/hydrology.py` | Reach metadata |
| `GET` | `/hydrology/upstream/{id}` | `routes/hydrology.py` | All upstream reaches (BFS) |
| `GET` | `/hydrology/downstream/{id}` | `routes/hydrology.py` | Downstream path |
| `GET` | `/hydrology/distance` | `routes/hydrology.py` | Network distance between two reaches |

---

## 6. AI Integration

**No AI integration is currently implemented.** The application contains no AI provider client code, no prompt templates, no output schemas, and no AI validation logic. No placeholder files were created for this audit.

The file `ai_use.txt` at the workspace root contains notes about AI-assisted development but is not application code.

---

## 7. Test Commands and Required Environment

### Backend tests

```bash
# REQUIRED: use the project virtualenv (system Python lacks geopandas)
cd backend
../venv/bin/python3 -m pytest tests/ -v --tb=short

# With coverage
../venv/bin/python3 -m pytest tests/ -v --cov=app --cov-report=term-missing

# Property-based tests only
../venv/bin/python3 -m pytest tests/property/ -v

# Scientific regression only
../venv/bin/python3 -m pytest tests/unit/test_wigger_scientific_regression.py -v
```

**Test database:** In-memory SQLite (via `conftest.py`). No PostgreSQL required for tests.  
**Python:** 3.12.3 with virtualenv at `../venv/` (relative to `backend/`)

### Frontend / Playwright E2E tests

```bash
cd frontend
npx playwright install --with-deps chromium   # first time only
npx playwright test                            # runs all 24 test instances
```

**Requirements:** Backend and frontend start automatically via `playwright.config.js` `webServer` config. Backend uses isolated SQLite at `/tmp/edna-browser-test.sqlite`.

### Reproducibility script

```bash
cd /project-root
../venv/bin/python3 scripts/reproduce_wigger.py
```

### Database setup (PostgreSQL)

```bash
# Set DATABASE_URL in backend/.env (see .env.example)
cd backend
../venv/bin/python3 -m alembic upgrade head
```

---

## 8. Wigger Reference Dataset and Reproducibility Entry Points

### Reference data files (all in `data_preflight/outputs/`)

| File | Description |
|---|---|
| `site_a.json` | Site A (S1) coordinates, network snap, HYRIV_ID 20446064 |
| `upstream_reaches_real.csv` | 49-reach Wigger sub-network with LENGTH_KM, NEXT_DOWN, UPLAND_SKM |
| `upstream_edges.csv` | Directed graph edge list (upstream → downstream) |
| `upstream_reaches_real.geojson` | River network GeoJSON for map rendering |
| `candidate_zones_real.geojson` | Z1 (3 reaches), Z2 (21 reaches), Z3 (11 reaches) polygons |
| `candidate_sampling_sites.csv` | Sites A–D: coords, HYRIV_IDs, distances, validation_status |
| `sampling_design_validation.json` | Validation metadata including convergence reach |
| `site_a_snap_validation.json` | Site A snapping fraction (used in candidate distance calculation) |
| `generated_artifact_manifest.json` | Artifact provenance manifest |

### Raw Carraro data (in `data_preflight/raw/carraro/`)

| File | Description |
|---|---|
| `eDNA_data.mat` | MATLAB eDNA measurement file (H001: Fs S1 2014-06-25, 1.2983e-17 mol/L) |
| `data_wigger.mat` | Full Wigger MATLAB dataset (4.7 MB) |
| `RUN_MODEL.m` | MATLAB model runner |
| `ANALYSE_DATA.m` | MATLAB analysis script |

### Scientific freeze checksums

| File | Description |
|---|---|
| `SCIENCE_FREEZE_v1.md` through `v4.md` | Versioned freeze of validated scientific scope |
| `SCIENCE_FREEZE_v*.sha256` | SHA-256 integrity checksums for each freeze |

### Reproducibility outputs

| File | Description |
|---|---|
| `reproducibility_outputs/wigger_result.json` | Machine-readable Wigger case result |
| `reproducibility_outputs/WIGGER_INVESTIGATION_REPORT.md` | Human-readable reproducibility report |

### Demo API entry point

```
GET /demo/wigger
```

Idempotent. Loads case, 4 sites, 3 zones, 4 evidence items from preflight artifacts. Returns `{case_id, sites_created:4, zones_created:3}`.

---

## 9. Known Defects (from FRESHWATER_PART2_TEST_REPORT.md)

| ID | Severity | Description |
|---|---|---|
| D1 | HIGH | Dual evaluation paths: `POST /sampling-decision` evaluates registered sites; `POST /reinvestigate` evaluates generated transient sites. Can produce different decisions for same case. |
| D2 | HIGH | Reinvestigation stores `uuid5` transient site IDs in `sampling_decisions.recommended_site_ids` — these IDs do not exist in `sampling_sites`. |
| D3 | MEDIUM | `WiggerPreflightLoader` instantiated fresh on every sampling HTTP request; full file I/O per call. |
| D4 | LOW | `SamplingRepository` contains duplicate definitions of `_site_to_domain`, `_zone_to_domain`, `_decision_to_domain`. |
| D5 | MEDIUM | All three context providers raise `NotImplementedError`; Stage 2 cannot complete. |
| D6 | MEDIUM | `follow_up_edna_sample` evidence type has no interpretation rule; reinvestigation after field sampling produces identical hypothesis states. |
| D7 | MEDIUM | Registered-site decision TIE for Wigger case may incorrectly include Site D (HYRIV_ID 20448315). Requires further investigation. |
| D8 | MEDIUM | `geopandas` not installed in system Python; tests fail on system Python without virtualenv activation. |
| D9 | LOW | `OneHealthService` is hard-coded for Wigger H001 *Fredericella sultana* only. |
| D10 | LOW | `Sites.jsx` loads only Wigger demo sites via `demoApi.map()`; new cases not visible. |

---

## 10. Files and Datasets Excluded from Archive

| Excluded path | Reason |
|---|---|
| `backend/.env` | Contains real database credentials (PostgreSQL password) |
| `venv/` | ~400 MB Python virtualenv; reconstructible via `pip install -r requirements.txt` |
| `venv_old/` | Stale secondary virtualenv |
| `frontend/node_modules/` | ~200 MB npm packages; reconstructible via `npm install` |
| `frontend/dist/` | Compiled frontend bundle; reconstructible via `npm run build` |
| `data_preflight/raw/HydroRIVERS_v10_eu.shp` and companion files | 252 MB raw HydroRIVERS Europe shapefile; not used at runtime (only Wigger sub-network CSV is loaded) |
| `data_preflight/raw/hydrorivers/` | 252 MB raw HydroRIVERS shapefile components |
| `backups/eDna_pre_migration_20261003_161811.dump` | PostgreSQL database dump containing live data |
| `HydroRIVERS_v10_eu_shp/` | 252 MB HydroRIVERS shapefile at root (duplicate of `data_preflight/raw/hydrorivers/`) |
| `browser_artifacts/` | 15 MB Playwright screenshots and PDFs from test runs |
| `**/__pycache__/` | Compiled Python bytecode |
| `**/.pytest_cache/` | pytest cache |
| `**/.hypothesis/` | Hypothesis example database |
| `**/.coverage` | Coverage data |
| `frontend/browser_artifacts/` | Browser test artefacts |
| `workflow/` | Single workflow diagram image |
| `ui/` | UI screenshots (PNG files, no source code) |
| `tmp/` | Temporary files |
| `ai_use.txt`, `rough.txt`, `imporve.txt` | Scratch notes, no code |
| `FRESHWATER_DEBUG_PACKAGE.zip` | Pre-existing partial ZIP archive |
| `.git/` | Git repository history |
| `.kiro/` | IDE configuration |
