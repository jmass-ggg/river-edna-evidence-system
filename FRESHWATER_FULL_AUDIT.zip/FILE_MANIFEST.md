# FILE MANIFEST
## FreshWater eDNA Evidence Investigator — Technical Review Package

### How to use this manifest
Every file in FRESHWATER_REVIEW_PACKAGE.zip is listed below with its original path,
a brief purpose note, the remaining-task domain it relates to, and key dependencies.

---

## 1. Scientific Documentation

| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| REPRODUCIBILITY.md | Full reproducibility procedure, checksums, expected outputs, and known limitations | Reproducibility / CI | scripts/reproduce_wigger.py, preflight outputs |
| PROJECT_COMPLETION_REPORT.md | Comprehensive status report: architecture, engines, test coverage, known issues | All domains | All modules |

---

## 2. Scientific Validation Outputs

| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| scientific_validation_outputs/sampling_audit.json | Sampling decision audit trace for the Wigger case | Sampling engine audit / traceability | SamplingDecisionEngine |
| scientific_validation_outputs/benchmark_measurements_template.csv | Template CSV for benchmark measurement recording | Benchmarking / performance | scripts/benchmark_sampling.py |

**Excluded (too large or binary):**
- scientific_validation_outputs/benchmark_summary.json (generated artefact, can be regenerated)
- data_preflight/raw/carraro/data_wigger.mat (4.7 MB MATLAB binary — not included)
- data_preflight/raw/carraro/eDNA_data.mat (MATLAB binary — not included)
- data_preflight/raw/hydrorivers/* (binary GIS shapefiles — not included)
- HydroRIVERS_v10_eu_shp/* (binary GIS shapefiles — not included)

---

## 3. Scripts

| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| scripts/validate_sampling.py | Validates sampling design against preflight outputs | Sampling validation | preflight outputs, HydrologyEngine |
| scripts/benchmark_sampling.py | Benchmarks sampling decision performance | Performance / benchmarking | SamplingDecisionEngine |
| scripts/reproduce_wigger.py | End-to-end Wigger case reproduction via FastAPI | Reproducibility / CI | All backend engines, preflight outputs |

---

## 4. Scientific Engines

### Core Infrastructure
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/scientific/__init__.py | Package init | — | — |
| backend/app/scientific/interfaces.py | Protocol definitions (IHydrologyEngine, IEvidenceEngine, ISamplingEngine) | All engines | domain/models.py |
| backend/app/scientific/data_loader.py | Loads preflight CSV/JSON/GeoJSON data | Data loading | preflight outputs |
| backend/app/scientific/hypothesis.py | Competing hypothesis data structures | Hypothesis management | domain/models.py |
| backend/app/scientific/historical_validation.py | Carraro 2020 historical case validation helper | Historical validation | data_loader.py, engines |

### Hydrology Engine
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/scientific/hydrology/__init__.py | Package init | — | — |
| backend/app/scientific/hydrology/engine.py | Network graph construction, upstream/downstream queries, distance calculation | Hydrological graph processing | data_loader.py, interfaces.py |

### Evidence Engine
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/scientific/evidence/__init__.py | Package init | — | — |
| backend/app/scientific/evidence/engine.py | Rule-based evidence compatibility assessment | Evidence assessment | rules/catalog.py, interfaces.py |

### Sampling Engine
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/scientific/sampling/__init__.py | Package init | — | — |
| backend/app/scientific/sampling/engine.py | Topology-based site recommendation and decision trace | Sampling decisions | hydrology/engine.py, interfaces.py |
| backend/app/scientific/sampling/candidate_generator.py | Generates candidate sampling sites from zone topology | Candidate generation | hydrology/engine.py |

### Rules & Context
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/scientific/rules/__init__.py | Package init | — | — |
| backend/app/scientific/rules/catalog.py | Scientific rule definitions with provenance | Rule management | domain/enums.py |
| backend/app/preflight/__init__.py | Package init | — | — |
| backend/app/preflight/carraro_v4.py | Carraro v4 data extraction helpers | Historical validation | data_loader.py |
| backend/app/context/__init__.py | Package init | — | — |
| backend/app/context/interfaces.py | Environmental context provider protocols | Environmental integration | — |
| backend/app/context/service.py | Aggregates environmental context from providers | Environmental integration | providers/* |
| backend/app/context/providers/__init__.py | Package init | — | — |
| backend/app/context/providers/gbif.py | GBIF biodiversity data provider adapter | Environmental/One Health | context/interfaces.py |
| backend/app/context/providers/urbanization.py | Urbanization data provider adapter | Environmental context | context/interfaces.py |
| backend/app/context/providers/weather.py | Weather data provider adapter | Environmental context | context/interfaces.py |

---

## 5. Backend Application

### Core
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/__init__.py | Application package init | — | — |
| backend/app/main.py | FastAPI app entry point, router registration, startup | All API | all routes |
| backend/config.py | Configuration management (env vars, DB URL) | Deployment / config | — |
| backend/requirements.txt | Python dependency list | Environment setup | — |

### API Routes
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/api/__init__.py | API package init | — | — |
| backend/app/api/dependencies.py | Dependency injection (DB session, engines) | All routes | db/session.py |
| backend/app/api/routes/__init__.py | Routes package init | — | — |
| backend/app/api/routes/health.py | Health check endpoint | Monitoring | — |
| backend/app/api/routes/cases.py | Case CRUD endpoints | Investigation creation/retrieval | services/case_service.py |
| backend/app/api/routes/evidence.py | Evidence management endpoints | Evidence assessment | services/evidence_service.py |
| backend/app/api/routes/hydrology.py | Hydrology query endpoints | Hydrological graph processing | services/hydrology_service.py |
| backend/app/api/routes/sampling.py | Sampling decision endpoints | Sampling decisions | services/sampling_service.py |
| backend/app/api/routes/demo.py | Demo/Wigger data loader endpoint | Reproducibility | all services |
| backend/app/api/routes/investigations.py | Investigation workflow endpoints | Investigation creation/retrieval | services/investigation_service.py |
| backend/app/api/routes/context.py | Environmental context endpoints | Environmental integration | services (context) |
| backend/app/api/routes/one_health.py | One Health interpretation endpoints | One Health / report generation | services/one_health_service.py |
| backend/app/api/routes/follow_up_samples.py | Follow-up eDNA sample endpoints | Follow-up sample management | services/follow_up_sample_service.py |

### Domain
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/domain/__init__.py | Domain package init | — | — |
| backend/app/domain/models.py | Domain entities (Case, Site, Reach, Evidence, Decision) | All domains | domain/enums.py |
| backend/app/domain/enums.py | Domain enumerations (EvidenceCompatibility, SamplingDecisionStatus…) | All domains | — |

### Database
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/db/__init__.py | DB package init | — | — |
| backend/app/db/base.py | SQLAlchemy declarative base | DB schema | — |
| backend/app/db/models.py | ORM models (all 8 tables) | DB schema / migrations | db/base.py, domain/enums.py |
| backend/app/db/session.py | Session factory and context managers | DB access | config.py |

### Repositories
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/repositories/__init__.py | Repositories package init | — | — |
| backend/app/repositories/cases.py | Case CRUD | Investigation creation/retrieval | db/models.py |
| backend/app/repositories/evidence.py | Evidence CRUD | Evidence assessment | db/models.py |
| backend/app/repositories/sampling.py | Sampling site/decision CRUD | Sampling decisions | db/models.py |
| backend/app/repositories/investigations.py | Investigation run records | Scientific investigation endpoints | db/models.py |
| backend/app/repositories/follow_up_samples.py | Follow-up sample CRUD | Follow-up sample management | db/models.py |

### Services
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/services/case_service.py | Case orchestration | Investigation creation/retrieval | repositories/cases.py |
| backend/app/services/evidence_service.py | Evidence assessment orchestration | Evidence assessment | evidence/engine.py |
| backend/app/services/hydrology_service.py | Hydrology analysis orchestration | Hydrological graph processing | hydrology/engine.py |
| backend/app/services/sampling_service.py | Sampling decision orchestration | Sampling decisions | sampling/engine.py |
| backend/app/services/investigation_service.py | Full investigation workflow | Scientific investigation endpoints | all engines |
| backend/app/services/one_health_service.py | One Health interpretation | One Health / report generation | context/service.py |
| backend/app/services/follow_up_sample_service.py | Follow-up sample management | Follow-up sample management | repositories/follow_up_samples.py |

### Schemas
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/app/schemas/__init__.py | Schemas package init | — | — |
| backend/app/schemas/cases.py | Case request/response schemas | Case API | domain/models.py |
| backend/app/schemas/evidence.py | Evidence request/response schemas | Evidence API | domain/enums.py |
| backend/app/schemas/hydrology.py | Hydrology response schemas | Hydrology API | — |
| backend/app/schemas/sampling.py | Sampling request/response schemas | Sampling API | domain/enums.py |
| backend/app/schemas/context.py | Environmental context schemas | Environmental integration API | — |
| backend/app/schemas/one_health.py | One Health interpretation schemas | One Health API | — |
| backend/app/schemas/investigations.py | Investigation run schemas | Investigation API | — |
| backend/app/schemas/follow_up_samples.py | Follow-up sample schemas | Follow-up API | — |

### Migrations
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/alembic/env.py | Alembic migration environment | DB schema | db/models.py |
| backend/alembic/versions/6758ca39bed9_initial_schema_with_all_tables.py | Initial 8-table schema | DB schema | — |
| backend/alembic/versions/a31f6c729d0a_add_follow_up_samples.py | Follow-up samples table migration | Follow-up sample management | — |
| backend/alembic/versions/d4c8e1a907b2_add_investigation_history.py | Investigation history table migration | Investigation runs | — |
| backend/alembic.ini | Alembic configuration | DB migrations | — |
| backend/.env.example | Environment variable template (no secrets) | Deployment / config | — |

### Documentation
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/README.md | Backend setup, architecture, API guide | All | — |
| backend/API_DOCUMENTATION.md | Full endpoint reference | API integration | — |

---

## 6. Tests

### Test Infrastructure
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/tests/__init__.py | Test package init | — | — |
| backend/tests/conftest.py | Shared fixtures (in-memory DB, engine instances) | All tests | all engines |

### Unit Tests
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/tests/unit/__init__.py | Unit test package init | — | — |
| backend/tests/unit/test_hydrology_engine.py | HydrologyEngine unit tests | Hydrology | hydrology/engine.py |
| backend/tests/unit/test_services.py | Service layer unit tests | All services | services/* |
| backend/tests/unit/test_sampling_repository.py | Sampling repository tests | Sampling decisions | repositories/sampling.py |
| backend/tests/unit/test_wigger_loader.py | Data loader tests for Wigger preflight data | Data loading | data_loader.py |
| backend/tests/unit/test_wigger_scientific_regression.py | Wigger case regression tests | Reproducibility | all engines |
| backend/tests/unit/test_carraro_validation.py | Carraro 2020 historical validation | Historical validation | preflight/carraro_v4.py |
| backend/tests/unit/test_wigger_reproducible_workflow.py | End-to-end reproducibility test | Reproducibility | reproduce_wigger.py |
| backend/tests/unit/test_wigger_map_api.py | Wigger map API regression | Scientific API endpoints | routes/hydrology.py |
| backend/tests/unit/test_context_infrastructure.py | Environmental context provider tests | Environmental integration | context/* |
| backend/tests/unit/test_follow_up_samples.py | Follow-up sample workflow tests | Follow-up sample management | services/follow_up_sample_service.py |
| backend/tests/unit/test_investigation_runs.py | Investigation run and history tests | Scientific investigation endpoints | services/investigation_service.py |
| backend/tests/unit/test_case_creation_integration.py | Case creation integration tests | Investigation creation/retrieval | services/case_service.py |
| backend/tests/unit/test_benchmark_sampling.py | Sampling performance benchmark tests | Benchmarking | sampling/engine.py |
| backend/tests/unit/test_carraro_v4_extraction.py | Carraro v4 data extraction tests | Historical validation | preflight/carraro_v4.py |
| backend/tests/unit/test_sampling_scope_audit.py | Sampling scope audit validation | Sampling audit | sampling/engine.py |
| backend/tests/unit/test_v3_scientific_boundaries.py | V3 scientific boundary tests | Scientific regression | engines |
| backend/tests/unit/test_v4_scientific_update.py | V4 scientific update tests | Scientific regression | engines |

### Property-Based Tests
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| backend/tests/property/__init__.py | Property test package init | — | — |
| backend/tests/property/test_hydrology_properties.py | Hydrology universal properties (100+ iterations) | Hydrology | hydrology/engine.py |
| backend/tests/property/test_evidence_properties.py | Evidence assessment properties (100+ iterations) | Evidence assessment | evidence/engine.py |
| backend/tests/property/test_sampling_properties.py | Sampling decision properties (100+ iterations) | Sampling decisions | sampling/engine.py |
| backend/tests/property/test_schema_properties.py | Schema serialization/round-trip properties | API schemas | schemas/* |

### Browser / E2E Tests
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| frontend/playwright.config.js | Playwright E2E test configuration | E2E / browser testing | frontend |
| frontend/tests/wigger.spec.js | Playwright Wigger workflow E2E test | Reproducibility / E2E | frontend pages |

---

## 7. Frontend

| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| frontend/src/App.jsx | Root React component and router | UI shell | all pages |
| frontend/src/main.jsx | React entry point | UI bootstrap | App.jsx |
| frontend/src/pages/InvestigationWorkspace.jsx | Scientific investigation workspace page | Investigation workflow UI | api.js |
| frontend/src/pages/Investigations.jsx | Investigation list page | Investigation list UI | api.js |
| frontend/src/pages/Dashboard.jsx | Overview dashboard page | Dashboard UI | api.js |
| frontend/src/pages/Reports.jsx | Scientific report display page | Report generation UI | api.js |
| frontend/src/pages/Sites.jsx | Sampling sites management page | Sampling site UI | api.js |
| frontend/src/components/ScientificMap.jsx | Interactive map for candidate/sampling site display | Map / candidate comparison | api.js |
| frontend/src/components/ApplicationLayout.jsx | Application shell layout and navigation | UI layout | — |
| frontend/src/components/UI.jsx | Shared UI component library | All pages | — |
| frontend/src/services/api.js | API client for all backend endpoints | API integration | — |
| frontend/src/hooks/useRemoteData.js | Data-fetching hook | Data loading | api.js |
| frontend/src/data/appData.js | Static application data / config | UI config | — |
| frontend/package.json | Frontend dependencies and scripts | Build / environment | — |
| frontend/vite.config.js | Vite build configuration | Build | — |
| frontend/index.html | HTML entry point | Build | — |

**Excluded frontend files:**
- frontend/src/styles.css (styling asset, not needed for logic review)
- frontend/src/pages/Home.jsx (landing page, not scientific workflow)
- frontend/dist/* (generated build output — excluded)
- frontend/node_modules/* (dependencies — excluded)
- frontend/browser_artifacts/* (screenshots — excluded)

---

## 8. Preflight Data Pipeline

### Outputs (text/JSON/CSV — included)
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| data_preflight/outputs/site_a.json | Site A coordinates and HYRIV_ID 20446064 | Data loading | — |
| data_preflight/outputs/site_a_snap_validation.json | Network snap audit | Validation | site_a.json |
| data_preflight/outputs/upstream_reaches_real.csv | 49 reach metadata records | Hydrology | — |
| data_preflight/outputs/upstream_edges.csv | Network connectivity graph | Hydrology | — |
| data_preflight/outputs/candidate_zones_real.geojson | Z1/Z2/Z3 zone definitions | Candidate generation | — |
| data_preflight/outputs/candidate_sampling_sites.csv | Sites B/C/D with distances | Sampling decisions | — |
| data_preflight/outputs/sampling_design_validation.json | Validation metadata | Sampling validation | — |
| data_preflight/outputs/FINAL_REPORT.md | Site A methodology justification | Documentation | — |
| data_preflight/outputs/preflight_report.md | Full preflight analysis report | Documentation | — |
| data_preflight/outputs/generated_artifact_manifest.json | Preflight artifact manifest | Traceability | — |

**Excluded preflight outputs:**
- *.geojson files other than candidate_zones_real.geojson (large GIS data)
- wigger_preflight_map.png (binary image)
- raw/*.mat, raw/*.shp, raw/*.dbf, etc. (binary / large datasets)

### Scripts
| File | Purpose | Related Task | Dependencies |
|------|---------|--------------|-------------|
| data_preflight/scripts/analyze_candidate_zones.py | Analyzes candidate zones | Data pipeline | preflight data |
| data_preflight/scripts/build_upstream_graph.py | Builds upstream network graph | Hydrology | HydroRIVERS shapefiles |
| data_preflight/scripts/complete_hydrorivers_match.py | Matches sites to HydroRIVERS reaches | Data pipeline | HydroRIVERS shapefiles |
| data_preflight/scripts/generate_candidate_sites.py | Generates candidate sampling sites | Candidate generation | zone data |
| data_preflight/scripts/validate_sampling_design.py | Validates sampling design | Sampling validation | preflight outputs |
| data_preflight/scripts/verify_candidate_zones.py | Verifies zone correctness | Data validation | preflight outputs |
| data_preflight/raw/carraro/README.md | Carraro dataset documentation | Historical validation | — |

---

## 9. Project Structure Files

| File | Purpose |
|------|---------|
| PROJECT_STRUCTURE.txt | Filtered repository tree (no noise dirs) |
| FILE_MANIFEST.md | This file — full manifest with purpose and dependency notes |

---

## Dependency Graph Summary

```
preflight outputs (CSV/JSON/GeoJSON)
  └─> data_loader.py
        ├─> hydrology/engine.py  ──> hydrology routes ──> hydrology_service.py
        ├─> evidence/engine.py   ──> evidence routes  ──> evidence_service.py
        ├─> sampling/engine.py   ──> sampling routes  ──> sampling_service.py
        │     └─> candidate_generator.py
        └─> rules/catalog.py
              └─> evidence/engine.py

context/providers/* ──> context/service.py ──> one_health_service.py
investigation_service.py ──> all engines
reproduce_wigger.py ──> all routes (integration)
```
