"""
eDNA Evidence Investigator Backend Application Package.
"""
__version__ = "0.1.0"
